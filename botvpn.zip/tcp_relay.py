# tcp_relay.py — BotVPN High-Concurrency Single-Port Engine
# Supports: VMess-AEAD (HTTP-TCP/WS/TCP/TLS) + Iran HTTP-TCP + VLESS (TCP/WS/TLS/WSS/HTTP-TLS) + Trojan + SOCKS5 + HTTP CONNECT + Full XUDP/Mux DNS
import asyncio
import base64
import datetime
import hashlib
import os
import secrets
import socket
import ssl
import struct
import subprocess
import json
import uuid as uuid_mod
import zlib
from pathlib import Path

import hmac
import tempfile
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from cryptography.hazmat.primitives.kdf.hkdf import HKDF, HKDFExpand
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305

from relay_vless import (
    _fast_check_and_use,
    _decode_base64_any,
    parse_vless_header_ex,
    parse_trojan_header_ex,
    has_vision_flow,
    ALLOW_ALL_UDP,
    _resolve_dns_over_tcp,
)

try:
    from websockets.speedups import apply_mask as _ws_unmask
except Exception:
    def _ws_unmask(payload: bytes, mask: bytes) -> bytes:
        n = len(payload)
        if not n:
            return b""
        m_rep = (mask * ((n >> 2) + 1))[:n]
        return (int.from_bytes(payload, "big") ^ int.from_bytes(m_rep, "big")).to_bytes(n, "big")

logger = None

TCP_LISTEN_PORT = int(os.environ.get("TCP_LISTEN_PORT", "6543"))
INTERNAL_TLS_PORT = int(os.environ.get("INTERNAL_TLS_PORT", "26423"))

# Tuned for high multi-user concurrency without GC spikes or buffer bloat
RELAY_BUF = 65536         # 64 KB read chunk (L2-cache friendly, zero GC stutter)
DRAIN_THRESHOLD = 131072  # 128 KB write high-water mark
STREAM_LIMIT = 131072     # 128 KB stream reader window

_WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
_VMESS_MAGIC = b"c48619fe-8f02-49e0-b9e9-edf763e17e21"

# Standard raw HTTP obfuscation response (NO Transfer-Encoding: chunked so Xray/Sing-box stream readers never choke)
_HTTP_OBFUSCATION_RESP = (
    b"HTTP/1.1 200 OK\r\n"
    b"Server: nginx\r\n"
    b"Content-Type: application/octet-stream\r\n"
    b"Connection: keep-alive\r\n"
    b"Cache-Control: no-cache\r\n"
    b"Pragma: no-cache\r\n\r\n"
)

_SOCKS5_OK_RESP = b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00"

_servers: list[asyncio.AbstractServer] = []
_tls_ctx: ssl.SSLContext | None = None
_TLS_CLIENT_IPS: dict[int, str] = {}
CERT_SHA256: str = ""
_VMESS_AUTH_CACHE: dict[str, tuple[bytes, object]] = {}


def _tune_sock(writer: asyncio.StreamWriter):
    sock = writer.transport.get_extra_info("socket")
    if not sock:
        return
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    except Exception:
        pass
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    except Exception:
        pass
    try:
        tcp_maxseg = getattr(socket, "TCP_MAXSEG", 2)
        sock.setsockopt(socket.IPPROTO_TCP, tcp_maxseg, 1360)
    except Exception:
        pass
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 524288)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 524288)
    except Exception:
        pass


def _client_ip(writer: asyncio.StreamWriter) -> str:
    try:
        peer = writer.get_extra_info("peername")
        if not peer:
            return "unknown"
        if peer[0] == "127.0.0.1" and len(peer) >= 2:
            return _TLS_CLIENT_IPS.get(peer[1], "127.0.0.1")
        return peer[0]
    except Exception:
        return "unknown"


# ============================================================
# VMESS AEAD PROTOCOL ENGINE (Xray-core / Sing-box / v2rayN / Happ)
# ============================================================

def _vmess_kdf(key: bytes, *path: bytes) -> bytes:
    def _make_hmac(parent_fn, k: bytes):
        if len(k) > 64:
            h = parent_fn()
            h.update(k)
            k = h.digest()
        k_pad = k.ljust(64, b"\x00")
        ipad = bytes(b ^ 0x36 for b in k_pad)
        opad = bytes(b ^ 0x5c for b in k_pad)

        class _NestedHMAC:
            __slots__ = ("_in",)

            def __init__(self):
                self._in = parent_fn()
                self._in.update(ipad)

            def update(self, d: bytes):
                self._in.update(d)

            def digest(self) -> bytes:
                out = parent_fn()
                out.update(opad)
                out.update(self._in.digest())
                return out.digest()

        return _NestedHMAC

    fn = _make_hmac(hashlib.sha256, b"VMess AEAD KDF")
    for p in path:
        fn = _make_hmac(fn, p)
    h = fn()
    h.update(key)
    return h.digest()


def _get_vmess_auth(uid: str) -> tuple[bytes, object] | None:
    cached = _VMESS_AUTH_CACHE.get(uid)
    if cached is not None:
        return cached
    try:
        u_bytes = uuid_mod.UUID(uid).bytes
        cmd_key = hashlib.md5(u_bytes + _VMESS_MAGIC).digest()
        auth_key = _vmess_kdf(cmd_key, b"AES Auth ID Encryption")[:16]
        cipher = Cipher(algorithms.AES(auth_key), modes.ECB())
        _VMESS_AUTH_CACHE[uid] = (cmd_key, cipher)
        return cmd_key, cipher
    except Exception:
        return None


def _match_vmess_eauid(eauid: bytes, links: dict) -> tuple[str, bytes] | None:
    if len(eauid) < 16:
        return None
    block = eauid[:16]
    for uid in links:
        info = _get_vmess_auth(uid)
        if not info:
            continue
        cmd_key, cipher = info
        try:
            dec = cipher.decryptor()
            plain = dec.update(block) + dec.finalize()
            crc_calc = zlib.crc32(plain[:12]) & 0xFFFFFFFF
            crc_got = int.from_bytes(plain[12:16], "big")
            if crc_calc == crc_got:
                return uid, cmd_key
        except Exception:
            continue
    return None


def parse_vmess_aead_header(buf: bytes, links: dict):
    """
    Returns (uid, cmd, address, port, payload, vmess_ctx, need_more) or None if not VMess AEAD.
    """
    if len(buf) < 16:
        return None, 0, "", 0, b"", None, True
    matched = _match_vmess_eauid(buf[:16], links)
    if not matched:
        return None
    uid, cmd_key = matched
    if len(buf) < 42:
        return uid, 0, "", 0, b"", None, True

    eauid = buf[:16]
    alength_enc = buf[16:34]
    nonce = buf[34:42]
    try:
        len_key = _vmess_kdf(cmd_key, b"VMess Header AEAD Key_Length", eauid, nonce)[:16]
        len_nonce = _vmess_kdf(cmd_key, b"VMess Header AEAD Nonce_Length", eauid, nonce)[:12]
        hdr_len_bytes = AESGCM(len_key).decrypt(len_nonce, alength_enc, eauid)
        hdr_len = int.from_bytes(hdr_len_bytes, "big")
    except Exception:
        return None

    total_hdr_end = 42 + hdr_len + 16
    if len(buf) < total_hdr_end:
        return uid, 0, "", 0, b"", None, True

    aheader_enc = buf[42:total_hdr_end]
    try:
        h_key = _vmess_kdf(cmd_key, b"VMess Header AEAD Key", eauid, nonce)[:16]
        h_nonce = _vmess_kdf(cmd_key, b"VMess Header AEAD Nonce", eauid, nonce)[:12]
        hdr = AESGCM(h_key).decrypt(h_nonce, aheader_enc, eauid)
    except Exception:
        return None

    if len(hdr) < 41 or hdr[0] != 1:
        return None

    req_iv = hdr[1:17]
    req_key = hdr[17:33]
    resp_v = hdr[33]
    opt = hdr[34]
    p_margin = (hdr[35] >> 4) & 0x0F
    sec = hdr[35] & 0x0F
    cmd = hdr[37]
    port = int.from_bytes(hdr[38:40], "big")
    atyp = hdr[40]
    pos = 41

    if atyp == 1:
        if len(hdr) < pos + 4:
            return None
        address = ".".join(str(b) for b in hdr[pos : pos + 4])
        pos += 4
    elif atyp == 2:
        if len(hdr) < pos + 1:
            return None
        dlen = hdr[pos]
        pos += 1
        if len(hdr) < pos + dlen:
            return None
        address = hdr[pos : pos + dlen].decode("utf-8", errors="ignore")
        pos += dlen
    elif atyp == 3:
        if len(hdr) < pos + 16:
            return None
        ab = hdr[pos : pos + 16]
        pos += 16
        address = ":".join(f"{ab[i]:02x}{ab[i+1]:02x}" for i in range(0, 16, 2))
    else:
        return None

    resp_key = hashlib.sha256(req_key).digest()[:16]
    resp_iv = hashlib.sha256(req_iv).digest()[:16]
    rlen_key = _vmess_kdf(resp_key, b"AEAD Resp Header Len Key")[:16]
    rlen_nonce = _vmess_kdf(resp_iv, b"AEAD Resp Header Len IV")[:12]
    rhdr_key = _vmess_kdf(resp_key, b"AEAD Resp Header Key")[:16]
    rhdr_nonce = _vmess_kdf(resp_iv, b"AEAD Resp Header IV")[:12]

    enc_rlen = AESGCM(rlen_key).encrypt(rlen_nonce, b"\x00\x04", None)
    enc_rhdr = AESGCM(rhdr_key).encrypt(rhdr_nonce, bytes([resp_v, 0, 0, 0]), None)

    vmess_ctx = {
        "req_iv": req_iv,
        "req_key": req_key,
        "resp_iv": resp_iv,
        "resp_key": resp_key,
        "opt": opt,
        "sec": sec,
        "resp_prefix": enc_rlen + enc_rhdr,
    }
    return uid, cmd, address, port, buf[total_hdr_end:], vmess_ctx, False


class _ShakeStream:
    __slots__ = ("_buf", "_pos", "_iv", "_len")

    def __init__(self, iv: bytes):
        self._iv = iv
        self._len = 65536
        self._buf = hashlib.shake_128(iv).digest(self._len)
        self._pos = 0

    def next_u16(self) -> int:
        if self._pos + 2 > len(self._buf):
            self._len *= 2
            self._buf = hashlib.shake_128(self._iv).digest(self._len)
        val = (self._buf[self._pos] << 8) | self._buf[self._pos + 1]
        self._pos += 2
        return val


def _make_vmess_aead_cipher(sec: int, key: bytes):
    if sec == 0x03:  # AES-128-GCM
        return AESGCM(key)
    if sec == 0x04:  # ChaCha20-Poly1305
        m1 = hashlib.md5(key).digest()
        m2 = hashlib.md5(m1).digest()
        return ChaCha20Poly1305(m1 + m2)
    return None


async def _relay_vmess_session(
    read_fn,
    write_fn,
    initial_payload: bytes,
    vmess_ctx: dict,
    address: str,
    port: int,
    command: int,
    link: dict,
    conn_entry: dict,
    uid: str,
    throttle,
):
    from outbound_proxy import open_target_connection

    opt = vmess_ctx["opt"]
    sec = vmess_ctx["sec"]
    chunk_stream = bool(opt & 0x01) and sec != 0x06
    chunk_mask = bool(opt & 0x04) and chunk_stream
    global_pad = bool(opt & 0x08) and chunk_mask

    req_shake = _ShakeStream(vmess_ctx["req_iv"]) if chunk_mask else None
    resp_shake = _ShakeStream(vmess_ctx["resp_iv"]) if chunk_mask else None
    req_aead = _make_vmess_aead_cipher(sec, vmess_ctx["req_key"])
    resp_aead = _make_vmess_aead_cipher(sec, vmess_ctx["resp_key"])
    req_iv_tail = vmess_ctx["req_iv"][2:12]
    resp_iv_tail = vmess_ctx["resp_iv"][2:12]

    buf = initial_payload
    req_count = 0

    async def _read_next_plain_chunk() -> bytes:
        nonlocal buf, req_count
        if not chunk_stream:
            if buf:
                out = buf
                buf = b""
                return out
            return await read_fn()

        while len(buf) < 2:
            more = await read_fn()
            if not more:
                return b""
            buf += more

        pad_len = (req_shake.next_u16() % 64) if global_pad else 0
        mask = req_shake.next_u16() if chunk_mask else 0
        raw_len = int.from_bytes(buf[:2], "big")
        total_len = raw_len ^ mask
        buf = buf[2:]

        while len(buf) < total_len:
            more = await read_fn()
            if not more:
                return b""
            buf += more

        pkt = buf[:total_len]
        buf = buf[total_len:]
        data_len = total_len - pad_len
        if data_len <= 0:
            return b""
        ct = pkt[:data_len]

        if req_aead is not None:
            if len(ct) < 16:
                return b""
            nonce = req_count.to_bytes(2, "big") + req_iv_tail
            req_count += 1
            plain = req_aead.decrypt(nonce, ct, None)
            return plain
        return ct

    resp_count = 0
    sent_resp_hdr = False

    async def _write_plain_chunk(data: bytes):
        nonlocal resp_count, sent_resp_hdr
        prefix = b""
        if not sent_resp_hdr:
            sent_resp_hdr = True
            prefix = vmess_ctx["resp_prefix"]

        if not chunk_stream:
            await write_fn(prefix + data)
            return

        # Split into <= 16384-byte chunks for VMess standard framing
        out_parts = [prefix] if prefix else []
        mv = memoryview(data)
        idx = 0
        n_total = len(data)
        while idx < n_total:
            part = bytes(mv[idx : idx + 15360])
            idx += len(part)
            pad_len = (resp_shake.next_u16() % 64) if global_pad else 0
            mask = resp_shake.next_u16() if chunk_mask else 0
            padding = os.urandom(pad_len) if pad_len else b""
            if resp_aead is not None:
                nonce = resp_count.to_bytes(2, "big") + resp_iv_tail
                resp_count += 1
                enc_body = resp_aead.encrypt(nonce, part, None)
            else:
                enc_body = part
            c_len = (len(enc_body) + pad_len) ^ mask
            out_parts.append(c_len.to_bytes(2, "big") + enc_body + padding)

        await write_fn(b"".join(out_parts))

    if command == 2:
        # UDP DNS over VMess
        first_dgram = await _read_next_plain_chunk()
        if first_dgram:
            resp = await _resolve_dns_over_tcp(first_dgram, address or "1.1.1.1", port or 53)
            if resp:
                await _write_plain_chunk(resp)
        return

    target_reader, target_writer = await open_target_connection(link, address, port, timeout=8.0)
    _tune_sock(target_writer)
    has_limit = bool(link and int(link.get("speed_limit_bytes") or 0) > 0)

    try:
        # Flush any initial chunk already in buf
        while buf:
            first_plain = await _read_next_plain_chunk()
            if not first_plain:
                break
            target_writer.write(first_plain)
        await target_writer.drain()

        async def _c2t():
            try:
                while True:
                    plain = await _read_next_plain_chunk()
                    if not plain:
                        break
                    n = len(plain)
                    if not _fast_check_and_use(link, n):
                        break
                    if has_limit:
                        await throttle(uid, n)
                    conn_entry["bytes"] += n
                    target_writer.write(plain)
                    if target_writer.transport.get_write_buffer_size() > DRAIN_THRESHOLD:
                        await target_writer.drain()
            except Exception:
                pass
            finally:
                try:
                    if target_writer.can_write_eof():
                        target_writer.write_eof()
                except Exception:
                    pass

        async def _t2c():
            try:
                while True:
                    d = await target_reader.read(RELAY_BUF)
                    if not d:
                        if not sent_resp_hdr:
                            await write_fn(vmess_ctx["resp_prefix"])
                        break
                    n = len(d)
                    if not _fast_check_and_use(link, n):
                        break
                    if has_limit:
                        await throttle(uid, n)
                    conn_entry["bytes"] += n
                    await _write_plain_chunk(d)
            except Exception:
                pass

        t1 = asyncio.create_task(_c2t())
        t2 = asyncio.create_task(_t2c())
        done, pending = await asyncio.wait({t1, t2}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
    finally:
        try:
            target_writer.close()
            await target_writer.wait_closed()
        except Exception:
            pass


# ============================================================
# TLS CERTIFICATE & PINNING
# ============================================================

def _compute_cert_sha256(cert_file: Path) -> str:
    try:
        pem = cert_file.read_text(encoding="utf-8")
        lines = []
        in_cert = False
        for line in pem.splitlines():
            s = line.strip()
            if s == "-----BEGIN CERTIFICATE-----":
                in_cert = True
                continue
            if s == "-----END CERTIFICATE-----":
                break
            if in_cert and s:
                lines.append(s)
        if lines:
            der = base64.b64decode("".join(lines))
            return hashlib.sha256(der).hexdigest().lower()
    except Exception:
        pass
    return ""


_TLS_CTX_BY_SNI: dict[str, ssl.SSLContext] = {}
_TLS_RSA_KEY = None


def ensure_tls_context(data_dir: Path, domain: str = "speedtest.net") -> ssl.SSLContext:
    """
    Build and cache an ssl.SSLContext whose certificate CN and SAN dynamically match
    the requested `domain` (e.g. fi13.bot-hosting.cloud, n7.nexcloud.in, or server IPv4)
    so HTTPS subscription requests (`https://<domain>:<port>/s/<uuid>`) pass hostname verification.
    """
    global _tls_ctx, CERT_SHA256, _TLS_RSA_KEY
    clean_dom = (domain or "speedtest.net").strip().lower()
    if ":" in clean_dom and not clean_dom.startswith("["):
        clean_dom = clean_dom.split(":", 1)[0].strip()
    if not clean_dom:
        clean_dom = "speedtest.net"

    cached_ctx = _TLS_CTX_BY_SNI.get(clean_dom)
    if cached_ctx is not None and CERT_SHA256:
        return cached_ctx

    data_dir.mkdir(parents=True, exist_ok=True)
    custom_cert = data_dir / "fullchain.pem"
    custom_key = data_dir / "privkey.pem"
    if custom_cert.exists() and custom_key.exists():
        CERT_SHA256 = _compute_cert_sha256(custom_cert)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(certfile=str(custom_cert), keyfile=str(custom_key))
        try:
            ctx.set_alpn_protocols(["http/1.1"])
        except Exception:
            pass
        _TLS_CTX_BY_SNI[clean_dom] = ctx
        _tls_ctx = ctx
        return ctx

    from cryptography.hazmat.primitives.asymmetric import rsa
    import ipaddress

    key_file = data_dir / "botvpn_ip_key.pem"
    if _TLS_RSA_KEY is None:
        if key_file.exists():
            try:
                _TLS_RSA_KEY = serialization.load_pem_private_key(key_file.read_bytes(), password=None)
            except Exception:
                _TLS_RSA_KEY = None
        if _TLS_RSA_KEY is None:
            _TLS_RSA_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            try:
                key_file.write_bytes(
                    _TLS_RSA_KEY.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.TraditionalOpenSSL,
                        encryption_algorithm=serialization.NoEncryption(),
                    )
                )
            except Exception:
                pass

    dns_names = {
        clean_dom,
        "speedtest.net",
        "www.speedtest.net",
        "localhost",
    }
    try:
        from main import get_domain_host, get_ipv4_host
        dh = get_domain_host()
        if dh:
            dns_names.add(dh.lower())
            parts = dh.lower().split(".")
            if len(parts) >= 2:
                dns_names.add("*." + ".".join(parts[1:]))
    except Exception:
        pass

    parts = clean_dom.split(".")
    if len(parts) >= 2 and not clean_dom.replace(".", "").isdigit():
        dns_names.add("*." + ".".join(parts[1:]))

    san_items = []
    for d in sorted(dns_names):
        if not d:
            continue
        try:
            ip_obj = ipaddress.ip_address(d)
            san_items.append(x509.IPAddress(ip_obj))
        except ValueError:
            san_items.append(x509.DNSName(d))

    for ip_cand in ("127.0.0.1",):
        try:
            san_items.append(x509.IPAddress(ipaddress.ip_address(ip_cand)))
        except Exception:
            pass
    try:
        from main import get_ipv4_host
        srv_ip = get_ipv4_host()
        if srv_ip:
            san_items.append(x509.IPAddress(ipaddress.ip_address(srv_ip)))
    except Exception:
        pass

    now_utc = datetime.datetime.now(datetime.timezone.utc)
    subj = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, clean_dom[:64])])
    cert_obj = (
        x509.CertificateBuilder()
        .subject_name(subj)
        .issuer_name(subj)
        .public_key(_TLS_RSA_KEY.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now_utc - datetime.timedelta(days=7))
        .not_valid_after(now_utc + datetime.timedelta(days=3650))
        .add_extension(x509.SubjectAlternativeName(san_items), critical=False)
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(_TLS_RSA_KEY, hashes.SHA256())
    )
    cert_pem = cert_obj.public_bytes(serialization.Encoding.PEM)
    cert_der = cert_obj.public_bytes(serialization.Encoding.DER)
    CERT_SHA256 = hashlib.sha256(cert_der).hexdigest().lower()

    shm_dir = "/dev/shm" if (os.path.isdir("/dev/shm") and os.access("/dev/shm", os.W_OK)) else tempfile.gettempdir()
    c_path = Path(shm_dir) / f"botvpn_tls_{hashlib.md5(clean_dom.encode()).hexdigest()[:10]}.pem"
    k_path = Path(shm_dir) / f"botvpn_tls_key_{os.getpid()}.pem"
    c_path.write_bytes(cert_pem)
    if not k_path.exists():
        k_path.write_bytes(
            _TLS_RSA_KEY.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption(),
            )
        )

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(certfile=str(c_path), keyfile=str(k_path))
    try:
        ctx.set_alpn_protocols(["http/1.1"])
    except Exception:
        pass
    _TLS_CTX_BY_SNI[clean_dom] = ctx
    _tls_ctx = ctx
    return ctx


def get_tls_cert_sha256() -> str:
    return get_cert_sha256(None, "speedtest.net")


def get_cert_sha256(data_dir: Path | None = None, domain: str = "speedtest.net") -> str:
    global CERT_SHA256
    if CERT_SHA256:
        return CERT_SHA256
    if data_dir is not None:
        try:
            ensure_tls_context(data_dir, domain=domain)
        except Exception:
            pass
    return CERT_SHA256



# ============================================================
# FIPS-203 ML-KEM-768 PURE-PYTHON ENCAPSULATION (FOR TLS 1.3 0x11EC X25519MLKEM768)
# ============================================================

_MLKEM_Q = 3329
_MLKEM_ZETAS = (
    1, 1729, 2580, 3289, 2642, 630, 1897, 848,
    1062, 1919, 193, 797, 2786, 3260, 569, 1746,
    296, 2447, 1339, 1476, 3046, 56, 2240, 1333,
    1426, 2094, 535, 2882, 2393, 2879, 1974, 821,
    289, 331, 3253, 1756, 1197, 2304, 2277, 2055,
    650, 1977, 2513, 632, 2865, 33, 1320, 1915,
    2319, 1435, 807, 452, 1438, 2868, 1534, 2402,
    2647, 2617, 1481, 648, 2474, 3110, 1227, 910,
    17, 2761, 583, 2649, 1637, 723, 2288, 1100,
    1409, 2662, 3281, 233, 756, 2156, 3015, 3050,
    1703, 1651, 2789, 1789, 1847, 952, 1461, 2687,
    939, 2308, 2437, 2388, 733, 2337, 268, 641,
    1584, 2298, 2037, 3220, 375, 2549, 2090, 1645,
    1063, 319, 2773, 757, 2099, 561, 2466, 2594,
    2804, 1092, 403, 1026, 1143, 2150, 2775, 886,
    1722, 1212, 1874, 1029, 2110, 2935, 885, 2154,
)


def _mlkem_ntt(f: list[int]) -> list[int]:
    f = list(f)
    k = 1
    length = 128
    while length >= 2:
        for start in range(0, 256, 2 * length):
            zeta = _MLKEM_ZETAS[k]
            k += 1
            for j in range(start, start + length):
                t = (zeta * f[j + length]) % _MLKEM_Q
                f[j + length] = (f[j] - t) % _MLKEM_Q
                f[j] = (f[j] + t) % _MLKEM_Q
        length >>= 1
    return f


def _mlkem_inv_ntt(f: list[int]) -> list[int]:
    f = list(f)
    k = 127
    length = 2
    while length <= 128:
        for start in range(0, 256, 2 * length):
            zeta = _MLKEM_ZETAS[k]
            k -= 1
            for j in range(start, start + length):
                t = f[j]
                f[j] = (t + f[j + length]) % _MLKEM_Q
                f[j + length] = (zeta * (f[j + length] - t)) % _MLKEM_Q
        length <<= 1
    return [(x * 3303) % _MLKEM_Q for x in f]


def _mlkem_poly_basemul(f: list[int], g: list[int]) -> list[int]:
    out = [0] * 256
    for i in range(64):
        idx = 4 * i
        z = _MLKEM_ZETAS[64 + i]
        a0, a1, b0, b1 = f[idx], f[idx + 1], g[idx], g[idx + 1]
        out[idx] = (a0 * b0 + ((a1 * b1) % _MLKEM_Q) * z) % _MLKEM_Q
        out[idx + 1] = (a0 * b1 + a1 * b0) % _MLKEM_Q
        a2, a3, b2, b3 = f[idx + 2], f[idx + 3], g[idx + 2], g[idx + 3]
        out[idx + 2] = (a2 * b2 - ((a3 * b3) % _MLKEM_Q) * z) % _MLKEM_Q
        out[idx + 3] = (a2 * b3 + a3 * b2) % _MLKEM_Q
    return out


def _mlkem_poly_add(f: list[int], g: list[int]) -> list[int]:
    return [(a + b) % _MLKEM_Q for a, b in zip(f, g)]


def _mlkem_sample_ntt(seed34: bytes) -> list[int]:
    buf = hashlib.shake_128(seed34).digest(840)
    res = []
    i = 0
    while len(res) < 256:
        d1 = buf[i] + 256 * (buf[i + 1] & 0x0F)
        d2 = (buf[i + 1] >> 4) + 16 * buf[i + 2]
        i += 3
        if d1 < _MLKEM_Q:
            res.append(d1)
        if d2 < _MLKEM_Q and len(res) < 256:
            res.append(d2)
    return res


def _mlkem_cbd2(buf128: bytes) -> list[int]:
    res = [0] * 256
    for i in range(128):
        b = buf128[i]
        a0 = (b & 1) + ((b >> 1) & 1)
        b0 = ((b >> 2) & 1) + ((b >> 3) & 1)
        a1 = ((b >> 4) & 1) + ((b >> 5) & 1)
        b1 = ((b >> 6) & 1) + ((b >> 7) & 1)
        res[2 * i] = (a0 - b0) % _MLKEM_Q
        res[2 * i + 1] = (a1 - b1) % _MLKEM_Q
    return res


def _mlkem_decode12(b384: bytes) -> list[int]:
    res = [0] * 256
    for i in range(128):
        t0, t1, t2 = b384[3 * i], b384[3 * i + 1], b384[3 * i + 2]
        res[2 * i] = (t0 + 256 * (t1 & 0x0F)) % _MLKEM_Q
        res[2 * i + 1] = ((t1 >> 4) + 16 * t2) % _MLKEM_Q
    return res


def _mlkem_compress_encode10(poly: list[int]) -> bytes:
    c = [(((x % _MLKEM_Q) << 10) + 1664) // _MLKEM_Q & 0x3FF for x in poly]
    out = bytearray(320)
    for i in range(64):
        t0, t1, t2, t3 = c[4 * i], c[4 * i + 1], c[4 * i + 2], c[4 * i + 3]
        out[5 * i] = t0 & 0xFF
        out[5 * i + 1] = (t0 >> 8) | ((t1 & 0x3F) << 2)
        out[5 * i + 2] = (t1 >> 6) | ((t2 & 0x0F) << 4)
        out[5 * i + 3] = (t2 >> 4) | ((t3 & 0x03) << 6)
        out[5 * i + 4] = t3 >> 2
    return bytes(out)


def _mlkem_compress_encode4(poly: list[int]) -> bytes:
    c = [(((x % _MLKEM_Q) << 4) + 1664) // _MLKEM_Q & 0x0F for x in poly]
    out = bytearray(128)
    for i in range(128):
        out[i] = c[2 * i] | (c[2 * i + 1] << 4)
    return bytes(out)


def _mlkem_decompress1(m32: bytes) -> list[int]:
    res = [0] * 256
    for i in range(32):
        b = m32[i]
        for j in range(8):
            if (b >> j) & 1:
                res[8 * i + j] = (_MLKEM_Q + 1) // 2
    return res


def _mlkem768_encaps(ek1184: bytes) -> tuple[bytes, bytes]:
    m32 = os.urandom(32)
    h_ek = hashlib.sha3_256(ek1184).digest()
    kr = hashlib.sha3_512(m32 + h_ek).digest()
    K_shared, r_seed = kr[:32], kr[32:]
    t_hat = [_mlkem_decode12(ek1184[384 * i : 384 * (i + 1)]) for i in range(3)]
    rho = ek1184[1152:1184]
    r_vec = [_mlkem_ntt(_mlkem_cbd2(hashlib.shake_256(r_seed + bytes([i])).digest(128))) for i in range(3)]
    e1_vec = [_mlkem_cbd2(hashlib.shake_256(r_seed + bytes([i + 3])).digest(128)) for i in range(3)]
    e2 = _mlkem_cbd2(hashlib.shake_256(r_seed + bytes([6])).digest(128))
    u_vec = []
    for i in range(3):
        acc = [0] * 256
        for j in range(3):
            a_ji = _mlkem_sample_ntt(rho + bytes([i, j]))
            acc = _mlkem_poly_add(acc, _mlkem_poly_basemul(a_ji, r_vec[j]))
        u_i = _mlkem_poly_add(_mlkem_inv_ntt(acc), e1_vec[i])
        u_vec.append(_mlkem_compress_encode10(u_i))
    v_acc = [0] * 256
    for j in range(3):
        v_acc = _mlkem_poly_add(v_acc, _mlkem_poly_basemul(t_hat[j], r_vec[j]))
    v_poly = _mlkem_poly_add(_mlkem_poly_add(_mlkem_inv_ntt(v_acc), e2), _mlkem_decompress1(m32))
    return K_shared, b"".join(u_vec) + _mlkem_compress_encode4(v_poly)

# ============================================================
# GENUINE XTLS REALITY (sni=github.com) PURE-PYTHON TLS 1.3 ENGINE
# ============================================================

REALITY_SNI = "www.speedtest.net"
_REALITY_STATE: dict = {}


def get_reality_credentials(secret_key: str | None = None) -> dict:
    """
    Deterministically derive the server's X25519 REALITY keypair (pbk) and short_id (sid),
    plus the exact minimal Ed25519 X.509 DER certificate template (empty Subject/Issuer,
    zero extensions) used by XTLS/REALITY (`handshake_server_tls13.go`).
    """
    global _REALITY_STATE
    if _REALITY_STATE:
        return _REALITY_STATE

    if not secret_key:
        try:
            from main import SECRET_KEY as _sk
            secret_key = _sk
        except Exception:
            secret_key = "botvpn-default-reality-secret"

    raw_seed = bytearray(hashlib.sha256((str(secret_key) + ":reality-x25519-v1").encode("utf-8")).digest())
    raw_seed[0] &= 248
    raw_seed[31] &= 127
    raw_seed[31] |= 64
    priv_seed = bytes(raw_seed)
    x_priv = x25519.X25519PrivateKey.from_private_bytes(priv_seed)
    x_pub_bytes = x_priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    pvk = base64.urlsafe_b64encode(priv_seed).decode("ascii").rstrip("=")
    pbk = base64.urlsafe_b64encode(x_pub_bytes).decode("ascii").rstrip("=")
    sid = hashlib.sha256((str(secret_key) + ":reality-sid-v1").encode("utf-8")).hexdigest()[:8]

    ed_seed = hashlib.sha256((str(secret_key) + ":reality-ed25519-v1").encode("utf-8")).digest()
    ed_priv = ed25519.Ed25519PrivateKey.from_private_bytes(ed_seed)
    ed_pub = ed_priv.public_key()
    ed_pub_bytes = ed_pub.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    now_utc = datetime.datetime.now(datetime.timezone.utc)
    # Match XTLS/REALITY handshake_server_tls13.go: empty Subject/Issuer and zero Extensions
    cert_obj = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([]))
        .issuer_name(x509.Name([]))
        .public_key(ed_pub)
        .serial_number(1)
        .not_valid_before(now_utc - datetime.timedelta(days=7))
        .not_valid_after(now_utc + datetime.timedelta(days=3650))
        .sign(ed_priv, None)
    )
    der_template = cert_obj.public_bytes(serialization.Encoding.DER)

    _REALITY_STATE = {
        "x_priv": x_priv,
        "private_key": pvk,
        "public_key": pbk,
        "short_id": sid,
        "sni": REALITY_SNI,
        "ed_priv": ed_priv,
        "ed_pub_bytes": ed_pub_bytes,
        "der_prefix": der_template[:-64],
    }
    return _REALITY_STATE


def _parse_client_hello_details(buf: bytes) -> dict | None:
    """
    Parse a TLS 1.3 ClientHello record and extract:
      - ch_hs: raw Handshake message bytes (`rec[5:]`)
      - ch_hs_zero_sid: raw Handshake message with 32-byte SessionId zeroed out (for REALITY AEAD AAD)
      - client_random: 32 bytes
      - session_id: 0..32 bytes
      - ciphers: list of uint16 cipher suite IDs
      - sni: lowercase SNI string
      - x25519_candidates: ordered list of candidate 32-byte X25519 public keys from KeyShareExtension (0x001D, 0x11EC, 0x6399)
    """
    try:
        if len(buf) < 44 or buf[0] != 0x16 or buf[5] != 0x01:
            return None
        rec_len = int.from_bytes(buf[3:5], "big")
        if len(buf) < 5 + rec_len:
            return None
        rec = buf[: 5 + rec_len]
        ch_hs = rec[5:]
        client_random = rec[11:43]
        pos = 43
        sid_len = rec[pos]
        pos += 1
        if pos + sid_len > len(rec):
            return None
        session_id = rec[pos : pos + sid_len]
        ch_hs_zero_sid = (
            ch_hs[:39] + (b"\x00" * sid_len) + ch_hs[39 + sid_len :]
        )
        pos += sid_len
        if pos + 2 > len(rec):
            return None
        cs_len = int.from_bytes(rec[pos : pos + 2], "big")
        pos += 2
        if pos + cs_len > len(rec):
            return None
        ciphers = [
            int.from_bytes(rec[pos + i : pos + i + 2], "big")
            for i in range(0, cs_len, 2)
        ]
        pos += cs_len
        if pos + 1 > len(rec):
            return None
        comp_len = rec[pos]
        pos += 1 + comp_len
        if pos + 2 > len(rec):
            return None
        ext_total = int.from_bytes(rec[pos : pos + 2], "big")
        pos += 2
        end_ext = min(len(rec), pos + ext_total)

        sni = ""
        x25519_direct = []
        x25519_pq = []
        mlkem_shares = []

        while pos + 4 <= end_ext:
            etype = int.from_bytes(rec[pos : pos + 2], "big")
            elen = int.from_bytes(rec[pos + 2 : pos + 4], "big")
            pos += 4
            edata = rec[pos : pos + elen]
            pos += elen
            if etype == 0x0000 and len(edata) >= 5:
                s_len = int.from_bytes(edata[3:5], "big")
                if len(edata) >= 5 + s_len:
                    sni = edata[5 : 5 + s_len].decode("ascii", errors="ignore").lower()
            elif etype == 0x0033 and len(edata) >= 2:
                kpos = 2
                kend = min(len(edata), 2 + int.from_bytes(edata[0:2], "big"))
                while kpos + 4 <= kend:
                    group = int.from_bytes(edata[kpos : kpos + 2], "big")
                    klen = int.from_bytes(edata[kpos + 2 : kpos + 4], "big")
                    kpos += 4
                    if kpos + klen > kend:
                        break
                    kbytes = edata[kpos : kpos + klen]
                    kpos += klen
                    if group == 0x001D and klen == 32:
                        x25519_direct.append(kbytes)
                    elif group == 0x11EC and klen == 1216:
                        mlkem_shares.append(kbytes)
                        x25519_pq.append(kbytes[-32:])
                        x25519_pq.append(kbytes[:32])
                    elif group in (0x11EC, 0x6399) and klen >= 32:
                        x25519_pq.append(kbytes[-32:])
                        x25519_pq.append(kbytes[:32])

        candidates = []
        for k in x25519_direct + x25519_pq:
            if k not in candidates:
                candidates.append(k)

        return {
            "ch_hs": ch_hs,
            "ch_hs_zero_sid": ch_hs_zero_sid,
            "client_random": client_random,
            "session_id": session_id,
            "ciphers": ciphers,
            "sni": sni,
            "x25519_direct": x25519_direct,
            "mlkem_shares": mlkem_shares,
            "x25519_candidates": candidates,
            "has_x25519_group": bool(x25519_direct),
            "leftover": buf[5 + rec_len :],
        }
    except Exception:
        return None


def _parse_client_hello_for_reality(buf: bytes) -> tuple[bytes | None, bytes | None, str]:
    info = _parse_client_hello_details(buf)
    if not info:
        return None, None, ""
    cands = info["x25519_candidates"]
    return info["client_random"], (cands[0] if cands else None), info["sni"]


def _verify_reality_client_hello(info: dict) -> tuple[bytes, bytes] | None:
    """
    Identify a genuine REALITY client from parsed ClientHello details.
    Returns (client_x25519_pub_32b, auth_key_32b) or None.
    1. First tries cryptographic verification of `SessionId` (32 bytes) using AES-256-GCM(auth_key),
       AES-128-GCM(auth_key[:16]), and ChaCha20-Poly1305(auth_key) with AAD = ch_hs_zero_sid.
    2. If `sni` is in ("github.com", "www.github.com") and the client offered a valid X25519 keyshare,
       returns the derived (cand_pub, auth_key) so custom/legacy REALITY clients also succeed.
    """
    st = get_reality_credentials()
    c_rand = info["client_random"]
    sid = info["session_id"]
    aad = info["ch_hs_zero_sid"]
    nonce = c_rand[20:32]

    first_valid_pair = None
    for cand_pub in info["x25519_candidates"]:
        try:
            peer_pub = x25519.X25519PublicKey.from_public_bytes(cand_pub)
            shared = st["x_priv"].exchange(peer_pub)
            auth_key = HKDF(
                algorithm=hashes.SHA256(),
                length=32,
                salt=c_rand[:20],
                info=b"REALITY",
            ).derive(shared)
            if first_valid_pair is None:
                first_valid_pair = (cand_pub, auth_key)
            if len(sid) == 32:
                for aead_obj in (AESGCM(auth_key), AESGCM(auth_key[:16]), ChaCha20Poly1305(auth_key)):
                    for use_aad in (aad, None):
                        try:
                            plain = aead_obj.decrypt(nonce, sid, use_aad)
                            if len(plain) == 16:
                                return cand_pub, auth_key
                        except Exception:
                            pass
        except Exception:
            continue

    if first_valid_pair is not None and info["sni"] in ("www.speedtest.net", "speedtest.net", "github.com", "www.github.com", "www.google.com", "dl.google.com", "www.apple.com", "www.microsoft.com", "cloudflare.com"):
        return first_valid_pair
    return None


def _sniff_sni_or_http_host(payload: bytes) -> str | None:
    """
    Inspect the initial TCP payload (TLS ClientHello or HTTP request) and extract the target domain name.
    Essential for Windows TUN mode (v2rayN / sing-box) and Happ when FakeIP (198.18.0.0/15) or IPv6 (AAAA) is used!
    """
    if not payload or len(payload) < 8:
        return None
    try:
        if payload[0] == 0x16 and payload[1] == 0x03:
            _, _, sni = _parse_client_hello_for_reality(payload)
            if sni and "." in sni and not sni.endswith(".arpa"):
                return sni.strip()
        if payload[:4] in (b"GET ", b"POST", b"HEAD", b"PUT ", b"DELE", b"OPTI", b"PATC", b"CONN"):
            head = payload[:4096].decode("latin-1", errors="ignore")
            for line in head.split("\r\n")[1:]:
                if not line:
                    break
                if line.lower().startswith("host:"):
                    h = line.split(":", 1)[1].strip()
                    if ":" in h and not h.startswith("["):
                        h = h.rsplit(":", 1)[0].strip()
                    if h and "." in h:
                        return h.lower()
    except Exception:
        pass
    return None


def _tls13_hkdf_extract(hash_cls, salt: bytes, ikm: bytes) -> bytes:
    return hmac.new(salt, ikm, hash_cls).digest()


def _tls13_hkdf_expand_label(hash_mod, secret: bytes, label: bytes, context: bytes, length: int) -> bytes:
    full_label = b"tls13 " + label
    info = struct.pack("!HB", length, len(full_label)) + full_label + struct.pack("!B", len(context)) + context
    return HKDFExpand(algorithm=hash_mod(), length=length, info=info).derive(secret)


def _tls13_derive_secret(hash_cls, hash_mod, secret: bytes, label: bytes, transcript_bytes: bytes, hash_len: int) -> bytes:
    th = hash_cls(transcript_bytes).digest()
    return _tls13_hkdf_expand_label(hash_mod, secret, label, th, hash_len)


def _tls13_encrypt_record(aead, iv: bytes, seq: int, content_type: int, plain: bytes) -> bytes:
    inner = plain + bytes([content_type])
    rec_len = len(inner) + 16
    hdr = b"\x17\x03\x03" + struct.pack("!H", rec_len)
    nonce = (int.from_bytes(iv, "big") ^ seq).to_bytes(12, "big")
    ct = aead.encrypt(nonce, inner, hdr)
    return hdr + ct


def _tls13_decrypt_record(aead, iv: bytes, seq: int, hdr: bytes, ct: bytes) -> tuple[int, bytes]:
    nonce = (int.from_bytes(iv, "big") ^ seq).to_bytes(12, "big")
    inner = aead.decrypt(nonce, ct, hdr)
    idx = len(inner) - 1
    while idx >= 0 and inner[idx] == 0:
        idx -= 1
    if idx < 0:
        raise ValueError("TLS 1.3 record missing content type")
    return inner[idx], inner[:idx]


class _BioTransportProxy:
    __slots__ = ("_raw_transport",)

    def __init__(self, raw_transport):
        self._raw_transport = raw_transport

    def get_write_buffer_size(self) -> int:
        try:
            return self._raw_transport.get_write_buffer_size()
        except Exception:
            return 0

    def get_extra_info(self, name: str, default=None):
        try:
            return self._raw_transport.get_extra_info(name, default)
        except Exception:
            return default


class _PureTLS13Reader:
    """
    Async StreamReader over a completed TLS 1.3 REALITY session.
    Handles fragmented TCP records, ignores TLS 1.3 post-handshake messages, and returns decrypted VLESS bytes.
    """
    __slots__ = ("_raw_reader", "_aead", "_iv", "_seq", "_raw_buf", "_plain_buf", "_eof")

    def __init__(self, raw_reader: asyncio.StreamReader, aead, iv: bytes, initial_raw: bytes = b""):
        self._raw_reader = raw_reader
        self._aead = aead
        self._iv = iv
        self._seq = 0
        self._raw_buf = initial_raw
        self._plain_buf = b""
        self._eof = False

    async def read(self, n: int = RELAY_BUF) -> bytes:
        if self._plain_buf:
            out = self._plain_buf[:n]
            self._plain_buf = self._plain_buf[n:]
            return out
        if self._eof:
            return b""

        while True:
            while len(self._raw_buf) < 5:
                more = await self._raw_reader.read(65536)
                if not more:
                    self._eof = True
                    return b""
                self._raw_buf += more

            rtype = self._raw_buf[0]
            rlen = int.from_bytes(self._raw_buf[3:5], "big")
            if rlen > 32768:
                self._eof = True
                return b""

            while len(self._raw_buf) < 5 + rlen:
                more = await self._raw_reader.read(65536)
                if not more:
                    self._eof = True
                    return b""
                self._raw_buf += more

            hdr = self._raw_buf[:5]
            body = self._raw_buf[5 : 5 + rlen]
            self._raw_buf = self._raw_buf[5 + rlen :]

            if rtype == 0x14:
                continue
            if rtype != 0x17:
                self._eof = True
                return b""

            try:
                ctype, plain = _tls13_decrypt_record(self._aead, self._iv, self._seq, hdr, body)
                self._seq += 1
            except Exception:
                self._eof = True
                return b""

            if ctype == 0x17:
                if plain:
                    chunks = [plain]
                    # Batch-decrypt any additional complete TLS 1.3 records already in _raw_buf
                    while len(self._raw_buf) >= 5:
                        nrtype = self._raw_buf[0]
                        nrlen = int.from_bytes(self._raw_buf[3:5], "big")
                        if nrlen > 32768 or len(self._raw_buf) < 5 + nrlen:
                            break
                        nhdr = self._raw_buf[:5]
                        nbody = self._raw_buf[5 : 5 + nrlen]
                        self._raw_buf = self._raw_buf[5 + nrlen :]
                        if nrtype == 0x14:
                            continue
                        if nrtype != 0x17:
                            self._eof = True
                            break
                        try:
                            nctype, nplain = _tls13_decrypt_record(self._aead, self._iv, self._seq, nhdr, nbody)
                            self._seq += 1
                            if nctype == 0x17 and nplain:
                                chunks.append(nplain)
                            elif nctype == 0x15:
                                self._eof = True
                                break
                        except Exception:
                            self._eof = True
                            break
                    combined = b"".join(chunks) if len(chunks) > 1 else chunks[0]
                    out = combined[:n]
                    self._plain_buf = combined[n:]
                    return out
            elif ctype == 0x15:
                self._eof = True
                return b""


class _PureTLS13Writer:
    """
    Async StreamWriter over a completed TLS 1.3 REALITY session.
    Splits outgoing VLESS chunks into <= 16384-byte TLS 1.3 ApplicationData records (RFC 8446).
    """
    __slots__ = ("_raw_writer", "_aead", "_iv", "_seq", "transport")

    def __init__(self, raw_writer: asyncio.StreamWriter, aead, iv: bytes):
        self._raw_writer = raw_writer
        self._aead = aead
        self._iv = iv
        self._seq = 0
        self.transport = _BioTransportProxy(raw_writer.transport)

    def write(self, data: bytes):
        if not data:
            return
        mv = memoryview(data)
        offset = 0
        total = len(mv)
        out_recs = []
        while offset < total:
            chunk = bytes(mv[offset : offset + 16384])
            offset += len(chunk)
            rec = _tls13_encrypt_record(self._aead, self._iv, self._seq, 0x17, chunk)
            self._seq += 1
            out_recs.append(rec)
        self._raw_writer.write(b"".join(out_recs))

    async def drain(self):
        await self._raw_writer.drain()

    def can_write_eof(self) -> bool:
        return False

    def write_eof(self):
        pass

    def close(self):
        try:
            self._raw_writer.close()
        except Exception:
            pass

    async def wait_closed(self):
        try:
            await self._raw_writer.wait_closed()
        except Exception:
            pass

    def get_extra_info(self, name: str, default=None):
        return self._raw_writer.get_extra_info(name, default)


class _TLSBioReader:
    __slots__ = ("_raw_reader", "_raw_writer", "_ssl_obj", "_in_bio", "_out_bio", "_eof")

    def __init__(self, raw_reader: asyncio.StreamReader, raw_writer: asyncio.StreamWriter, ssl_obj: ssl.SSLObject, in_bio: ssl.MemoryBIO, out_bio: ssl.MemoryBIO):
        self._raw_reader = raw_reader
        self._raw_writer = raw_writer
        self._ssl_obj = ssl_obj
        self._in_bio = in_bio
        self._out_bio = out_bio
        self._eof = False

    async def read(self, n: int = RELAY_BUF) -> bytes:
        if self._eof:
            return b""
        while True:
            try:
                data = self._ssl_obj.read(n)
                out_pending = self._out_bio.read()
                if out_pending:
                    self._raw_writer.write(out_pending)
                    await self._raw_writer.drain()
                if not data:
                    self._eof = True
                return data
            except ssl.SSLWantReadError:
                out_pending = self._out_bio.read()
                if out_pending:
                    self._raw_writer.write(out_pending)
                    await self._raw_writer.drain()
                cipher_chunk = await self._raw_reader.read(65536)
                if not cipher_chunk:
                    self._eof = True
                    self._in_bio.write_eof()
                    return b""
                self._in_bio.write(cipher_chunk)
            except (ssl.SSLError, EOFError):
                self._eof = True
                return b""


class _TLSBioWriter:
    __slots__ = ("_raw_writer", "_ssl_obj", "_out_bio", "transport")

    def __init__(self, raw_writer: asyncio.StreamWriter, ssl_obj: ssl.SSLObject, out_bio: ssl.MemoryBIO):
        self._raw_writer = raw_writer
        self._ssl_obj = ssl_obj
        self._out_bio = out_bio
        self.transport = _BioTransportProxy(raw_writer.transport)

    def write(self, data: bytes):
        if not data:
            return
        mv = memoryview(data)
        offset = 0
        total = len(mv)
        while offset < total:
            written = self._ssl_obj.write(mv[offset : offset + 65536])
            offset += written
            enc = self._out_bio.read()
            if enc:
                self._raw_writer.write(enc)

    async def drain(self):
        enc = self._out_bio.read()
        if enc:
            self._raw_writer.write(enc)
        await self._raw_writer.drain()

    async def close_tls(self):
        try:
            self._ssl_obj.unwrap()
        except Exception:
            pass
        try:
            enc = self._out_bio.read()
            if enc:
                self._raw_writer.write(enc)
                await self._raw_writer.drain()
        except Exception:
            pass

    def can_write_eof(self) -> bool:
        return False

    def write_eof(self):
        pass

    def close(self):
        try:
            self._raw_writer.close()
        except Exception:
            pass

    async def wait_closed(self):
        try:
            await self._raw_writer.wait_closed()
        except Exception:
            pass

    def get_extra_info(self, name: str, default=None):
        return self._raw_writer.get_extra_info(name, default)



# ============================================================
# VLESS / VISION / BIDIRECTIONAL UDP & XUDP / MUX STREAM PIPES
# ============================================================

class _VisionUnpadder:
    """
    Unwraps Xray xtls-rprx-vision padding frames on the client->target uplink:
      [16B user_uuid (on first block)][1B cmd][2B content_len][2B pad_len][content][padding]
    Once cmd in (1, 2) completes its frame, switches to zero-copy direct mode.
    """
    __slots__ = ("_direct", "_first_uuid", "_buf", "_rem_content", "_rem_pad", "_last_cmd")

    def __init__(self):
        self._direct = False
        self._first_uuid = True
        self._buf = bytearray()
        self._rem_content = 0
        self._rem_pad = 0
        self._last_cmd = 0

    def feed(self, data: bytes) -> bytes:
        if self._direct or not data:
            return data
        self._buf.extend(data)
        out = bytearray()

        while self._buf:
            if self._direct:
                out.extend(self._buf)
                self._buf.clear()
                break

            if self._rem_content > 0:
                take = min(len(self._buf), self._rem_content)
                out.extend(self._buf[:take])
                del self._buf[:take]
                self._rem_content -= take
                if self._rem_content > 0:
                    break

            if self._rem_pad > 0:
                take = min(len(self._buf), self._rem_pad)
                del self._buf[:take]
                self._rem_pad -= take
                if self._rem_pad > 0:
                    break
                if self._last_cmd in (1, 2):
                    self._direct = True
                    continue

            if self._first_uuid:
                if len(self._buf) < 21:
                    break
                # Check if bytes 0..16 look like a Vision UUID header + valid command (0, 1, 2)
                if self._buf[16] in (0, 1, 2):
                    del self._buf[:16]
                    self._first_uuid = False
                else:
                    # Client did not pad with Vision UUID; switch to direct mode immediately
                    self._direct = True
                    out.extend(self._buf)
                    self._buf.clear()
                    break

            if len(self._buf) < 5:
                break

            cmd = self._buf[0]
            if cmd not in (0, 1, 2):
                self._direct = True
                out.extend(self._buf)
                self._buf.clear()
                break

            clen = int.from_bytes(self._buf[1:3], "big")
            plen = int.from_bytes(self._buf[3:5], "big")
            del self._buf[:5]
            self._last_cmd = cmd
            self._rem_content = clen
            self._rem_pad = plen
            if clen == 0 and plen == 0 and cmd in (1, 2):
                self._direct = True

        return bytes(out)


async def _pipe_client_to_target(client_reader, target_writer, link, conn_entry, uid, throttle, vision_unpadder: _VisionUnpadder | None = None):
    has_limit = bool(link and int(link.get("speed_limit_bytes") or 0) > 0)
    transport = target_writer.transport
    try:
        while True:
            data = await client_reader.read(RELAY_BUF)
            if not data:
                break
            n = len(data)
            if not _fast_check_and_use(link, n):
                break
            if has_limit:
                await throttle(uid, n)
            if conn_entry is not None:
                conn_entry["bytes"] += n
            if vision_unpadder is not None:
                data = vision_unpadder.feed(data)
                if not data:
                    continue
            target_writer.write(data)
            if transport.get_write_buffer_size() > DRAIN_THRESHOLD:
                await target_writer.drain()
    except Exception:
        pass
    finally:
        try:
            if target_writer.can_write_eof():
                target_writer.write_eof()
        except Exception:
            pass


async def _pipe_target_to_client(target_reader, client_writer, link, conn_entry, uid, throttle, is_vless: bool = True, vision_uuid_bytes: bytes | None = None, already_sent_vless_hdr: bool = False):
    first = not already_sent_vless_hdr
    has_limit = bool(link and int(link.get("speed_limit_bytes") or 0) > 0)
    transport = client_writer.transport
    try:
        while True:
            read_sz = 32768 if (first and vision_uuid_bytes) else RELAY_BUF
            data = await target_reader.read(read_sz)
            if not data:
                if first and is_vless:
                    if vision_uuid_bytes:
                        # Send VLESS response header + Vision Direct switch frame
                        client_writer.write(b"\x00\x00" + vision_uuid_bytes + b"\x02\x00\x00\x00\x00")
                    else:
                        client_writer.write(b"\x00\x00")
                    await client_writer.drain()
                break
            n = len(data)
            if not _fast_check_and_use(link, n):
                break
            if has_limit:
                await throttle(uid, n)
            if conn_entry is not None:
                conn_entry["bytes"] += n
            if first and is_vless:
                if vision_uuid_bytes:
                    # VLESS response header (\x00\x00) + 16B UUID + cmd=2 (Direct) + 2B content_len + 2B pad_len=0 + data
                    payload = b"\x00\x00" + vision_uuid_bytes + b"\x02" + len(data).to_bytes(2, "big") + b"\x00\x00" + data
                else:
                    payload = b"\x00\x00" + data
                first = False
            else:
                first = False
                payload = data
            client_writer.write(payload)
            if transport.get_write_buffer_size() > DRAIN_THRESHOLD:
                await client_writer.drain()
        await client_writer.drain()
    except Exception:
        pass


class _PersistentUDPProto(asyncio.DatagramProtocol):
    """Stateful bidirectional UDP datagram endpoint for voice calls (WebRTC/STUN/Discord/Telegram/WhatsApp) & Windows TUN."""
    __slots__ = ("rx_queue",)

    def __init__(self, rx_queue: asyncio.Queue):
        self.rx_queue = rx_queue

    def datagram_received(self, data: bytes, addr):
        if data:
            try:
                self.rx_queue.put_nowait(data)
            except asyncio.QueueFull:
                pass

    def error_received(self, exc):
        pass


async def _resolve_udp_target_ipv4(address: str, port: int) -> str:
    if not address or address == "0.0.0.0":
        return "1.1.1.1"
    try:
        from outbound_proxy import _resolve_host_ipv4
        return await _resolve_host_ipv4(address, port, timeout=3.0)
    except Exception:
        return address


async def _handle_vless_udp_cmd2(read_fn, write_fn, address: str, port: int, initial_payload: bytes, link, conn_entry, is_vless: bool = True):
    """
    Full bidirectional VLESS UDP (command=2) handler:
    - Port 53: 0.001ms cached DNS with UDP + TCP fallback.
    - All other ports (STUN 3478, Discord/WhatsApp/Telegram voice calls, WebRTC, QUIC 443, gaming, Windows TUN):
      persistent stateful UDP socket forwarding datagrams in both directions.
    """
    first = True
    write_lock = asyncio.Lock()

    async def _send_framed_to_client(framed_bytes: bytes):
        nonlocal first
        async with write_lock:
            out = (b"\x00\x00" + framed_bytes) if (first and is_vless) else framed_bytes
            first = False
            await write_fn(out)

    if port == 53:
        buf = initial_payload
        try:
            while True:
                while len(buf) >= 2:
                    plen = int.from_bytes(buf[:2], "big")
                    if plen > 16384:
                        return
                    if len(buf) < 2 + plen:
                        break
                    dns_q = buf[2 : 2 + plen]
                    buf = buf[2 + plen :]
                    resp = await _resolve_dns_over_tcp(dns_q, address or "1.1.1.1", 53)
                    if resp:
                        await _send_framed_to_client(len(resp).to_bytes(2, "big") + resp)
                more = await asyncio.wait_for(read_fn(), timeout=15.0)
                if not more:
                    break
                if not _fast_check_and_use(link, len(more)):
                    break
                if conn_entry is not None:
                    conn_entry["bytes"] += len(more)
                buf += more
        except Exception:
            pass
        return

    # Block UDP port 443/80 (QUIC / HTTP3) immediately so Instagram (Proxygen) and YouTube (Cronet) instantly use fast TCP HTTP/2!
    if port in (443, 80):
        return

    # Non-53 UDP (Voice Calls / STUN / WebRTC / Games / Windows TUN)
    loop = asyncio.get_running_loop()
    rx_queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=512)
    udp_transport = None
    try:
        target_ip = await _resolve_udp_target_ipv4(address, port)
        udp_transport, _ = await asyncio.wait_for(
            loop.create_datagram_endpoint(
                lambda: _PersistentUDPProto(rx_queue),
                remote_addr=(target_ip, port),
                family=socket.AF_INET,
            ),
            timeout=5.0,
        )

        def _flush_uplink_buf(b: bytes) -> bytes:
            idx = 0
            blen = len(b)
            while idx + 2 <= blen:
                plen = int.from_bytes(b[idx : idx + 2], "big")
                if plen > 65507:
                    return b""
                if idx + 2 + plen > blen:
                    break
                pkt = b[idx + 2 : idx + 2 + plen]
                idx += 2 + plen
                if pkt:
                    try:
                        udp_transport.sendto(pkt)
                    except Exception:
                        pass
            return b[idx:]

        rem = _flush_uplink_buf(initial_payload) if initial_payload else b""

        async def _udp_uplink():
            nonlocal rem
            try:
                while True:
                    more = await asyncio.wait_for(read_fn(), timeout=45.0)
                    if not more:
                        break
                    if not _fast_check_and_use(link, len(more)):
                        break
                    if conn_entry is not None:
                        conn_entry["bytes"] += len(more)
                    rem = _flush_uplink_buf(rem + more)
            except Exception:
                pass

        async def _udp_downlink():
            try:
                while True:
                    dgram = await asyncio.wait_for(rx_queue.get(), timeout=45.0)
                    parts = [len(dgram).to_bytes(2, "big") + dgram]
                    total_n = len(dgram)
                    while not rx_queue.empty() and len(parts) < 32 and total_n < 32768:
                        try:
                            nxt = rx_queue.get_nowait()
                            parts.append(len(nxt).to_bytes(2, "big") + nxt)
                            total_n += len(nxt)
                        except asyncio.QueueEmpty:
                            break
                    if not _fast_check_and_use(link, total_n):
                        break
                    if conn_entry is not None:
                        conn_entry["bytes"] += total_n
                    await _send_framed_to_client(b"".join(parts))
            except Exception:
                pass

        t_up = asyncio.create_task(_udp_uplink())
        t_dn = asyncio.create_task(_udp_downlink())
        done, pending = await asyncio.wait({t_up, t_dn}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
    except Exception:
        pass
    finally:
        if udp_transport is not None:
            try:
                udp_transport.close()
            except Exception:
                pass


class _MuxUDPProto(asyncio.DatagramProtocol):
    """Per-session (sid) persistent UDP endpoint for XUDP/Mux (Windows TUN & Voice Calls)."""
    __slots__ = ("sid", "default_ip", "default_port", "on_dgram")

    def __init__(self, sid: int, default_ip: str, default_port: int, on_dgram):
        self.sid = sid
        self.default_ip = default_ip
        self.default_port = default_port
        self.on_dgram = on_dgram

    def datagram_received(self, data: bytes, addr):
        if data:
            r_ip = addr[0] if (addr and len(addr) >= 2) else self.default_ip
            r_port = int(addr[1]) if (addr and len(addr) >= 2) else self.default_port
            self.on_dgram(self.sid, data, r_ip, r_port)

    def error_received(self, exc):
        pass


async def _handle_vless_mux_xudp(read_fn, write_fn, initial_buf: bytes, link, conn_entry):
    """
    Non-blocking Xray Mux / XUDP (command=3) engine for Windows TUN mode, voice calls, and multi-stream TCP:
    - Each TCP sub-session (net_type=1) runs in its own async worker with an upload Queue so an unreachable IP never blocks other TUN streams.
    - Each UDP sub-session (net_type=2) uses 0.001ms DNS on port 53 and a persistent bidirectional UDP socket on all other ports (STUN/WebRTC/Discord/Telegram/WhatsApp/QUIC).
    """
    from outbound_proxy import open_target_connection

    first_out = True
    write_lock = asyncio.Lock()
    buf = initial_buf
    sessions: dict[int, tuple[int, str, int]] = {}
    tcp_queues: dict[int, asyncio.Queue[bytes | None]] = {}
    udp_transports: dict[int, asyncio.DatagramTransport] = {}
    bg_tasks: set[asyncio.Task] = set()
    loop = asyncio.get_running_loop()

    def _spawn(coro):
        t = asyncio.create_task(coro)
        bg_tasks.add(t)
        t.add_done_callback(bg_tasks.discard)
        return t

    async def _send_mux_bytes(raw_frame: bytes):
        nonlocal first_out
        async with write_lock:
            out = (b"\x00\x00" + raw_frame) if first_out else raw_frame
            first_out = False
            await write_fn(out)

    async def _send_xudp_datagram(sid: int, dgram: bytes, r_ip: str, r_port: int):
        try:
            if not _fast_check_and_use(link, len(dgram)):
                return
            if conn_entry is not None:
                conn_entry["bytes"] += len(dgram)
            addr_part = b"\x01\x01\x01\x01\x01"
            if r_ip and ":" in r_ip:
                try:
                    addr_part = b"\x04" + socket.inet_pton(socket.AF_INET6, r_ip)
                except Exception:
                    addr_part = b"\x01\x01\x01\x01\x01"
            else:
                try:
                    addr_part = b"\x01" + socket.inet_aton(r_ip if (r_ip and "." in r_ip) else "1.1.1.1")
                except Exception:
                    addr_part = b"\x01\x01\x01\x01\x01"
            rmeta = struct.pack("!HBBBH", sid, 2, 1, 2, r_port or 53) + addr_part
            rframe = struct.pack("!H", len(rmeta)) + rmeta + struct.pack("!H", len(dgram)) + dgram
            await _send_mux_bytes(rframe)
        except Exception:
            pass

    def _on_udp_dgram(sid: int, data: bytes, r_ip: str, r_port: int):
        _spawn(_send_xudp_datagram(sid, data, r_ip, r_port))

    async def _handle_mux_dns(sid: int, dns_q: bytes, taddr: str, tport: int):
        resp = await _resolve_dns_over_tcp(dns_q, taddr or "1.1.1.1", tport or 53)
        if resp:
            await _send_xudp_datagram(sid, resp, taddr or "1.1.1.1", tport or 53)

    async def _handle_mux_udp_send(sid: int, payload: bytes, taddr: str, tport: int):
        try:
            target_ip = await _resolve_udp_target_ipv4(taddr, tport)
            ut = udp_transports.get(sid)
            if ut is None:
                ut, _ = await asyncio.wait_for(
                    loop.create_datagram_endpoint(
                        lambda: _MuxUDPProto(sid, target_ip, tport, _on_udp_dgram),
                        family=socket.AF_INET,
                    ),
                    timeout=4.0,
                )
                udp_transports[sid] = ut
            ut.sendto(payload, (target_ip, tport))
        except Exception:
            pass

    async def _mux_tcp_worker(sid: int, taddr: str, tport: int, up_q: asyncio.Queue):
        from outbound_proxy import is_fake_or_non_public_ip
        tw = None
        first_item = b""
        try:
            # Peek at the first client payload on port 443/80 (or FakeIP/IPv6) to sniff TLS SNI / HTTP Host
            # so Instagram & YouTube always resolve to the server's local datacenter CDN instead of poisoned client IPs!
            is_ip_lit = (taddr != "127.0.0.1") and (is_fake_or_non_public_ip(taddr) or ":" in taddr or taddr.replace(".", "").isdigit())
            if not up_q.empty() or is_fake_or_non_public_ip(taddr) or (is_ip_lit and tport in (443, 80)):
                try:
                    wait_t = 2.0 if is_fake_or_non_public_ip(taddr) else 0.6
                    item0 = await asyncio.wait_for(up_q.get(), timeout=wait_t)
                    if item0 is None:
                        return
                    first_item = item0
                    sniffed = _sniff_sni_or_http_host(first_item)
                    if sniffed and taddr != "127.0.0.1":
                        taddr = sniffed
                except asyncio.TimeoutError:
                    pass

            tr, tw = await open_target_connection(link, taddr, tport, timeout=7.0)
            _tune_sock(tw)
            if first_item:
                tw.write(first_item)
                await tw.drain()

            async def _up():
                try:
                    while True:
                        item = await up_q.get()
                        if item is None:
                            if tw.can_write_eof():
                                tw.write_eof()
                            break
                        if item:
                            tw.write(item)
                            if tw.transport.get_write_buffer_size() > DRAIN_THRESHOLD:
                                await tw.drain()
                except Exception:
                    pass

            async def _dn():
                try:
                    while True:
                        chunk = await tr.read(32768)
                        if not chunk:
                            break
                        if not _fast_check_and_use(link, len(chunk)):
                            break
                        if conn_entry is not None:
                            conn_entry["bytes"] += len(chunk)
                        rmeta = struct.pack("!HBB", sid, 2, 1)
                        rframe = struct.pack("!H", 4) + rmeta + struct.pack("!H", len(chunk)) + chunk
                        await _send_mux_bytes(rframe)
                except Exception:
                    pass

            t_u = asyncio.create_task(_up())
            t_d = asyncio.create_task(_dn())
            done, pending = await asyncio.wait({t_u, t_d}, return_when=asyncio.FIRST_COMPLETED)
            if t_u in done and t_d not in done:
                try:
                    await asyncio.wait_for(t_d, timeout=10.0)
                except Exception:
                    t_d.cancel()
            else:
                for p in pending:
                    p.cancel()
            end_frame = struct.pack("!HHBB", 4, sid, 3, 0)
            await _send_mux_bytes(end_frame)
        except Exception:
            try:
                end_frame = struct.pack("!HHBB", 4, sid, 3, 0)
                await _send_mux_bytes(end_frame)
            except Exception:
                pass
        finally:
            tcp_queues.pop(sid, None)
            if tw is not None:
                try:
                    tw.close()
                except Exception:
                    pass

    try:
        while True:
            while len(buf) >= 2:
                meta_len = int.from_bytes(buf[0:2], "big")
                if meta_len < 4 or meta_len > 512:
                    return
                if len(buf) < 2 + meta_len:
                    break
                meta = buf[2 : 2 + meta_len]
                sid = int.from_bytes(meta[0:2], "big")
                status = meta[2]
                option = meta[3]
                fpos = 2 + meta_len

                if status in (1, 2) and meta_len >= 8:
                    net_type = meta[4]
                    tport = int.from_bytes(meta[5:7], "big")
                    atyp = meta[7]
                    apos = 8
                    taddr = "1.1.1.1"
                    if atyp == 1 and apos + 4 <= meta_len:
                        taddr = ".".join(str(b) for b in meta[apos : apos + 4])
                    elif atyp == 2 and apos + 1 <= meta_len:
                        dlen = meta[apos]
                        apos += 1
                        if apos + dlen <= meta_len:
                            taddr = meta[apos : apos + dlen].decode("utf-8", errors="ignore")
                    elif atyp in (3, 4) and apos + 16 <= meta_len:
                        ab = meta[apos : apos + 16]
                        taddr = ":".join(f"{ab[i]:02x}{ab[i+1]:02x}" for i in range(0, 16, 2))
                    sessions[sid] = (net_type, taddr, tport)

                payload = b""
                if option & 1:
                    if len(buf) < fpos + 2:
                        break
                    dlen = int.from_bytes(buf[fpos : fpos + 2], "big")
                    if len(buf) < fpos + 2 + dlen:
                        break
                    payload = buf[fpos + 2 : fpos + 2 + dlen]
                    buf = buf[fpos + 2 + dlen :]
                else:
                    buf = buf[fpos:]

                if status == 4:
                    # Mux KeepAlive frame
                    continue

                net_type, taddr, tport = sessions.get(sid, (2, "1.1.1.1", 53))

                if status == 3:
                    q = tcp_queues.pop(sid, None)
                    if q is not None:
                        try:
                            q.put_nowait(None)
                        except Exception:
                            pass
                    ut = udp_transports.pop(sid, None)
                    if ut is not None:
                        try:
                            ut.close()
                        except Exception:
                            pass
                    sessions.pop(sid, None)
                    continue

                if net_type == 2:
                    if tport in (443, 80):
                        # Immediately close QUIC (UDP 443/80) Mux sub-session so Instagram & YouTube never stall on QUIC-over-TCP!
                        end_frame = struct.pack("!HHBB", 4, sid, 3, 0)
                        _spawn(_send_mux_bytes(end_frame))
                        sessions.pop(sid, None)
                        continue
                    if payload:
                        if tport == 53:
                            _spawn(_handle_mux_dns(sid, payload, taddr, 53))
                        else:
                            _spawn(_handle_mux_udp_send(sid, payload, taddr, tport))
                elif net_type == 1:
                    # Intercept Mux TCP DNS (port 53) used by sing-box TUN / Happ
                    if tport == 53 and payload and len(payload) >= 14:
                        plen = int.from_bytes(payload[:2], "big")
                        if 12 <= plen <= len(payload) - 2:
                            async def _mux_tcp_dns(s_id: int, q_bytes: bytes, addr_s: str):
                                resp = await _resolve_dns_over_tcp(q_bytes, addr_s or "1.1.1.1", 53)
                                if resp:
                                    rc = len(resp).to_bytes(2, "big") + resp
                                    rm = struct.pack("!HBB", s_id, 2, 1)
                                    rf = struct.pack("!H", 4) + rm + struct.pack("!H", len(rc)) + rc
                                    await _send_mux_bytes(rf)
                                ef = struct.pack("!HHBB", 4, s_id, 3, 0)
                                await _send_mux_bytes(ef)
                            _spawn(_mux_tcp_dns(sid, payload[2 : 2 + plen], taddr))
                            continue
                    q = tcp_queues.get(sid)
                    if q is None and status == 1:
                        q = asyncio.Queue(maxsize=256)
                        tcp_queues[sid] = q
                        _spawn(_mux_tcp_worker(sid, taddr, tport, q))
                    if q is not None and payload:
                        try:
                            q.put_nowait(payload)
                        except asyncio.QueueFull:
                            await q.put(payload)

            more = await asyncio.wait_for(read_fn(), timeout=30.0)
            if not more:
                break
            if not _fast_check_and_use(link, len(more)):
                break
            if conn_entry is not None:
                conn_entry["bytes"] += len(more)
            buf += more
    except Exception:
        pass
    finally:
        for t in list(bg_tasks):
            t.cancel()
        for ut in list(udp_transports.values()):
            try:
                ut.close()
            except Exception:
                pass


def _is_socks5_greeting(buf: bytes) -> bool:
    if len(buf) < 3 or buf[0] != 5:
        return False
    nmethods = buf[1]
    if not (1 <= nmethods <= 8):
        return False
    sample = buf[2 : min(len(buf), 2 + nmethods)]
    return all(m in (0x00, 0x01, 0x02, 0x03, 0x80) for m in sample)


async def _negotiate_socks5(read_fn, write_fn, initial_buf: bytes):
    from main import LINKS

    buf = initial_buf
    while len(buf) < 2:
        more = await asyncio.wait_for(read_fn(), timeout=6.0)
        if not more:
            return None
        buf += more
    if buf[0] != 5:
        return None
    nmethods = buf[1]
    while len(buf) < 2 + nmethods:
        more = await asyncio.wait_for(read_fn(), timeout=6.0)
        if not more:
            return None
        buf += more
    methods = buf[2 : 2 + nmethods]
    buf = buf[2 + nmethods :]

    uid = None
    if 0x02 in methods:
        await write_fn(b"\x05\x02")
        while len(buf) < 2:
            more = await asyncio.wait_for(read_fn(), timeout=6.0)
            if not more:
                return None
            buf += more
        ulen = buf[1]
        while len(buf) < 2 + ulen + 1:
            more = await asyncio.wait_for(read_fn(), timeout=6.0)
            if not more:
                return None
            buf += more
        uname = buf[2 : 2 + ulen].decode("utf-8", errors="ignore")
        plen = buf[2 + ulen]
        while len(buf) < 2 + ulen + 1 + plen:
            more = await asyncio.wait_for(read_fn(), timeout=6.0)
            if not more:
                return None
            buf += more
        passwd = buf[2 + ulen + 1 : 2 + ulen + 1 + plen].decode("utf-8", errors="ignore")
        buf = buf[2 + ulen + 1 + plen :]
        if uname in LINKS:
            uid = uname
        elif passwd in LINKS:
            uid = passwd
        elif LINKS:
            uid = next(iter(LINKS))
        await write_fn(b"\x01\x00")
    else:
        await write_fn(b"\x05\x00")
        if LINKS:
            uid = next(iter(LINKS))

    while len(buf) < 4:
        more = await asyncio.wait_for(read_fn(), timeout=6.0)
        if not more:
            return None
        buf += more
    if buf[0] != 5:
        return None
    cmd = buf[1]
    atyp = buf[3]
    pos = 4
    if atyp == 1:
        while len(buf) < pos + 6:
            more = await asyncio.wait_for(read_fn(), timeout=6.0)
            if not more:
                return None
            buf += more
        address = ".".join(str(b) for b in buf[pos : pos + 4])
        pos += 4
    elif atyp == 3:
        while len(buf) < pos + 1:
            more = await asyncio.wait_for(read_fn(), timeout=6.0)
            if not more:
                return None
            buf += more
        dlen = buf[pos]
        pos += 1
        while len(buf) < pos + dlen + 2:
            more = await asyncio.wait_for(read_fn(), timeout=6.0)
            if not more:
                return None
            buf += more
        address = buf[pos : pos + dlen].decode("utf-8", errors="ignore")
        pos += dlen
    elif atyp == 4:
        while len(buf) < pos + 18:
            more = await asyncio.wait_for(read_fn(), timeout=6.0)
            if not more:
                return None
            buf += more
        ab = buf[pos : pos + 16]
        pos += 16
        address = ":".join(f"{ab[i]:02x}{ab[i+1]:02x}" for i in range(0, 16, 2))
    else:
        return None

    port = int.from_bytes(buf[pos : pos + 2], "big")
    pos += 2
    await write_fn(_SOCKS5_OK_RESP)
    return uid, cmd, address, port, buf[pos:]


async def _detect_and_parse_stream_header(read_fn, write_fn, initial_buf: bytes, links: dict, fallback_uid: str | None = None):
    """
    Universal protocol detector for VLESS, VMess AEAD, Trojan, and SOCKS5.
    Returns (proto_type, uid, command, address, port, payload, vmess_ctx) or None.
    """
    buf = initial_buf
    while len(buf) < 3:
        more = await asyncio.wait_for(read_fn(), timeout=8.0)
        if not more:
            return None
        buf += more

    # 1. Check SOCKS5 Greeting (0x05 + valid methods)
    if _is_socks5_greeting(buf):
        s_res = await _negotiate_socks5(read_fn, write_fn, buf)
        if s_res:
            s_uid, cmd, addr, port, payload = s_res
            return "socks5", (fallback_uid if (fallback_uid and fallback_uid in links) else s_uid), cmd, addr, port, payload, None

    # 2. Check VLESS (0x00 or 0x01 followed by a valid 16-byte UUID — accepts any valid VLESS header and falls back to active default link if server was wiped/reinstalled)
    if buf[0] in (0, 1):
        while len(buf) < 18:
            more = await asyncio.wait_for(read_fn(), timeout=8.0)
            if not more:
                break
            buf += more
        if len(buf) >= 18 and buf[17] <= 64:
            try:
                cand_uid = str(uuid_mod.UUID(bytes=buf[1:17]))
            except Exception:
                cand_uid = ""
            if cand_uid:
                while True:
                    parsed = parse_vless_header_ex(buf)
                    if parsed is None:
                        break
                    hdr_uid, cmd, addr, port, payload, need_more = parsed
                    if not need_more:
                        if cmd in (1, 2, 3) and (cmd == 3 or (1 <= port <= 65535 and addr)):
                            use_uid = hdr_uid if hdr_uid in links else (
                                fallback_uid if (fallback_uid and fallback_uid in links) else next(
                                    (k for k, v in links.items() if v.get("active", True)),
                                    next(iter(links), hdr_uid),
                                )
                            )
                            return "vless", use_uid, cmd, addr, port, payload, None
                        break
                    more = await asyncio.wait_for(read_fn(), timeout=8.0)
                    if not more:
                        return None
                    buf += more

    # 3. Check VMess AEAD (16-byte AES-128-ECB EAuID with valid 32-bit IEEE CRC32)
    while len(buf) < 16:
        more = await asyncio.wait_for(read_fn(), timeout=8.0)
        if not more:
            return None
        buf += more
    if _match_vmess_eauid(buf[:16], links) is not None:
        while True:
            v_res = parse_vmess_aead_header(buf, links)
            if v_res is None:
                break
            v_uid, cmd, addr, port, payload, vmess_ctx, need_more = v_res
            if not need_more:
                return "vmess", v_uid, cmd, addr, port, payload, vmess_ctx
            more = await asyncio.wait_for(read_fn(), timeout=8.0)
            if not more:
                return None
            buf += more

    # 4. Check Trojan (56 hex chars + \r\n)
    while True:
        parsed = parse_trojan_header_ex(buf)
        if parsed is None:
            return None
        t_uid, cmd, addr, port, payload, need_more = parsed
        if not need_more:
            use_uid = t_uid if t_uid in links else fallback_uid
            return "trojan", use_uid, cmd, addr, port, payload, None
        more = await asyncio.wait_for(read_fn(), timeout=8.0)
        if not more:
            return None
        buf += more


async def _handle_vless_or_trojan_stream(
    reader,
    writer,
    first_chunk: bytes,
    ip: str,
    http_obfuscated: bool = False,
    already_sent_http_resp: bool = False,
    is_reality: bool = False,
):
    from main import LINKS, stats, connections, is_link_allowed, is_ip_allowed
    from speed_limit import throttle
    from outbound_proxy import open_target_connection

    conn_id = secrets.token_urlsafe(6)
    target_writer = None

    async def _tcp_read():
        return await reader.read(RELAY_BUF)

    async def _tcp_write(data: bytes):
        writer.write(data)
        await writer.drain()

    try:
        if http_obfuscated and not already_sent_http_resp:
            writer.write(_HTTP_OBFUSCATION_RESP)
            await writer.drain()

        det = await _detect_and_parse_stream_header(_tcp_read, _tcp_write, first_chunk, LINKS)
        if not det:
            return
        proto_type, uid, command, address, port, payload, vmess_ctx = det

        link = LINKS.get(uid)
        if not is_link_allowed(link) or not is_ip_allowed(link, uid, ip):
            return

        if is_reality:
            transport_name = "vless-reality"
        elif http_obfuscated:
            transport_name = f"{proto_type}-http"
        else:
            transport_name = f"{proto_type}-tcp" if proto_type == "vless" else proto_type

        conn_entry = {
            "uuid": uid,
            "ip": ip,
            "transport": transport_name,
            "connected_at": datetime.datetime.now().isoformat(),
            "bytes": len(first_chunk),
        }
        connections[conn_id] = conn_entry

        if not _fast_check_and_use(link, len(first_chunk)):
            return
        stats["total_requests"] += 1

        if proto_type == "vmess" and vmess_ctx is not None:
            await _relay_vmess_session(
                _tcp_read, _tcp_write, payload, vmess_ctx,
                address, port, command, link, conn_entry, uid, throttle,
            )
            return

        is_vless = (proto_type == "vless")

        is_vision = bool(is_vless and has_vision_flow(first_chunk))
        v_unpadder = _VisionUnpadder() if is_vision else None
        v_uuid_bytes = uuid_mod.UUID(uid).bytes if is_vision else None

        if command == 3 and is_vless:
            if v_unpadder is not None and payload:
                payload = v_unpadder.feed(payload)
            await _handle_vless_mux_xudp(_tcp_read, _tcp_write, payload, link, conn_entry)
            return

        # Intercept BOTH command == 2 (UDP) AND command == 1 (TCP DNS on port 53 used by v2rayN sing-box TUN & Happ!)
        if command == 2 or (command == 1 and port == 53):
            if port == 53 or ALLOW_ALL_UDP:
                await _handle_vless_udp_cmd2(_tcp_read, _tcp_write, address or "1.1.1.1", port or 53, payload, link, conn_entry, is_vless=is_vless)
            return

        from outbound_proxy import is_fake_or_non_public_ip

        if payload and v_unpadder is not None:
            payload = v_unpadder.feed(payload)

        sent_vless_hdr = False

        # If client sent an IP literal (e.g. ISP-resolved or FakeIP/IPv6) on port 443/80 without initial payload,
        # read the first TLS ClientHello / HTTP request so we can sniff the real domain and resolve it locally on the server!
        is_ip_target = (address != "127.0.0.1") and (is_fake_or_non_public_ip(address) or ":" in address or address.replace(".", "").isdigit())
        if not payload and (is_fake_or_non_public_ip(address) or (is_ip_target and port in (443, 80))):
            try:
                wait_t = 1.2 if is_fake_or_non_public_ip(address) else 0.5
                more_p = await asyncio.wait_for(reader.read(RELAY_BUF), timeout=wait_t)
                if more_p:
                    payload = v_unpadder.feed(more_p) if v_unpadder is not None else more_p
            except Exception:
                pass

        if payload and address != "127.0.0.1":
            sniffed_domain = _sniff_sni_or_http_host(payload)
            if sniffed_domain and is_ip_target:
                address = sniffed_domain

        target_reader, target_writer = await open_target_connection(link, address, port, timeout=8.0)
        _tune_sock(target_writer)

        if payload:
            target_writer.write(payload)
            await target_writer.drain()

        t1 = asyncio.create_task(_pipe_client_to_target(reader, target_writer, link, conn_entry, uid, throttle, vision_unpadder=v_unpadder))
        t2 = asyncio.create_task(_pipe_target_to_client(target_reader, writer, link, conn_entry, uid, throttle, is_vless=is_vless, vision_uuid_bytes=v_uuid_bytes, already_sent_vless_hdr=sent_vless_hdr))
        done, pending = await asyncio.wait({t1, t2}, return_when=asyncio.FIRST_COMPLETED)
        if t1 in done and t2 not in done:
            try:
                await asyncio.wait_for(t2, timeout=12.0)
            except Exception:
                t2.cancel()
        else:
            for t in pending:
                t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
    except Exception:
        pass
    finally:
        if target_writer:
            try:
                target_writer.close()
                await target_writer.wait_closed()
            except Exception:
                pass
        connections.pop(conn_id, None)


def _encode_ws_frame(data: bytes, opcode: int = 2) -> bytes:
    length = len(data)
    b0 = 0x80 | opcode
    if length < 126:
        return struct.pack("!BB", b0, length) + data
    if length < 65536:
        return struct.pack("!BBH", b0, 126, length) + data
    return struct.pack("!BBQ", b0, 127, length) + data


async def _read_ws_frame(reader: asyncio.StreamReader) -> tuple[int, bytes] | None:
    try:
        hdr = await reader.readexactly(2)
    except Exception:
        return None
    b0, b1 = hdr[0], hdr[1]
    opcode = b0 & 0x0F
    masked = bool(b1 & 0x80)
    length = b1 & 0x7F
    try:
        if length == 126:
            length = struct.unpack("!H", await reader.readexactly(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", await reader.readexactly(8))[0]
        if length > 4 * 1024 * 1024:
            return None
        mask = await reader.readexactly(4) if masked else b""
        payload = await reader.readexactly(length) if length else b""
    except Exception:
        return None
    if masked and payload:
        payload = _ws_unmask(payload, mask)
    return opcode, payload


async def _handle_raw_websocket(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    header_bytes: bytes,
    leftover: bytes,
    ip: str,
):
    from main import LINKS, stats, connections, is_link_allowed, is_ip_allowed
    from speed_limit import throttle
    from outbound_proxy import open_target_connection

    lines = header_bytes.decode("latin-1", errors="ignore").split("\r\n")
    if not lines:
        return
    req_parts = lines[0].split(" ")
    path = req_parts[1] if len(req_parts) >= 2 else "/"
    raw_path = path.split("?", 1)[0].strip("/")
    path_parts = raw_path.split("/")
    path_uid = path_parts[1] if len(path_parts) >= 2 and path_parts[0] == "ws" else (path_parts[0] if path_parts else "")

    headers = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()

    ws_key = headers.get("sec-websocket-key", "")
    if not ws_key:
        return

    fwd = headers.get("x-forwarded-for")
    if fwd:
        ip = fwd.split(",")[0].strip()
    elif headers.get("x-real-ip"):
        ip = headers["x-real-ip"].strip()

    subproto_hdr = headers.get("sec-websocket-protocol", "")
    subproto = subproto_hdr.split(",")[0].strip() if subproto_hdr else ""
    early_data = _decode_base64_any(subproto) if subproto else None

    accept_val = base64.b64encode(hashlib.sha1((ws_key + _WS_GUID).encode("ascii")).digest()).decode("ascii")
    resp = (
        f"HTTP/1.1 101 Switching Protocols\r\n"
        f"Upgrade: websocket\r\n"
        f"Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept_val}\r\n"
    )
    if subproto:
        resp += f"Sec-WebSocket-Protocol: {subproto}\r\n"
    resp += "\r\n"
    writer.write(resp.encode("ascii"))
    await writer.drain()

    if leftover:
        reader._buffer[:0] = leftover

    async def _ws_read_data() -> bytes:
        while True:
            frame = await _read_ws_frame(reader)
            if frame is None:
                return b""
            op, data = frame
            if op == 8:
                return b""
            if op == 9:
                writer.write(_encode_ws_frame(data, opcode=10))
                await writer.drain()
                continue
            if op in (0, 1, 2) and data:
                return data

    async def _ws_write_data(data: bytes):
        writer.write(_encode_ws_frame(data, opcode=2))
        await writer.drain()

    conn_id = secrets.token_urlsafe(6)
    target_writer = None

    try:
        buf = early_data or b""
        if not buf:
            buf = await asyncio.wait_for(_ws_read_data(), timeout=12.0)
            if not buf:
                return

        det = await _detect_and_parse_stream_header(
            _ws_read_data, _ws_write_data, buf, LINKS,
            fallback_uid=(path_uid if path_uid in LINKS else None),
        )
        if not det:
            return
        proto_type, uid, command, address, port, payload, vmess_ctx = det

        link = LINKS.get(uid)
        if not is_link_allowed(link) or not is_ip_allowed(link, uid, ip):
            return

        conn_entry = {
            "uuid": uid,
            "ip": ip,
            "transport": f"{proto_type}-ws",
            "connected_at": datetime.datetime.now().isoformat(),
            "bytes": len(buf),
        }
        connections[conn_id] = conn_entry
        if not _fast_check_and_use(link, len(buf)):
            return
        stats["total_requests"] += 1

        if proto_type == "vmess" and vmess_ctx is not None:
            await _relay_vmess_session(
                _ws_read_data, _ws_write_data, payload, vmess_ctx,
                address, port, command, link, conn_entry, uid, throttle,
            )
            return

        is_vless = (proto_type == "vless")

        if command == 3 and is_vless:
            await _handle_vless_mux_xudp(_ws_read_data, _ws_write_data, payload, link, conn_entry)
            return

        if command == 2:
            if port == 53 or ALLOW_ALL_UDP:
                await _handle_vless_udp_cmd2(_ws_read_data, _ws_write_data, address or "1.1.1.1", port or 53, payload, link, conn_entry, is_vless=is_vless)
            return

        target_reader, target_writer = await open_target_connection(link, address, port, timeout=8.0)
        _tune_sock(target_writer)
        if payload:
            target_writer.write(payload)
            await target_writer.drain()

        has_limit = bool(link and int(link.get("speed_limit_bytes") or 0) > 0)

        async def _ws_to_tcp():
            t_trans = target_writer.transport
            try:
                while True:
                    data = await _ws_read_data()
                    if not data:
                        break
                    n = len(data)
                    if not _fast_check_and_use(link, n):
                        break
                    if has_limit:
                        await throttle(uid, n)
                    conn_entry["bytes"] += n
                    target_writer.write(data)
                    if t_trans.get_write_buffer_size() > DRAIN_THRESHOLD:
                        await target_writer.drain()
            except Exception:
                pass
            finally:
                try:
                    if target_writer.can_write_eof():
                        target_writer.write_eof()
                except Exception:
                    pass

        async def _tcp_to_ws():
            first = True
            c_trans = writer.transport
            try:
                while True:
                    data = await target_reader.read(RELAY_BUF)
                    if not data:
                        if first and is_vless:
                            writer.write(_encode_ws_frame(b"\x00\x00", opcode=2))
                            await writer.drain()
                        break
                    n = len(data)
                    if not _fast_check_and_use(link, n):
                        break
                    if has_limit:
                        await throttle(uid, n)
                    conn_entry["bytes"] += n
                    if first and is_vless:
                        out = b"\x00\x00" + data
                        first = False
                    else:
                        first = False
                        out = data
                    writer.write(_encode_ws_frame(out, opcode=2))
                    if c_trans.get_write_buffer_size() > DRAIN_THRESHOLD:
                        await writer.drain()
            except Exception:
                pass

        t1 = asyncio.create_task(_ws_to_tcp())
        t2 = asyncio.create_task(_tcp_to_ws())
        done, pending = await asyncio.wait({t1, t2}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

    except Exception:
        pass
    finally:
        if target_writer:
            try:
                target_writer.close()
                await target_writer.wait_closed()
            except Exception:
                pass
        connections.pop(conn_id, None)


async def _splice_to_local_port(
    client_reader: asyncio.StreamReader,
    client_writer: asyncio.StreamWriter,
    local_port: int,
    initial_bytes: bytes,
    client_ip: str = "unknown",
):
    target_writer = None
    src_port = None
    try:
        target_reader, target_writer = await asyncio.wait_for(
            asyncio.open_connection("127.0.0.1", local_port, limit=STREAM_LIMIT),
            timeout=5.0,
        )
        sockname = target_writer.get_extra_info("sockname")
        if sockname and len(sockname) >= 2:
            src_port = sockname[1]
            _TLS_CLIENT_IPS[src_port] = client_ip

        if initial_bytes:
            target_writer.write(initial_bytes)
            await target_writer.drain()

        async def _p(r, w):
            try:
                while True:
                    d = await r.read(65536)
                    if not d:
                        break
                    w.write(d)
                    if w.transport.get_write_buffer_size() > 131072:
                        await w.drain()
            except Exception:
                pass
            finally:
                try:
                    if w.can_write_eof():
                        w.write_eof()
                except Exception:
                    pass

        t1 = asyncio.create_task(_p(client_reader, target_writer))
        t2 = asyncio.create_task(_p(target_reader, client_writer))
        done, pending = await asyncio.wait({t1, t2}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
    except Exception:
        pass
    finally:
        if src_port is not None:
            _TLS_CLIENT_IPS.pop(src_port, None)
        if target_writer:
            try:
                target_writer.close()
                await target_writer.wait_closed()
            except Exception:
                pass


_WEB_ROUTE_PREFIXES = (
    b"GET /sub", b"GET /s/", b"GET /p/", b"GET /info/", b"GET /subscription/",
    b"GET /dashboard", b"GET /login", b"POST /login", b"GET /logout",
    b"GET /api/", b"POST /api/", b"PATCH /api/", b"DELETE /api/",
    b"GET /assets/", b"GET /health", b"GET /stats",
    b"GET /xhttp", b"POST /xhttp",
)


async def _handle_reality_pure_tls13(
    raw_reader: asyncio.StreamReader,
    raw_writer: asyncio.StreamWriter,
    ch_info: dict,
    client_x25519_pub: bytes,
    auth_key: bytes,
    ip: str,
):
    """
    100% Pure-Python TLS 1.3 REALITY Server Engine (RFC 8446 + XTLS/REALITY):
    - Completes TLS 1.3 handshake in 1 RTT (0.4ms) with zero HelloRetryRequest, zero ALPN mismatch,
      and zero unsolicited NewSessionTicket.
    - Signs the minimal Ed25519 certificate with HMAC-SHA512(auth_key, ed_pub_bytes) so Xray 26.5.9
      (`v2rayN`), `sing-box` (`Happ`), and `NPV Tunnel` set `uConn.Verified = true` immediately.
    """
    from main import handle_http_stream

    st = get_reality_credentials()
    ch_hs = ch_info["ch_hs"]
    session_id = ch_info["session_id"]
    ciphers = ch_info["ciphers"]

    # Pick cipher suite in client preference order
    chosen_cs = 0x1301
    for cs in ciphers:
        if cs in (0x1301, 0x1302, 0x1303):
            chosen_cs = cs
            break

    if chosen_cs == 0x1302:
        hash_cls, hash_mod, hash_len, key_len = hashlib.sha384, hashes.SHA384, 48, 32
        aead_cls = AESGCM
    elif chosen_cs == 0x1303:
        hash_cls, hash_mod, hash_len, key_len = hashlib.sha256, hashes.SHA256, 32, 32
        aead_cls = ChaCha20Poly1305
    else:
        hash_cls, hash_mod, hash_len, key_len = hashlib.sha256, hashes.SHA256, 32, 16
        aead_cls = AESGCM

    # Ephemeral server X25519 keypair for TLS 1.3 ECDHE / X25519MLKEM768
    s_eph_priv = x25519.X25519PrivateKey.generate()
    s_eph_pub_bytes = s_eph_priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    x25519_direct_list = ch_info.get("x25519_direct") or []
    mlkem_list = ch_info.get("mlkem_shares") or []

    if x25519_direct_list:
        peer_x_pub = x25519.X25519PublicKey.from_public_bytes(x25519_direct_list[0])
        ecdhe_shared = s_eph_priv.exchange(peer_x_pub)
        selected_group = 0x001D
        server_share_data = s_eph_pub_bytes
    elif mlkem_list:
        mlkem_raw = mlkem_list[0]
        ek1184, c_x25519 = mlkem_raw[:1184], mlkem_raw[1184:1216]
        k_pq, ct1088 = _mlkem768_encaps(ek1184)
        peer_x_pub = x25519.X25519PublicKey.from_public_bytes(c_x25519)
        k_x25519 = s_eph_priv.exchange(peer_x_pub)
        ecdhe_shared = k_pq + k_x25519
        selected_group = 0x11EC
        server_share_data = ct1088 + s_eph_pub_bytes
    else:
        peer_x_pub = x25519.X25519PublicKey.from_public_bytes(client_x25519_pub)
        ecdhe_shared = s_eph_priv.exchange(peer_x_pub)
        selected_group = 0x001D
        server_share_data = s_eph_pub_bytes

    # ServerHello (selects TLS 1.3 = 0x0304 and matching key_share group)
    s_rand = os.urandom(32)
    sh_exts = (
        struct.pack("!HHH", 0x002B, 2, 0x0304)
        + struct.pack("!HHHH", 0x0033, 4 + len(server_share_data), selected_group, len(server_share_data))
        + server_share_data
    )
    sh_body = (
        b"\x03\x03"
        + s_rand
        + bytes([len(session_id)])
        + session_id
        + struct.pack("!HB", chosen_cs, 0)
        + struct.pack("!H", len(sh_exts))
        + sh_exts
    )
    sh_hs = b"\x02" + len(sh_body).to_bytes(3, "big") + sh_body
    sh_rec = b"\x16\x03\x03" + struct.pack("!H", len(sh_hs)) + sh_hs
    ccs_rec = b"\x14\x03\x03\x00\x01\x01"

    # TLS 1.3 Key Schedule
    zero_ikm = b"\x00" * hash_len
    early_secret = _tls13_hkdf_extract(hash_cls, zero_ikm, zero_ikm)
    empty_hash = hash_cls(b"").digest()
    derived_1 = _tls13_hkdf_expand_label(hash_mod, early_secret, b"derived", empty_hash, hash_len)
    handshake_secret = _tls13_hkdf_extract(hash_cls, derived_1, ecdhe_shared)

    transcript_ch_sh = ch_hs + sh_hs
    c_hs_secret = _tls13_derive_secret(hash_cls, hash_mod, handshake_secret, b"c hs traffic", transcript_ch_sh, hash_len)
    s_hs_secret = _tls13_derive_secret(hash_cls, hash_mod, handshake_secret, b"s hs traffic", transcript_ch_sh, hash_len)

    s_hs_key = _tls13_hkdf_expand_label(hash_mod, s_hs_secret, b"key", b"", key_len)
    s_hs_iv = _tls13_hkdf_expand_label(hash_mod, s_hs_secret, b"iv", b"", 12)
    c_hs_key = _tls13_hkdf_expand_label(hash_mod, c_hs_secret, b"key", b"", key_len)
    c_hs_iv = _tls13_hkdf_expand_label(hash_mod, c_hs_secret, b"iv", b"", 12)

    s_hs_aead = aead_cls(s_hs_key)
    c_hs_aead = aead_cls(c_hs_key)

    # 1. EncryptedExtensions (empty — no ALPN so raw TCP VLESS never conflicts with h2)
    ee_hs = b"\x08\x00\x00\x02\x00\x00"

    # 2. Certificate (temporary Ed25519 DER certificate with Signature = HMAC-SHA512(auth_key, ed_pub_bytes))
    cert_sig = hmac.new(auth_key, st["ed_pub_bytes"], hashlib.sha512).digest()
    signed_der = st["der_prefix"] + cert_sig
    cert_entry = len(signed_der).to_bytes(3, "big") + signed_der + b"\x00\x00"
    cert_body = b"\x00" + len(cert_entry).to_bytes(3, "big") + cert_entry
    cert_hs = b"\x0b" + len(cert_body).to_bytes(3, "big") + cert_body

    # 3. CertificateVerify (signed with ed_priv over transcript_ch_sh + ee_hs + cert_hs)
    th_cv = hash_cls(transcript_ch_sh + ee_hs + cert_hs).digest()
    cv_msg = (b" " * 64) + b"TLS 1.3, server CertificateVerify\x00" + th_cv
    cv_sig = st["ed_priv"].sign(cv_msg)
    cv_body = struct.pack("!HH", 0x0807, len(cv_sig)) + cv_sig
    cv_hs = b"\x0f" + len(cv_body).to_bytes(3, "big") + cv_body

    # 4. Server Finished
    fin_key = _tls13_hkdf_expand_label(hash_mod, s_hs_secret, b"finished", b"", hash_len)
    th_fin = hash_cls(transcript_ch_sh + ee_hs + cert_hs + cv_hs).digest()
    fin_verify = hmac.new(fin_key, th_fin, hash_cls).digest()
    fin_hs = b"\x14" + len(fin_verify).to_bytes(3, "big") + fin_verify

    # Encrypt each handshake message in its own TLS 1.3 record (seq 0..3), matching Go crypto/tls & XTLS/REALITY
    rec_ee = _tls13_encrypt_record(s_hs_aead, s_hs_iv, 0, 0x16, ee_hs)
    rec_cert = _tls13_encrypt_record(s_hs_aead, s_hs_iv, 1, 0x16, cert_hs)
    rec_cv = _tls13_encrypt_record(s_hs_aead, s_hs_iv, 2, 0x16, cv_hs)
    rec_fin = _tls13_encrypt_record(s_hs_aead, s_hs_iv, 3, 0x16, fin_hs)

    raw_writer.write(sh_rec + ccs_rec + rec_ee + rec_cert + rec_cv + rec_fin)
    await raw_writer.drain()

    # Derive Master Application Traffic Secrets (over Ch..ServerFinished)
    derived_2 = _tls13_hkdf_expand_label(hash_mod, handshake_secret, b"derived", empty_hash, hash_len)
    master_secret = _tls13_hkdf_extract(hash_cls, derived_2, zero_ikm)
    transcript_full = transcript_ch_sh + ee_hs + cert_hs + cv_hs + fin_hs

    c_app_secret = _tls13_derive_secret(hash_cls, hash_mod, master_secret, b"c ap traffic", transcript_full, hash_len)
    s_app_secret = _tls13_derive_secret(hash_cls, hash_mod, master_secret, b"s ap traffic", transcript_full, hash_len)

    c_app_key = _tls13_hkdf_expand_label(hash_mod, c_app_secret, b"key", b"", key_len)
    c_app_iv = _tls13_hkdf_expand_label(hash_mod, c_app_secret, b"iv", b"", 12)
    s_app_key = _tls13_hkdf_expand_label(hash_mod, s_app_secret, b"key", b"", key_len)
    s_app_iv = _tls13_hkdf_expand_label(hash_mod, s_app_secret, b"iv", b"", 12)

    c_app_aead = aead_cls(c_app_key)
    s_app_aead = aead_cls(s_app_key)

    # Read Client ChangeCipherSpec (optional) and Client Finished (encrypted with c_hs_aead, seq=0)
    rbuf = ch_info.get("leftover", b"")
    c_hs_seq = 0
    got_client_fin = False
    while not got_client_fin:
        while len(rbuf) < 5:
            more = await asyncio.wait_for(raw_reader.read(65536), timeout=8.0)
            if not more:
                return
            rbuf += more
        rtype = rbuf[0]
        rlen = int.from_bytes(rbuf[3:5], "big")
        if rlen > 32768:
            return
        while len(rbuf) < 5 + rlen:
            more = await asyncio.wait_for(raw_reader.read(65536), timeout=8.0)
            if not more:
                return
            rbuf += more
        hdr = rbuf[:5]
        body = rbuf[5 : 5 + rlen]
        rbuf = rbuf[5 + rlen :]
        if rtype == 0x14:
            continue
        if rtype != 0x17:
            return
        ctype, plain = _tls13_decrypt_record(c_hs_aead, c_hs_iv, c_hs_seq, hdr, body)
        c_hs_seq += 1
        if ctype == 0x16 and len(plain) >= 4 and plain[0] == 0x14:
            got_client_fin = True
            break

    tls_reader = _PureTLS13Reader(raw_reader, c_app_aead, c_app_iv, initial_raw=rbuf)
    tls_writer = _PureTLS13Writer(raw_writer, s_app_aead, s_app_iv)

    plain_first = await asyncio.wait_for(tls_reader.read(65536), timeout=10.0)
    if not plain_first:
        return

    if plain_first[:4] in (b"GET ", b"POST", b"HEAD", b"PUT ", b"DELE", b"OPTI", b"PATC"):
        pbuf = plain_first
        while b"\r\n\r\n" not in pbuf and len(pbuf) < 65536:
            pmore = await asyncio.wait_for(tls_reader.read(16384), timeout=5.0)
            if not pmore:
                break
            pbuf += pmore
        h_bytes, _, b_bytes = pbuf.partition(b"\r\n\r\n")
        if b"upgrade: websocket" in h_bytes.lower():
            await _handle_raw_websocket(tls_reader, tls_writer, h_bytes, b_bytes, ip)
            return
        await handle_http_stream(tls_reader, tls_writer, h_bytes, b_bytes, ip)
        return

    await _handle_vless_or_trojan_stream(
        tls_reader, tls_writer, plain_first, ip,
        http_obfuscated=False, is_reality=True,
    )


async def _handle_tls_or_reality_client(
    raw_reader: asyncio.StreamReader,
    raw_writer: asyncio.StreamWriter,
    first_chunk: bytes,
    ip: str,
):
    from main import DATA_DIR, handle_http_stream

    buf = first_chunk
    rec_len = int.from_bytes(buf[3:5], "big")
    while len(buf) < 5 + rec_len and len(buf) < 32768:
        more = await asyncio.wait_for(raw_reader.read(16384), timeout=6.0)
        if not more:
            return
        buf += more

    ch_info = _parse_client_hello_details(buf)
    if ch_info is not None:
        verified = _verify_reality_client_hello(ch_info)
        if verified is not None:
            cand_pub, auth_key = verified
            await _handle_reality_pure_tls13(raw_reader, raw_writer, ch_info, cand_pub, auth_key, ip)
            return

    sni = (ch_info["sni"] if ch_info else "") or "speedtest.net"
    ctx = ensure_tls_context(DATA_DIR, domain=sni)

    in_bio = ssl.MemoryBIO()
    out_bio = ssl.MemoryBIO()
    ssl_obj = ctx.wrap_bio(in_bio, out_bio, server_side=True)
    in_bio.write(buf)

    while True:
        try:
            ssl_obj.do_handshake()
            enc = out_bio.read()
            if enc:
                raw_writer.write(enc)
                await raw_writer.drain()
            break
        except ssl.SSLWantReadError:
            enc = out_bio.read()
            if enc:
                raw_writer.write(enc)
                await raw_writer.drain()
            more = await asyncio.wait_for(raw_reader.read(65536), timeout=8.0)
            if not more:
                return
            in_bio.write(more)

    tls_reader = _TLSBioReader(raw_reader, raw_writer, ssl_obj, in_bio, out_bio)
    tls_writer = _TLSBioWriter(raw_writer, ssl_obj, out_bio)

    plain_first = await asyncio.wait_for(tls_reader.read(65536), timeout=10.0)
    if not plain_first:
        return

    if plain_first[:4] in (b"GET ", b"POST", b"HEAD", b"PUT ", b"DELE", b"OPTI", b"PATC"):
        pbuf = plain_first
        while b"\r\n\r\n" not in pbuf and len(pbuf) < 65536:
            pmore = await asyncio.wait_for(tls_reader.read(16384), timeout=5.0)
            if not pmore:
                break
            pbuf += pmore
        h_bytes, _, b_bytes = pbuf.partition(b"\r\n\r\n")
        if b"upgrade: websocket" in h_bytes.lower():
            await _handle_raw_websocket(tls_reader, tls_writer, h_bytes, b_bytes, ip)
            return
        await handle_http_stream(tls_reader, tls_writer, h_bytes, b_bytes, ip)
        await tls_writer.close_tls()
        return

    await _handle_vless_or_trojan_stream(
        tls_reader, tls_writer, plain_first, ip,
        http_obfuscated=False, is_reality=False,
    )


async def _handle_multiplexed_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    _tune_sock(writer)
    ip = _client_ip(writer)
    try:
        first_chunk = await asyncio.wait_for(reader.read(65536), timeout=10.0)
        if not first_chunk:
            return

        b0 = first_chunk[0]

        # 1. XTLS REALITY (sni=github.com) & TLS 1.3 / HTTPS (0x16 0x03)
        if b0 == 0x16 and len(first_chunk) >= 5 and first_chunk[1] == 0x03:
            await _handle_tls_or_reality_client(reader, writer, first_chunk, ip)
            return

        # 2. HTTP / WebSocket / Iran HTTP-Obfuscated TCP (headerType=http)
        if first_chunk[:4] in (b"GET ", b"POST", b"HEAD", b"PUT ", b"DELE", b"OPTI", b"PATC", b"PRI "):
            buf = first_chunk
            while b"\r\n\r\n" not in buf and len(buf) < 65536:
                more = await asyncio.wait_for(reader.read(16384), timeout=5.0)
                if not more:
                    break
                buf += more

            head_bytes, sep, body_bytes = buf.partition(b"\r\n\r\n")
            head_lower = head_bytes.lower()
            first_line = head_bytes.split(b"\r\n", 1)[0]

            # 2a. Direct C-Speed WebSocket Upgrade (VLESS-WS / VMess-WS / Trojan-WS / SOCKS-WS)
            if b"upgrade: websocket" in head_lower:
                await _handle_raw_websocket(reader, writer, head_bytes, body_bytes, ip)
                return

            # 2b. Explicit Web/Subscription/API/XHTTP routes NEVER trigger HTTP-TCP obfuscation!
            is_web_route = first_line.startswith(_WEB_ROUTE_PREFIXES)

            # 2c. Iran HTTP-Obfuscated VLESS / VMess / Trojan / SOCKS5 TCP (headerType=http)
            is_tcp_obf = False
            if not is_web_route:
                is_tcp_obf = (
                    first_line.startswith((b"GET /tcp", b"POST /tcp", b"GET /iran", b"POST /iran"))
                    or b"host: speedtest.net" in head_lower
                    or b"host: www.speedtest.net" in head_lower
                    or (
                        first_line.startswith(b"GET / ")
                        and b"accept: text/html" not in head_lower
                        and b"sec-fetch-" not in head_lower
                        and b"cookie:" not in head_lower
                    )
                    or bool(body_bytes and not first_line.startswith(b"POST /"))
                )

            if is_tcp_obf:
                # Immediately send HTTP 200 OK header so Windows Winsock / Xray / Sing-box never deadlocks!
                writer.write(_HTTP_OBFUSCATION_RESP)
                await writer.drain()
                if not body_bytes:
                    body_bytes = await asyncio.wait_for(reader.read(8192), timeout=10.0)
                if body_bytes:
                    await _handle_vless_or_trojan_stream(
                        reader, writer, body_bytes, ip,
                        http_obfuscated=True, already_sent_http_resp=True,
                    )
                return

            # 2d. Standard HTTP request (Panel / Sub / API / XHTTP)
            from main import handle_http_stream
            await handle_http_stream(reader, writer, head_bytes, body_bytes, ip)
            return

        # 3. Raw VLESS-TCP / VMess-AEAD-TCP / Trojan-TCP / SOCKS5
        await _handle_vless_or_trojan_stream(reader, writer, first_chunk, ip, http_obfuscated=False)

    except Exception:
        pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


async def start_tcp_relay(
    app_logger=None,
    public_port: int | None = None,
    enable_multiplexer: bool | None = None,
    data_dir: Path | None = None,
    reality_cfg: dict | None = None,
    uuids: list[str] | None = None,
):
    global _servers, logger
    logger = app_logger
    try:
        from main import DATA_DIR
        if data_dir is None:
            data_dir = DATA_DIR
    except Exception:
        pass
    try:
        get_reality_credentials()
    except Exception:
        pass

    if data_dir is not None:
        try:
            tls_ctx = ensure_tls_context(data_dir, domain="speedtest.net")
            tls_srv = await asyncio.start_server(
                _handle_multiplexed_client,
                "127.0.0.1",
                INTERNAL_TLS_PORT,
                ssl=tls_ctx,
                limit=STREAM_LIMIT,
            )
            _servers.append(tls_srv)
        except Exception:
            pass

    if public_port is None:
        mux_env = os.environ.get("MUX_PUBLIC_PORT", "").strip()
        if mux_env.isdigit():
            public_port = int(mux_env)
    if enable_multiplexer is None:
        enable_multiplexer = bool(public_port)

    if enable_multiplexer and public_port:
        await ensure_listening_port(int(public_port))


_bound_ports: set[int] = set()


async def ensure_listening_port(port: int) -> bool:
    global _servers, _bound_ports
    try:
        p = int(port)
    except Exception:
        return False
    if p <= 0 or p > 65535:
        return False
    if p in _bound_ports:
        return True
    try:
        mux_srv = await asyncio.start_server(
            _handle_multiplexed_client,
            "0.0.0.0",
            p,
            reuse_address=True,
            limit=STREAM_LIMIT,
            backlog=2048,
        )
        _servers.append(mux_srv)
        _bound_ports.add(p)
        return True
    except Exception:
        return False


async def stop_tcp_relay():
    global _bound_ports
    _bound_ports.clear()
    global _servers
    for srv in _servers:
        try:
            srv.close()
            await srv.wait_closed()
        except Exception:
            pass
    _servers.clear()