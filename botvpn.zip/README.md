# BotVPN

A lightweight, single-port VLESS VPN server and web dashboard written in pure Python (`asyncio`). Built specifically for container hosts, game/bot hosting panels (Pterodactyl, Pelikan, etc.), and VPS setups where you only get **1 port**, no root access, and no `tun` interface.

## What It Does
- **Runs everything on 1 port**: Multiplexes VLESS (Raw-TCP + REALITY), WebSocket, Subscription links, and the Web Dashboard on the exact same port.
- **Zero external binaries required**: Pure Python 3.8+ standard library core with built-in X25519 TLS 1.3 REALITY handshake and smart DPI fragmentation (`tlshello` / `1-3` split) so configs work on strict networks (including Iran MCI/Irancell, China, and Russia) and on Windows PC TUN mode (`v2rayN` / `Nekoray`) without DNS timeouts.
- **Auto-detects IP, domain, and port**: Automatically detects your server's public IPv4, hostname, and allocated port from environment variables (`SERVER_PORT`, `PORT`, `P_SERVER_PORT`), NAT/STUN, and your browser URL bar.
- **Trusted Port-443 HTTPS Subscriptions**: Automatically generates a CA-verified port-443 `https://` subscription mirror alongside your direct subscription link so strict mobile apps (**Happ**, **v2rayNG**, **Streisand**, **Npv Tunnel**) never throw certificate or non-443 port errors.

---

## Quick Setup Guide (Any Host)

### Option 1: Bot / Game Hosting Panels (Pterodactyl, Bot-Hosting, etc.)
1. **Upload the files**: Upload `main.py`, `tcp_relay.py`, `pages.py`, `relay_vless.py`, `outbound_proxy.py`, and `requirements.txt` to your server's root folder (or upload `botvpn.zip` and extract it).
2. **Set the startup file**: In your panel's **Startup** tab, set the main file to `main.py`.
3. **Start the server**: Click **Start**.
4. **Open the dashboard**: Check the console logs—it will print your exact dashboard URL and port:
   ```text
   [PANEL] http://YOUR_HOST:PORT/
   ```
5. **Copy your config or subscription**:
   - Open `http://YOUR_HOST:PORT/` in your browser.
   - Click **Copy Sub** to copy your HTTPS subscription link (works in **Happ**, **v2rayNG**, **v2rayN**, **Streisand**).
   - Or click **Raw-TCP** / **REALITY** to copy the direct `vless://` link (works directly in **Npv Tunnel**, **v2rayN**, **v2rayNG**, **Happ**).

---

### Option 2: Any Linux VPS / Dedicated Server
```bash
git clone https://github.com/YOUR_USERNAME/botvpn.git
cd botvpn
pip install -r requirements.txt
PORT=2020 python3 main.py
```
To keep it running 24/7 in the background:
```bash
nohup env PORT=2020 python3 main.py > botvpn.log 2>&1 &
```

---

## Which Config Should You Use?

Each user profile gives you two VLESS configs inside your subscription (and one-click copy buttons on the dashboard):

| Config Button | Best For | Why |
| :--- | :--- | :--- |
| **Raw-TCP** (`vless://...`) | **Npv Tunnel**, **v2rayN (Windows PC)**, **v2rayNG** | Fastest ping and lowest CPU overhead. Uses smart TCP fragmentation + port-53 DNS interception so Windows TUN mode works smoothly. |
| **REALITY** (`vless://...security=reality`) | **Happ**, **Streisand**, **v2rayNG**, heavily filtered mobile data | Wraps traffic in a genuine TLS 1.3 X25519 handshake spoofing `www.yahoo.com` to bypass deep packet inspection (DPI). |
| **Copy Sub** (`https://...`) | **Happ**, **v2rayNG**, **v2rayN**, **Streisand** | Imports all configs at once over a trusted CA-signed Port-443 HTTPS link. |

---

## Environment Variables (Optional)

You don't need to configure anything—BotVPN detects your IP and port automatically. If you want to override anything manually:

| Variable | Description | Default |
| :--- | :--- | :--- |
| `PORT` / `SERVER_PORT` | Port to listen on | Auto-detected (fallback `2020`) |
| `PUBLIC_IP` | Override detected public IPv4 address | Auto-detected |
| `DOMAIN` | Set a custom domain or node hostname | Auto-detected from browser/host |
| `REALITY_SNI` | Target SNI for REALITY handshake | `www.yahoo.com` |
| `DASH_PASS` | Optional password to lock the web dashboard | None (open) |

---

## Files Included
- `main.py` — Single-port multiplexer (VLESS, REALITY TLS, HTTP/HTTPS, WebSocket, and Dashboard API).
- `tcp_relay.py` — Pure-Python VLESS engine, X25519 TLS 1.3 REALITY server, UDP-over-TCP DoH DNS resolver, and DPI packet fragmenter.
- `pages.py` — Single-page Web UI dashboard with QR code modal, live traffic stats, and 1-click config/sub buttons.
- `outbound_proxy.py` — Upstream proxy chaining support (`socks5://`, `http://`, `vless://`).
- `relay_vless.py` — Outbound VLESS client helper for multi-hop chaining.
- `requirements.txt` — Optional `cryptography` package (used for fast X25519 TLS 1.3 REALITY).
