# BotVPN

A lightweight, single-port VLESS TCP-REALITY VPN server and web panel written in pure Python (`asyncio`). Designed for bot/game hosting panels (Pterodactyl, Bot-Hosting, KataBump, Nexcloud, etc.) and Linux VPS setups where you only get **1 port**, no root access, and no `tun` driver.

## Features
- **One Unified Config (`VLESS TCP-REALITY`)**: Everything is built into a single fast `VLESS TCP-REALITY` configuration (`sni=www.speedtest.net`, `fp=chrome`) that works across **Happ**, **NPV Tunnel**, **v2rayN** (both TUN mode & System Proxy), and **v2rayNG**.
- **Optimized for Instagram, YouTube & Border Networks**:
  - Automatically blocks UDP port 443 (`QUIC / HTTP3`) inside TCP streams so Instagram Reels/Stories (`Proxygen`) and YouTube (`Cronet`) immediately use full-speed TCP TLS 1.3 (`HTTP/2`) with zero stall.
  - Sniffs TLS `SNI` (`i.instagram.com`, `*.cdninstagram.com`, `*.googlevideo.com`) on the server and resolves CDN edges using a 64-worker parallel DNS engine (`1.1.1.1`, `8.8.8.8`, `9.9.9.9` + local datacenter DNS) with automatic multi-IP failover and `TCP_MAXSEG=1360` MSS clamping.
- **Auto-Detects Domain/IP & Port**: Automatically picks up your node hostname/IP and port from environment variables (`SERVER_PORT`, `PORT`, `PUBLIC_PORT`, `APP_PORT`) and your browser URL bar.
- **Zero-Error HTTPS Subscriptions**: Automatically generates a Port-443 CA-signed `https://` subscription link so **Happ**, **v2rayN**, and **NPV Tunnel** import and update cleanly.

## Step-by-Step Setup Guide

### 1. Bot / Game Hosting Panels (Pterodactyl, Bot-Hosting, KataBump, Nexcloud, etc.)
1. **Upload & Extract**: Upload `botvpn.zip` to your server's File Manager and click **Unarchive / Extract** so `main.py`, `tcp_relay.py`, `pages.py`, `outbound_proxy.py`, `relay_vless.py`, `speed_limit.py`, `app.py`, and `requirements.txt` are in the root directory.
2. **Startup File**: Set your panel's startup file to `main.py` (or `app.py` if your host defaults to `app.py`).
3. **Start the Server**: Click **Start**. In the console you will see:
   ```text
   [BotVPN v26.0.0] Running on 0.0.0.0:PORT -> Panel: http://YOUR_HOST:PORT/login (Default login: admin / admin)
   ```
4. **Open the Panel**:
   - Visit `http://YOUR_HOST:PORT/login` in your browser.
   - Default username: `admin`
   - Default password: `admin` *(change this anytime in the **Settings** tab)*.
5. **Connect**:
   - Click **Copy Config** to copy your unified `VLESS TCP-REALITY` config, or click **Copy Sub** to copy the `https://` subscription URL.

### 2. Any Linux VPS (Ubuntu / Debian / Alpine)
```bash
git clone https://github.com/YOUR_USERNAME/botvpn.git
cd botvpn
pip install -r requirements.txt
PORT=2020 python3 main.py
```
To run in the background 24/7:
```bash
nohup env PORT=2020 python3 main.py > botvpn.log 2>&1 &
```
