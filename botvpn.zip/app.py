# Launcher wrapper for hosting panels that run app.py / bot.py / index.py
import asyncio
from main import run_server, app

if __name__ == "__main__":
    asyncio.run(run_server())
