# Universal BotVPN Entrypoint (works whether panel runs bot.py, app.py, index.py, server.py, start.py, or main.py)
import asyncio
from main import run_server, app

if __name__ == "__main__":
    asyncio.run(run_server())
