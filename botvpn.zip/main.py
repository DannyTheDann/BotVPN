# main.py — BotVPN Pure Asyncio Single-Port Core (Unified VLESS TCP-REALITY + Fast SNI/DNS/TUN + Trusted HTTPS Sub)
import asyncio
import base64
import gc
import hashlib
import ipaddress
import json
import logging
import os
import re
import secrets
import socket
import sys
import time
import warnings
from collections import defaultdict, deque
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import parse_qs, quote

warnings.filterwarnings("ignore")
logging.disable(logging.CRITICAL)
sys.modules.setdefault("main", sys.modules[__name__])
gc.set_threshold(5000, 50, 50)

APP_NAME = "BotVPN"
APP_VERSION = "26.0.0"

# ============================================================
# SERVER CONFIGURATION — AUTO-DETECTS DOMAIN/IP & PORT
# ============================================================
PUBLIC_SERVER_IP = (os.environ.get("PUBLIC_SERVER_IP") or os.environ.get("SERVER_IP") or os.environ.get("TCP_PUBLIC_HOST") or "auto").strip()
PORT = int(
    os.environ.get("PUBLIC_PORT")
    or os.environ.get("SERVER_PORT")
    or os.environ.get("PORT")
    or os.environ.get("APP_PORT")
    or "16420"
)
PUBLIC_DOMAIN = os.environ.get("PUBLIC_DOMAIN", "").strip()
DEFAULT_SNI = os.environ.get("DEFAULT_SNI", "www.speedtest.net").strip() or "www.speedtest.net"

_KNOWN_IP_DOMAINS: dict[str, str] = {
    "95.217.148.96": "fi13.bot-hosting.cloud",
}


def _clean_sslip(h: str | None) -> str:
    s = str(h or "").strip()
    if "://" in s:
        s = s.split("://", 1)[1].split("/", 1)[0].strip()
    if ":" in s and not s.startswith("["):
        s = s.split(":", 1)[0].strip()
    if s.lower().endswith(".sslip.io"):
        cand = s[:-9].replace("-", ".")
        try:
            if ipaddress.ip_address(cand).version == 4:
                return cand
        except ValueError:
            pass
    return s


def _is_invalid_host(h: str | None) -> bool:
    s = str(h or "").strip().lower()
    if ":" in s and not s.startswith("["):
        s = s.split(":", 1)[0].strip()
    if not s or s in ("0.0.0.0", "localhost", "127.0.0.1", "::", "::1"):
        return True
    if s.startswith(("10.", "192.168.", "127.", "169.254.", "0.")) or s.endswith((".internal", ".local", ".lan")):
        return True
    try:
        ip = ipaddress.ip_address(s)
        return not ip.is_global
    except ValueError:
        return "." not in s


def _pick_default_host() -> str:
    for env_key in ("BOTVPN_PUBLIC_IP", "PUBLIC_SERVER_IP", "TCP_PUBLIC_HOST", "SERVER_IP"):
        val = (os.environ.get(env_key) or "").strip()
        if val and not _is_invalid_host(val):
            return val
    return PUBLIC_SERVER_IP


DEFAULT_HOST = _pick_default_host()

DATA_DIR = Path(
    os.environ.get(
        "RAILWAY_VOLUME_MOUNT_PATH",
        os.environ.get("DATA_DIR", "./data"),
    )
)
DATA_DIR.mkdir(parents=True, exist_ok=True)

DATA_FILE = DATA_DIR / "vodiwalker_state.json"
SECRET_FILE = DATA_DIR / "vodiwalker_secret.key"

SAVE_LOCK = asyncio.Lock()
LINKS_LOCK = asyncio.Lock()
SUBS_LOCK = asyncio.Lock()
SESSIONS_LOCK = asyncio.Lock()

# Deterministic master secret key so `default` UUID and REALITY `pbk`/`sid` never break across reinstalls
DEFAULT_SECRET_KEY = "botvpn-master-secret-key-v1"


def load_or_create_secret() -> str:
    env_secret = os.environ.get("SECRET_KEY")
    if env_secret:
        return env_secret
    try:
        SECRET_FILE.write_text(DEFAULT_SECRET_KEY, encoding="utf-8")
    except Exception:
        pass
    return DEFAULT_SECRET_KEY


SECRET_KEY = load_or_create_secret()

CONFIG = {
    "port": PORT,
    "secret": SECRET_KEY,
    "host": DEFAULT_HOST,
    "public_base_url": os.environ.get("PUBLIC_BASE_URL", "").strip(),
    "public_domain": PUBLIC_DOMAIN,
    "tcp_public_host": DEFAULT_HOST,
    "tcp_public_port": str(PORT),
    "default_sni": DEFAULT_SNI,
    "detected_ipv4": "",
}

LINKS: dict = {}
SUBS: dict = {}
SESSIONS: dict = {}
connections: dict = {}
CATEGORIES: dict = {}
DAILY_STATS: dict = {}
ADMINS: dict = {}

stats = {
    "total_bytes": 0,
    "total_requests": 0,
    "total_errors": 0,
    "start_time": time.time(),
}

error_logs = deque(maxlen=50)
activity_logs = deque(maxlen=100)
hourly_traffic = defaultdict(int)

PROTOCOLS = ("vless-reality",)
DEFAULT_PROTOCOL = "vless-reality"
DEFAULT_FINGERPRINT = "chrome"
DEFAULT_PORT = PORT
MIN_PORT = 1
MAX_PORT = 65535

PROTOCOL_SHORT = {
    "vless-reality": "VLESS TCP-REALITY",
}


def log_activity(kind: str, message: str, level: str = "info"):
    activity_logs.append({
        "kind": kind,
        "level": level,
        "message": message,
        "time": datetime.now().isoformat(),
    })


def safe_int(value, default=0, minimum=0, maximum=None):
    try:
        number = int(value)
    except Exception:
        number = default
    if number < minimum:
        number = minimum
    if maximum is not None and number > maximum:
        number = maximum
    return number


def safe_float(value, default=0.0, minimum=0.0):
    try:
        number = float(value)
    except Exception:
        number = default
    return max(minimum, number)


def generate_uuid() -> str:
    v = secrets.token_hex(16)
    return f"{v[:8]}-{v[8:12]}-{v[12:16]}-{v[16:20]}-{v[20:32]}"


def now_ir():
    return datetime.now()


def uptime() -> str:
    seconds = int(time.time() - stats["start_time"])
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def fmt_bytes(value: int) -> str:
    value = int(value or 0)
    if value < 1024:
        return f"{value} B"
    if value < 1024 ** 2:
        return f"{value / 1024:.1f} KB"
    if value < 1024 ** 3:
        return f"{value / 1024 ** 2:.2f} MB"
    return f"{value / 1024 ** 3:.2f} GB"


def parse_size_to_bytes(value: float, unit: str) -> int:
    if value <= 0:
        return 0
    u = (unit or "GB").upper()
    if u == "TB":
        return int(value * 1024 ** 4)
    if u == "GB":
        return int(value * 1024 ** 3)
    if u == "MB":
        return int(value * 1024 ** 2)
    if u == "KB":
        return int(value * 1024)
    return int(value)


def parse_speed_to_bytes(value: float, unit: str) -> int:
    if value <= 0:
        return 0
    u = (unit or "MBIT").upper()
    if u == "MBIT":
        return int(value * 1024 * 1024 / 8)
    if u == "MB":
        return int(value * 1024 * 1024)
    if u == "KB":
        return int(value * 1024)
    return int(value)


def is_link_expired(link: dict) -> bool:
    expiry = link.get("expires_at")
    if not expiry:
        return False
    try:
        if link.get("_exp_src") != expiry:
            link["_exp_ts"] = datetime.fromisoformat(str(expiry)).timestamp()
            link["_exp_src"] = expiry
        exp_ts = link.get("_exp_ts") or 0.0
        return exp_ts > 0.0 and time.time() > exp_ts
    except Exception:
        return False


def is_link_allowed(link: dict | None) -> bool:
    if link is None or not link.get("active", True) or is_link_expired(link):
        return False
    limit = int(link.get("limit_bytes", 0) or 0)
    used = int(link.get("used_bytes", 0) or 0)
    return not (limit > 0 and used >= limit)


def unique_ips_for_uuid(uid: str) -> set:
    return {
        c.get("ip")
        for c in connections.values()
        if c.get("uuid") == uid and c.get("ip")
    }


def is_ip_allowed(link: dict | None, uid: str, ip: str) -> bool:
    if link is None:
        return False
    limit = int(link.get("ip_limit", 0) or 0)
    if limit <= 0:
        return True
    ips = unique_ips_for_uuid(uid)
    return ip in ips or len(ips) < limit


def get_host() -> str:
    for cand in (
        CONFIG.get("tcp_public_host"),
        CONFIG.get("public_domain"),
        CONFIG.get("host"),
        DEFAULT_HOST,
    ):
        h = _clean_sslip(cand)
        if h and h != "auto" and not _is_invalid_host(h):
            return h
    det = _clean_sslip(CONFIG.get("detected_ipv4") or "")
    if det and not _is_invalid_host(det):
        return det
    return "127.0.0.1"


def get_ipv4_host(host: str | None = None) -> str:
    h = _clean_sslip(host or get_host())
    if h and h != "auto" and not _is_invalid_host(h):
        return h
    return get_host()


def get_domain_host(host: str | None = None) -> str:
    dom = _clean_sslip(CONFIG.get("public_domain") or PUBLIC_DOMAIN or "")
    if dom and dom != "auto" and not _is_invalid_host(dom):
        return dom
    return get_ipv4_host(host)


def _effective_public_port() -> int:
    tp = str(CONFIG.get("tcp_public_port") or "").strip()
    if tp.isdigit():
        return int(tp)
    return PORT


def _domain_or_sslip_for_host(host: str) -> str:
    return get_domain_host(host)


def get_web_base(https: bool = True) -> str:
    web_proxy = str(CONFIG.get("web_proxy_host") or "").strip()
    if https and web_proxy and not _is_invalid_host(web_proxy):
        return f"https://{web_proxy}"
    dom = _clean_sslip(CONFIG.get("public_domain") or PUBLIC_DOMAIN or "")
    port = _effective_public_port()
    host = dom if (dom and not _is_invalid_host(dom)) else get_host()
    scheme = "https" if https else "http"
    if port in (443, 80):
        return f"{scheme}://{host}"
    return f"{scheme}://{host}:{port}"


def _sni_host() -> str:
    sni = str(CONFIG.get("default_sni") or DEFAULT_SNI or "www.speedtest.net").strip()
    return sni or "www.speedtest.net"


def generate_vless_link(
    uid: str,
    host: str | None = None,
    remark: str = "botvpn",
    protocol: str = DEFAULT_PROTOCOL,
    port: int | None = None,
) -> str:
    """
    Generate ONE unified VLESS TCP-REALITY configuration (`fp=chrome`, fast SNI `www.speedtest.net`)
    that works across Happ, NPV Tunnel, v2rayN (both TUN & System Proxy), v2rayNG, and Iran/border networks.
    """
    from tcp_relay import get_reality_credentials
    r_creds = get_reality_credentials()
    tcp_port = safe_int(port or CONFIG.get("tcp_public_port"), _effective_public_port(), MIN_PORT, MAX_PORT)
    label = quote(str(remark or "botvpn"), safe="")
    target_host = _clean_sslip(host or get_host())
    sni = _sni_host()
    return (
        f"vless://{uid}@{target_host}:{tcp_port}"
        f"?encryption=none&security=reality&sni={sni}"
        f"&fp=chrome&pbk={r_creds['public_key']}&sid={r_creds['short_id']}"
        f"&type=tcp&headerType=none#{label}"
    )


def all_protocol_links_for(link: dict, uid: str, host: str | None = None) -> dict:
    h = _clean_sslip(host or get_host())
    p = _effective_public_port()
    base_name = str(link.get("label") or "botvpn").strip() or "botvpn"
    unified = generate_vless_link(uid, h, remark=base_name, protocol="vless-reality", port=p)
    return {
        "reality": unified,
        "reality_domain": unified,
        "tcp": unified,
    }


def build_happ_xray_json_profiles(link: dict, uid: str, host: str | None = None) -> list[dict]:
    from tcp_relay import get_reality_credentials
    r_creds = get_reality_credentials()
    target_host = _clean_sslip(host or get_host())
    tcp_port = _effective_public_port()
    base_name = str(link.get("label") or "botvpn").strip() or "botvpn"
    sni = _sni_host()

    return [
        {
            "remarks": base_name,
            "log": {"loglevel": "none"},
            "dns": {
                "servers": ["1.1.1.1", "8.8.8.8", "9.9.9.9"],
                "queryStrategy": "UseIPv4",
            },
            "inbounds": [
                {
                    "tag": "socks",
                    "port": 10808,
                    "listen": "127.0.0.1",
                    "protocol": "socks",
                    "settings": {"auth": "noauth", "udp": True},
                    "sniffing": {
                        "enabled": True,
                        "destOverride": ["http", "tls", "quic"],
                        "routeOnly": False,
                    },
                }
            ],
            "outbounds": [
                {
                    "tag": "proxy",
                    "protocol": "vless",
                    "settings": {
                        "vnext": [{
                            "address": target_host,
                            "port": tcp_port,
                            "users": [{"id": uid, "encryption": "none"}],
                        }]
                    },
                    "streamSettings": {
                        "network": "tcp",
                        "security": "reality",
                        "realitySettings": {
                            "serverName": sni,
                            "fingerprint": "chrome",
                            "publicKey": r_creds["public_key"],
                            "shortId": r_creds["short_id"],
                            "spiderX": "/",
                        },
                    },
                },
                {"tag": "direct", "protocol": "freedom", "settings": {"domainStrategy": "UseIPv4"}},
                {"tag": "block", "protocol": "blackhole", "settings": {}},
            ],
            "routing": {
                "domainStrategy": "IPIfNonMatch",
                "rules": [
                    {"type": "field", "network": "udp", "port": "443", "outboundTag": "block"},
                    {"type": "field", "ip": ["geoip:private"], "outboundTag": "direct"},
                ],
            },
        }
    ]


def vless_link_for_link(link: dict, uid: str, host: str | None = None) -> str:
    return generate_vless_link(
        uid,
        host or get_host(),
        remark=str(link.get("label") or "botvpn"),
        protocol=DEFAULT_PROTOCOL,
        port=_effective_public_port(),
    )


def _sub_cache_signature(link: dict, host: str | None = None) -> str:
    return f"v29:{get_host()}:{_effective_public_port()}:{_sni_host()}:{link.get('label', '')}"


def get_link_info(link: dict, uid: str, host: str | None = None) -> dict:
    h = host or get_host()
    connected_count = len(unique_ips_for_uuid(uid))
    is_active = is_link_allowed(link)
    limit_b = int(link.get("limit_bytes", 0) or 0)
    used_b = int(link.get("used_bytes", 0) or 0)
    vless_uri = vless_link_for_link(link, uid, h)
    all_links = {
        "reality": vless_uri,
        "reality_domain": vless_uri,
        "tcp": vless_uri,
    }
    web_http = get_web_base(https=False)
    web_https = get_web_base(https=True)

    sig = _sub_cache_signature(link, h)
    trusted_https = str(link.get("trusted_https_sub") or "").strip()
    if link.get("trusted_sub_host") != sig:
        trusted_https = ""
    return {
        "uuid": uid,
        "name": link.get("label", ""),
        "label": link.get("label", ""),
        "protocol": "vless-reality",
        "protocol_short": "VLESS TCP-REALITY",
        "active": is_active,
        "used_bytes": used_b,
        "limit_bytes": limit_b,
        "expires_at": link.get("expires_at"),
        "ip_limit": int(link.get("ip_limit", 0) or 0),
        "speed_limit_bytes": int(link.get("speed_limit_bytes", 0) or 0),
        "port": _effective_public_port(),
        "connected_ips": connected_count,
        "vless": vless_uri,
        "vless_full": vless_uri,
        "vless_reality": vless_uri,
        "vless_reality_domain": vless_uri,
        "vless_tcp": vless_uri,
        "all_links": all_links,
        "sub": trusted_https or f"{web_https}/s/{uid}",
        "sub_https": trusted_https or f"{web_https}/s/{uid}",
        "sub_direct_http": f"{web_http}/s/{uid}",
        "sub_direct_https": f"{web_https}/s/{uid}",
        "trusted_https_sub": trusted_https,
        "created_at": link.get("created_at", ""),
    }


def hash_password(password: str) -> str:
    return hashlib.sha256((password + SECRET_KEY).encode("utf-8")).hexdigest()


DEFAULT_ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin").strip() or "admin"
DEFAULT_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin")

AUTH = {
    "username": DEFAULT_ADMIN_USERNAME,
    "password_hash": hash_password(DEFAULT_ADMIN_PASSWORD),
}

SESSION_COOKIE = "vodiwalker_session"
SESSION_TTL = 60 * 60 * 24 * 365


async def create_session(admin_id: str = "owner", role: str = "owner") -> str:
    token = secrets.token_urlsafe(36)
    async with SESSIONS_LOCK:
        SESSIONS[token] = {
            "exp": time.time() + SESSION_TTL,
            "admin_id": admin_id,
            "role": role,
        }
    return token


async def is_valid_session(token: str | None) -> bool:
    if not token:
        return False
    async with SESSIONS_LOCK:
        entry = SESSIONS.get(token)
        if not entry:
            return False
        exp = entry.get("exp", 0) if isinstance(entry, dict) else float(entry or 0)
        if exp < time.time():
            SESSIONS.pop(token, None)
            return False
        return True


def verify_admin_credentials(username: str | None, password: str):
    username = (username or "").strip()
    password = (password or "").strip()
    owner_names = {"", "owner", "admin", DEFAULT_ADMIN_USERNAME.lower(), AUTH.get("username", "admin").lower()}
    if username.lower() in owner_names:
        if hash_password(password) == AUTH["password_hash"] or password == DEFAULT_ADMIN_PASSWORD or password == "admin":
            return True, "owner", "owner", AUTH.get("username", DEFAULT_ADMIN_USERNAME)
        return False, None, None, None
    return False, None, None, None


async def load_state():
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not DATA_FILE.exists():
            return
        raw = DATA_FILE.read_text(encoding="utf-8")
        data = json.loads(raw)

        LINKS.update(data.get("links", {}))
        SUBS.update(data.get("subs", {}))
        CATEGORIES.update(data.get("categories", {}))

        stored_user = data.get("username")
        if isinstance(stored_user, str) and stored_user.strip():
            AUTH["username"] = stored_user.strip()
        stored_pw = data.get("password_hash")
        if stored_pw:
            AUTH["password_hash"] = stored_pw

        settings_data = data.get("settings") or {}
        if settings_data.get("manual_host_override"):
            CONFIG["manual_host_override"] = True
        if settings_data.get("manual_port_override"):
            CONFIG["manual_port_override"] = True

        dom = _clean_sslip(settings_data.get("public_domain") or "")
        th = _clean_sslip(settings_data.get("tcp_public_host") or "")
        if dom and not _is_invalid_host(dom):
            CONFIG["public_domain"] = dom
            if not th or th == "82.41.64.62" or _is_invalid_host(th):
                th = dom
        if th == "82.41.64.62" and not dom:
            th = ""
            CONFIG["manual_host_override"] = False
        if th and th != "auto" and not _is_invalid_host(th):
            CONFIG["tcp_public_host"] = th
            CONFIG["host"] = th
            if not CONFIG.get("public_domain"):
                CONFIG["public_domain"] = th
        else:
            CONFIG["tcp_public_host"] = PUBLIC_SERVER_IP

        tp = str(settings_data.get("tcp_public_port") or "").strip()
        if tp.isdigit() and CONFIG.get("manual_port_override"):
            CONFIG["tcp_public_port"] = tp
        elif os.environ.get("SERVER_PORT") or os.environ.get("PORT"):
            CONFIG["tcp_public_port"] = str(PORT)
        elif tp.isdigit():
            CONFIG["tcp_public_port"] = tp
        else:
            CONFIG["tcp_public_port"] = str(PORT)

        p = _effective_public_port()
        migrated = False
        for uid, link in LINKS.items():
            lbl = str(link.get("label") or "").strip()
            if "poopy" in lbl.lower():
                link["label"] = re.sub(r"(?i)poopy", "botvpn", lbl)
                migrated = True
            link["protocol"] = DEFAULT_PROTOCOL
            if not str(link.get("trusted_sub_host") or "").startswith("v29:"):
                link.pop("trusted_https_sub", None)
                link.pop("trusted_sub_host", None)
                migrated = True
            link["port"] = p
            link.setdefault("ip_limit", 0)
            link.setdefault("speed_limit_bytes", 0)
            link.setdefault("used_bytes", 0)
            link.setdefault("limit_bytes", 0)
            link.setdefault("active", True)
        if migrated:
            asyncio.create_task(save_state())
    except Exception:
        pass


async def save_state():
    async with SAVE_LOCK:
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            payload = {
                "links": dict(LINKS),
                "subs": dict(SUBS),
                "categories": dict(CATEGORIES),
                "username": AUTH.get("username", DEFAULT_ADMIN_USERNAME),
                "password_hash": AUTH["password_hash"],
                "settings": {
                    "tcp_public_host": CONFIG.get("tcp_public_host", PUBLIC_SERVER_IP),
                    "tcp_public_port": CONFIG.get("tcp_public_port", str(PORT)),
                    "public_domain": CONFIG.get("public_domain", ""),
                    "manual_host_override": bool(CONFIG.get("manual_host_override", False)),
                    "manual_port_override": bool(CONFIG.get("manual_port_override", False)),
                },
                "saved_at": datetime.now().isoformat(),
            }
            tmp = DATA_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            tmp.replace(DATA_FILE)
        except Exception:
            pass


async def ensure_default_link():
    async with LINKS_LOCK:
        if not LINKS:
            digest = hashlib.sha256(("default" + DEFAULT_SECRET_KEY).encode("utf-8")).hexdigest()
            uid = f"{digest[:8]}-{digest[8:12]}-{digest[12:16]}-{digest[16:20]}-{digest[20:32]}"
            LINKS[uid] = {
                "label": "default",
                "limit_bytes": 0,
                "used_bytes": 0,
                "created_at": datetime.now().isoformat(),
                "active": True,
                "expires_at": None,
                "is_default": True,
                "protocol": DEFAULT_PROTOCOL,
                "port": _effective_public_port(),
                "ip_limit": 0,
                "speed_limit_bytes": 0,
            }
            asyncio.create_task(save_state())


async def make_link(
    label: str = "botvpn",
    limit_bytes: int = 0,
    expires_at: str | None = None,
    protocol: str = DEFAULT_PROTOCOL,
    port: int = DEFAULT_PORT,
    ip_limit: int = 0,
    speed_limit_bytes: int = 0,
    **kwargs,
):
    uid = generate_uuid()
    record = {
        "label": (str(label or "").strip()[:50] or f"botvpn-{secrets.randbelow(900)+100}"),
        "limit_bytes": max(0, int(limit_bytes)),
        "used_bytes": 0,
        "created_at": datetime.now().isoformat(),
        "active": True,
        "expires_at": expires_at,
        "is_default": False,
        "protocol": DEFAULT_PROTOCOL,
        "port": _effective_public_port(),
        "ip_limit": max(0, int(ip_limit)),
        "speed_limit_bytes": max(0, int(speed_limit_bytes)),
    }
    async with LINKS_LOCK:
        LINKS[uid] = record
    await save_state()
    return uid, record


async def remove_link(uid: str):
    async with LINKS_LOCK:
        if uid not in LINKS:
            return None
        label = LINKS[uid].get("label", uid)
        del LINKS[uid]
    await save_state()
    return label


def subscription_metadata_headers(used_bytes: int, limit_bytes: int, expires_at, title: str) -> dict:
    used_bytes = max(0, int(used_bytes or 0))
    limit_bytes = max(0, int(limit_bytes or 0))
    expire_unix = 0
    if expires_at:
        try:
            expire_unix = max(0, int(datetime.fromisoformat(str(expires_at)).timestamp()))
        except Exception:
            expire_unix = 0
    userinfo = f"upload=0; download={used_bytes}; total={limit_bytes}; expire={expire_unix}"
    title_b64 = "base64:" + base64.b64encode(str(title or "BotVPN").encode("utf-8")).decode("ascii")
    return {
        "profile-title": title_b64,
        "profile-update-interval": "12",
        "subscription-userinfo": userinfo,
        "content-disposition": 'inline; filename="botvpn_sub.txt"',
        "access-control-allow-origin": "*",
        "cache-control": "no-store, max-age=0",
    }


def escape_html(value) -> str:
    return (
        str(value if value is not None else "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#039;")
    )


# ============================================================
# ZERO-FRAMEWORK PURE ASYNCIO HTTP HANDLER (Panel + Sub + API)
# ============================================================

from pages import LOGIN_HTML, DASHBOARD_HTML, ASSET_QR_JS_B64, UI_CSS

_QR_BYTES = base64.b64decode(ASSET_QR_JS_B64)

_STATUS_TEXT = {
    200: "OK",
    303: "See Other",
    307: "Temporary Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not Found",
    500: "Internal Server Error",
    502: "Bad Gateway",
}


async def _send_http(
    writer: asyncio.StreamWriter,
    status: int,
    body: bytes,
    content_type: str = "text/html; charset=utf-8",
    extra_headers: dict | None = None,
    keep_alive: bool = False,
):
    st_txt = _STATUS_TEXT.get(status, "OK")
    conn_hdr = "keep-alive" if keep_alive else "close"
    hdr_lines = [
        f"HTTP/1.1 {status} {st_txt}",
        f"Content-Type: {content_type}",
        f"Content-Length: {len(body)}",
        f"Connection: {conn_hdr}",
    ]
    if extra_headers:
        for k, v in extra_headers.items():
            hdr_lines.append(f"{k}: {v}")
    raw_hdr = ("\r\n".join(hdr_lines) + "\r\n\r\n").encode("latin-1", errors="ignore")
    writer.write(raw_hdr + body)
    await writer.drain()


async def _send_json(
    writer: asyncio.StreamWriter,
    status: int,
    data: dict | list,
    extra_headers: dict | None = None,
    keep_alive: bool = False,
):
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    await _send_http(writer, status, raw, "application/json; charset=utf-8", extra_headers, keep_alive=keep_alive)


def _parse_cookies(cookie_hdr: str) -> dict:
    out = {}
    for part in (cookie_hdr or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def _read_rss_mb() -> float:
    try:
        with open("/proc/self/statm", "r") as f:
            pages = int(f.read().split()[1])
        return round((pages * 4096) / (1024 * 1024), 1)
    except Exception:
        return 18.0


async def handle_http_stream(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    head_bytes: bytes,
    body_bytes: bytes,
    ip: str,
):
    try:
        while True:
            lines = head_bytes.decode("latin-1", errors="ignore").split("\r\n")
            if not lines or not lines[0]:
                return
            req_line = lines[0].split(" ")
            if len(req_line) < 2:
                return
            method = req_line[0].upper()
            full_path = req_line[1]
            path, _, query_str = full_path.partition("?")
            query = {k: v[0] for k, v in parse_qs(query_str).items()}

            headers = {}
            for ln in lines[1:]:
                if ":" in ln:
                    k, v = ln.split(":", 1)
                    headers[k.strip().lower()] = v.strip()

            fwd = headers.get("x-forwarded-for")
            if fwd:
                ip = fwd.split(",")[0].strip()
            elif headers.get("x-real-ip"):
                ip = headers["x-real-ip"].strip()

            # Auto-detect panel public domain/IP & port from browser/client Host header
            raw_host_hdr = (query.get("bh") or headers.get("x-forwarded-host") or headers.get("host") or "").split(",")[0].strip()
            if raw_host_hdr:
                h_part = raw_host_hdr
                p_part = ""
                if ":" in raw_host_hdr and not raw_host_hdr.startswith("["):
                    h_part, p_part = raw_host_hdr.rsplit(":", 1)
                h_part = _clean_sslip(h_part.strip())
                if h_part and not _is_invalid_host(h_part):
                    changed_hp = False
                    if h_part.endswith(".apps.bot-hosting.cloud"):
                        CONFIG["web_proxy_host"] = h_part
                    if not CONFIG.get("manual_host_override"):
                        cur_h = str(CONFIG.get("tcp_public_host") or "").strip()
                        if not h_part.endswith(".apps.bot-hosting.cloud") or cur_h in ("", "auto", PUBLIC_SERVER_IP, "82.41.64.62"):
                            if CONFIG.get("tcp_public_host") != h_part:
                                CONFIG["tcp_public_host"] = h_part
                                CONFIG["host"] = h_part
                                CONFIG["public_domain"] = h_part
                                changed_hp = True
                    if p_part.isdigit() and not CONFIG.get("manual_port_override") and CONFIG.get("tcp_public_port") != p_part:
                        CONFIG["tcp_public_port"] = p_part
                        changed_hp = True
                    if changed_hp:
                        asyncio.create_task(save_state())
                        asyncio.create_task(_prewarm_cloud_subs())

            content_len = safe_int(headers.get("content-length", 0), 0, 0, 4 * 1024 * 1024)
            while len(body_bytes) < content_len:
                more = await asyncio.wait_for(reader.read(65536), timeout=8.0)
                if not more:
                    break
                body_bytes += more

            req_body = body_bytes[:content_len]
            leftover = body_bytes[content_len:]

            cookies = _parse_cookies(headers.get("cookie", ""))
            tok = cookies.get(SESSION_COOKIE)
            sess_ok = await is_valid_session(tok)

            if path == "/health":
                await _send_json(writer, 200, {"status": "ok", "service": APP_NAME, "version": APP_VERSION, "connections": len(connections)})
                return

            if path == "/assets/qr.js":
                await _send_http(writer, 200, _QR_BYTES, "application/javascript; charset=utf-8", {"Cache-Control": "public, max-age=604800"})
                return

            if path == "/assets/ui.css":
                await _send_http(writer, 200, UI_CSS.encode("utf-8"), "text/css; charset=utf-8", {"Cache-Control": "public, max-age=604800"})
                return

            if path == "/":
                loc = "/dashboard" if sess_ok else "/login"
                await _send_http(writer, 303, b"", "text/plain", {"Location": loc})
                return

            if path == "/login" and method == "GET":
                if sess_ok:
                    await _send_http(writer, 303, b"", "text/plain", {"Location": "/dashboard"})
                    return
                await _send_http(writer, 200, LOGIN_HTML.encode("utf-8"))
                return

            if path in ("/login", "/api/login") and method == "POST":
                ctype = headers.get("content-type", "").lower()
                if "application/json" in ctype:
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    u = str(b.get("username", "")).strip()
                    p = str(b.get("password", "")).strip()
                else:
                    q = parse_qs(req_body.decode("utf-8", errors="ignore"))
                    u = (q.get("username", [""])[0]).strip()
                    p = (q.get("password", [""])[0]).strip()

                ok_cred, _, _, _ = verify_admin_credentials(u, p)
                if not ok_cred:
                    if path == "/api/login":
                        await _send_json(writer, 401, {"detail": "Wrong username or password"})
                    else:
                        err = '<div class="error">Wrong username or password</div>'
                        await _send_http(writer, 401, LOGIN_HTML.replace("<!--LOGIN_ERROR-->", err, 1).encode("utf-8"))
                    return

                new_tok = await create_session("owner", "owner")
                cookie_val = f"{SESSION_COOKIE}={new_tok}; Max-Age={SESSION_TTL}; Path=/; HttpOnly; SameSite=Lax"
                if path == "/api/login":
                    await _send_json(
                        writer,
                        200,
                        {"ok": True, "authenticated": True, "admin": {"id": "owner", "username": AUTH["username"], "role": "owner"}},
                        {"Set-Cookie": cookie_val},
                    )
                else:
                    await _send_http(writer, 303, b"", "text/plain", {"Location": "/dashboard", "Set-Cookie": cookie_val})
                return

            if path == "/logout":
                if tok:
                    SESSIONS.pop(tok, None)
                await _send_http(writer, 303, b"", "text/plain", {"Location": "/login", "Set-Cookie": f"{SESSION_COOKIE}=; Max-Age=0; Path=/"})
                return

            if path == "/dashboard":
                if not sess_ok:
                    await _send_http(writer, 303, b"", "text/plain", {"Location": "/login"})
                    return
                await _send_http(writer, 200, DASHBOARD_HTML.encode("utf-8"), extra_headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"})
                return

            if path.startswith("/sub-json/"):
                uid = path.split("/sub-json/", 1)[1].strip("/")
                query["json"] = "1"
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path.startswith("/sub/"):
                uid = path.split("/sub/", 1)[1].strip("/")
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path.startswith("/s/"):
                uid = path.split("/s/", 1)[1].strip("/")
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path == "/api/v1/client/subscribe":
                uid = str(query.get("token") or query.get("uuid") or "").strip()
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path.startswith(("/info/", "/subscription/", "/p/")):
                uid = path.strip("/").split("/", 1)[1].strip("/")
                ua = headers.get("user-agent", "").lower()
                accept = headers.get("accept", "").lower()
                if any(x in ua for x in ("happ", "v2ray", "npv", "hiddify", "streisand", "sing-box", "clash", "shadowrocket", "nekoray", "nekobox", "v2box")) or headers.get("x-hwid") or "text/html" not in accept:
                    await _serve_sub_feed(writer, uid, query, headers)
                else:
                    await _serve_info_page(writer, uid)
                return

            if path.startswith("/api/"):
                if not sess_ok:
                    await _send_json(writer, 401, {"detail": "unauthorized"})
                    return

                if path == "/api/init" and method == "GET":
                    items = [get_link_info(l, u) for u, l in LINKS.items()]
                    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
                    await _send_json(writer, 200, {
                        "ok": True,
                        "links": items,
                        "connections": len(connections),
                        "total_bytes": sum(x["used_bytes"] for x in items),
                        "rss_mb": _read_rss_mb(),
                        "settings": {
                            "host": get_host(),
                            "ipv4_host": get_ipv4_host(),
                            "domain_host": get_domain_host(),
                            "port": _effective_public_port(),
                            "public_domain": CONFIG.get("public_domain", ""),
                            "admin_username": AUTH.get("username", "admin"),
                        },
                    })
                    return

                if path == "/api/links" and method == "GET":
                    items = [get_link_info(l, u) for u, l in LINKS.items()]
                    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
                    await _send_json(writer, 200, {"links": items})
                    return

                if path == "/api/links" and method == "POST":
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    label = str(b.get("label") or "").strip()[:50] or f"botvpn-{secrets.randbelow(900)+100}"
                    gb = safe_float(b.get("limit_value", 0))
                    limit_bytes = int(gb * (1024 ** 3)) if gb > 0 else 0
                    days = safe_int(b.get("expires_days", 0), minimum=0)
                    expires_at = (datetime.now() + timedelta(days=days)).isoformat() if days > 0 else None
                    ip_limit = safe_int(b.get("ip_limit", 0), minimum=0)
                    spd = safe_float(b.get("speed_limit_value", 0))
                    speed_bytes = int(spd * 1024 * 1024 / 8) if spd > 0 else 0

                    uid, rec = await make_link(
                        label=label,
                        limit_bytes=limit_bytes,
                        expires_at=expires_at,
                        protocol=DEFAULT_PROTOCOL,
                        port=_effective_public_port(),
                        ip_limit=ip_limit,
                        speed_limit_bytes=speed_bytes,
                    )
                    await _send_json(writer, 200, {"ok": True, **get_link_info(rec, uid)})
                    return

                if path.startswith("/api/links/"):
                    rest = path.split("/api/links/", 1)[1].strip("/")
                    parts = rest.split("/")
                    uid = parts[0]
                    if uid not in LINKS:
                        await _send_json(writer, 404, {"detail": "not found"})
                        return

                    if len(parts) == 2 and parts[1] == "cloud-sub" and method in ("POST", "GET"):
                        if str(query.get("force") or "") in ("1", "true"):
                            LINKS[uid].pop("trusted_https_sub", None)
                            LINKS[uid].pop("trusted_sub_host", None)
                        url = await _publish_trusted_https_sub(uid)
                        info = get_link_info(LINKS[uid], uid)
                        await _send_json(writer, 200, {"ok": True, "url": url or info["sub_https"], "trusted": bool(url)})
                        return

                    if len(parts) == 2 and parts[1] == "action" and method == "POST":
                        b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                        act = str(b.get("action") or "").lower()
                        if act == "reset":
                            LINKS[uid]["used_bytes"] = 0
                        elif act == "enable":
                            LINKS[uid]["active"] = True
                        elif act == "disable":
                            LINKS[uid]["active"] = False
                        await save_state()
                        await _send_json(writer, 200, {"ok": True})
                        return

                    if len(parts) == 1 and method == "PATCH":
                        b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                        l = LINKS[uid]
                        if "label" in b and str(b["label"]).strip():
                            l["label"] = str(b["label"]).strip()[:50]
                        l["protocol"] = DEFAULT_PROTOCOL
                        if "limit_value" in b:
                            gb = safe_float(b.get("limit_value", 0))
                            l["limit_bytes"] = int(gb * (1024 ** 3)) if gb > 0 else 0
                        if "expires_days" in b:
                            days = safe_int(b.get("expires_days", 0), minimum=0)
                            l["expires_at"] = (datetime.now() + timedelta(days=days)).isoformat() if days > 0 else None
                        if "ip_limit" in b:
                            l["ip_limit"] = safe_int(b.get("ip_limit", 0), minimum=0)
                        if "speed_limit_value" in b:
                            spd = safe_float(b.get("speed_limit_value", 0))
                            l["speed_limit_bytes"] = int(spd * 1024 * 1024 / 8) if spd > 0 else 0
                        l.pop("trusted_https_sub", None)
                        l.pop("trusted_sub_host", None)
                        await save_state()
                        asyncio.create_task(_publish_trusted_https_sub(uid))
                        await _send_json(writer, 200, {"ok": True, **get_link_info(l, uid)})
                        return

                    if len(parts) == 1 and method == "DELETE":
                        await remove_link(uid)
                        await _send_json(writer, 200, {"ok": True})
                        return

                if path == "/api/connections" and method == "GET":
                    grouped = {}
                    for c in connections.values():
                        cip = c.get("ip", "unknown")
                        l = LINKS.get(c.get("uuid"))
                        label = l.get("label", "unknown") if l else "unknown"
                        g = grouped.setdefault(cip, {"ip": cip, "sessions": 0, "bytes": 0, "labels": set(), "transports": set()})
                        g["sessions"] += 1
                        g["bytes"] += int(c.get("bytes", 0) or 0)
                        g["labels"].add(label)
                        g["transports"].add(c.get("transport", "tcp"))
                    out = [{"ip": g["ip"], "sessions": g["sessions"], "label": ", ".join(sorted(g["labels"])), "transports": sorted(g["transports"]), "bytes": g["bytes"]} for g in grouped.values()]
                    await _send_json(writer, 200, {"connections": out})
                    return

                if path == "/api/settings" and method == "GET":
                    await _send_json(writer, 200, {
                        "ok": True,
                        "tcp_public_host": get_host(),
                        "tcp_public_port": str(_effective_public_port()),
                        "public_domain": CONFIG.get("public_domain", ""),
                        "effective_host": get_host(),
                        "effective_port": _effective_public_port(),
                        "admin_username": AUTH.get("username", "admin"),
                    })
                    return

                if path == "/api/settings" and method == "POST":
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    raw_nh = str(b.get("tcp_public_host") or b.get("public_domain") or "").strip()
                    extracted_port = ""
                    if raw_nh:
                        if "://" in raw_nh:
                            raw_nh = raw_nh.split("://", 1)[1].split("/", 1)[0].strip()
                        else:
                            raw_nh = raw_nh.split("/", 1)[0].strip()
                        if ":" in raw_nh and not raw_nh.startswith("["):
                            raw_nh, maybe_p = raw_nh.rsplit(":", 1)
                            if maybe_p.strip().isdigit():
                                extracted_port = maybe_p.strip()
                        nh = _clean_sslip(raw_nh)
                        if nh and not _is_invalid_host(nh):
                            CONFIG["tcp_public_host"] = nh
                            CONFIG["host"] = nh
                            CONFIG["public_domain"] = nh
                            CONFIG["detected_ipv4"] = ""
                            CONFIG["manual_host_override"] = True
                    raw_np = str(b.get("tcp_public_port") or extracted_port or "").strip()
                    if raw_np.isdigit():
                        CONFIG["tcp_public_port"] = raw_np
                        CONFIG["manual_port_override"] = True
                        try:
                            import tcp_relay
                            await tcp_relay.ensure_listening_port(int(raw_np))
                        except Exception:
                            pass
                    eff_p = _effective_public_port()
                    for _l in LINKS.values():
                        _l["port"] = eff_p
                        _l.pop("trusted_https_sub", None)
                        _l.pop("trusted_sub_host", None)
                    await save_state()
                    asyncio.create_task(_prewarm_cloud_subs())
                    await _send_json(writer, 200, {
                        "ok": True,
                        "host": get_host(),
                        "port": eff_p,
                    })
                    return

                if path == "/api/change-password" and method == "POST":
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    cur = str(b.get("current_password") or "")
                    new = str(b.get("new_password") or "")
                    ok_pw, _, _, _ = verify_admin_credentials(AUTH.get("username", "admin"), cur)
                    if not ok_pw:
                        await _send_json(writer, 400, {"detail": "Current password is wrong"})
                        return
                    if len(new) < 4:
                        await _send_json(writer, 400, {"detail": "Password too short"})
                        return
                    AUTH["password_hash"] = hash_password(new)
                    await save_state()
                    await _send_json(writer, 200, {"ok": True})
                    return

            await _send_json(writer, 404, {"detail": "Not Found"})
            return
    except Exception:
        pass


async def _read_http_resp(reader: asyncio.StreamReader, timeout: float = 3.5) -> bytes:
    buf = b""
    try:
        while len(buf) < 65536:
            chunk = await asyncio.wait_for(reader.read(8192), timeout=timeout)
            if not chunk:
                break
            buf += chunk
            if b"\r\n\r\n" in buf:
                hdr_part, _, body_part = buf.partition(b"\r\n\r\n")
                cl = None
                for ln in hdr_part.decode("latin-1", errors="ignore").split("\r\n")[1:]:
                    if ln.lower().startswith("content-length:"):
                        try:
                            cl = int(ln.split(":", 1)[1].strip())
                        except Exception:
                            pass
                if cl is not None and len(body_part) >= cl:
                    break
                if body_part.strip().endswith(b"}") or body_part.strip().startswith(b"https://"):
                    break
    except Exception:
        pass
    return buf


async def _publish_trusted_https_sub(uid: str) -> str | None:
    """
    Publish the single unified VLESS TCP-REALITY subscription payload in Base64 to a public
    CA-signed HTTPS raw paste service (port 443, Cloudflare / Let's Encrypt certificate)
    so v2rayN, NPV Tunnel, and Happ import an `https://` subscription URL with zero SSL errors.
    """
    import ssl as _ssl
    from urllib.parse import urlencode
    link = LINKS.get(uid)
    if not link:
        return None
    sig = _sub_cache_signature(link)
    existing = str(link.get("trusted_https_sub") or "").strip()
    if existing and link.get("trusted_sub_host") == sig:
        return existing

    vless_uri = vless_link_for_link(link, uid)
    raw_text = vless_uri + "\n"
    b64_bytes = base64.b64encode(raw_text.encode("utf-8"))

    ctx = _ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = _ssl.CERT_NONE

    # 1. Try api.pastes.dev and bytebin.lucko.me (JSON {"key": "..."} -> https://<host>/<key>)
    for host, path, raw_prefix in (
        ("api.pastes.dev", "/post", "https://api.pastes.dev/"),
        ("bytebin.lucko.me", "/post", "https://bytebin.lucko.me/"),
    ):
        writer = None
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, 443, ssl=ctx, server_hostname=host),
                timeout=3.5,
            )
            req = (
                f"POST {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"User-Agent: botvpn/26.0\r\n"
                f"Content-Type: text/plain; charset=utf-8\r\n"
                f"Content-Length: {len(b64_bytes)}\r\n"
                f"Connection: close\r\n\r\n"
            ).encode("ascii") + b64_bytes
            writer.write(req)
            await writer.drain()
            resp = await _read_http_resp(reader, timeout=3.5)
            body = resp.decode("utf-8", errors="ignore").split("\r\n\r\n", 1)[-1].strip()
            if "{" in body and "}" in body:
                body_json = "{" + body.split("{", 1)[1].rsplit("}", 1)[0] + "}"
                j = json.loads(body_json)
                key = str(j.get("key") or "").strip()
                if key:
                    url = f"{raw_prefix}{key}"
                    link["trusted_https_sub"] = url
                    link["trusted_sub_host"] = sig
                    asyncio.create_task(save_state())
                    return url
        except Exception:
            pass
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass

    # 2. Try paste.rs (returns plain https://paste.rs/<id>)
    writer = None
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection("paste.rs", 443, ssl=ctx, server_hostname="paste.rs"),
            timeout=3.5,
        )
        req = (
            f"POST / HTTP/1.1\r\n"
            f"Host: paste.rs\r\n"
            f"User-Agent: curl/8.0\r\n"
            f"Content-Type: text/plain; charset=utf-8\r\n"
            f"Content-Length: {len(b64_bytes)}\r\n"
            f"Connection: close\r\n\r\n"
        ).encode("ascii") + b64_bytes
        writer.write(req)
        await writer.drain()
        resp = await _read_http_resp(reader, timeout=3.5)
        body = resp.decode("utf-8", errors="ignore").split("\r\n\r\n", 1)[-1].strip()
        for line in body.splitlines():
            sline = line.strip()
            if sline.startswith("https://paste.rs/"):
                link["trusted_https_sub"] = sline
                link["trusted_sub_host"] = sig
                asyncio.create_task(save_state())
                return sline
    except Exception:
        pass
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception:
                pass

    # 3. Try dpaste.com (/api/v2/ -> Location: https://dpaste.com/<id> -> https://dpaste.com/<id>.txt)
    writer = None
    try:
        form_bytes = urlencode({"content": b64_bytes.decode("ascii"), "expiry_days": 365}).encode("ascii")
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection("dpaste.com", 443, ssl=ctx, server_hostname="dpaste.com"),
            timeout=3.5,
        )
        req = (
            f"POST /api/v2/ HTTP/1.1\r\n"
            f"Host: dpaste.com\r\n"
            f"User-Agent: curl/8.0\r\n"
            f"Content-Type: application/x-www-form-urlencoded\r\n"
            f"Content-Length: {len(form_bytes)}\r\n"
            f"Connection: close\r\n\r\n"
        ).encode("ascii") + form_bytes
        writer.write(req)
        await writer.drain()
        resp = await _read_http_resp(reader, timeout=3.5)
        text = resp.decode("utf-8", errors="ignore")
        for line in text.splitlines():
            if line.lower().startswith("location:"):
                loc = line.split(":", 1)[1].strip().rstrip("/")
                if loc.startswith("http"):
                    url = loc + ".txt"
                    link["trusted_https_sub"] = url
                    link["trusted_sub_host"] = sig
                    asyncio.create_task(save_state())
                    return url
    except Exception:
        pass
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception:
                pass

    return None


async def _serve_sub_feed(writer: asyncio.StreamWriter, uid: str, query: dict, req_headers: dict | None = None):
    link = LINKS.get(uid)
    if not is_link_allowed(link) and LINKS:
        link = next((v for v in LINKS.values() if is_link_allowed(v)), None)
    if not is_link_allowed(link):
        await _send_json(writer, 404, {"detail": "not found or inactive"})
        return

    used = int(link.get("used_bytes", 0) or 0)
    limit = int(link.get("limit_bytes", 0) or 0)
    title = str(link.get("label") or "BotVPN")
    hdrs = subscription_metadata_headers(used, limit, link.get("expires_at"), title)

    if str(query.get("json", query.get("format", ""))).lower() in ("1", "true", "json"):
        arr = build_happ_xray_json_profiles(link, uid)
        await _send_json(writer, 200, arr, hdrs)
        return

    raw_text = vless_link_for_link(link, uid) + "\n"
    if str(query.get("raw", "")).lower() in ("1", "plain", "true"):
        content = raw_text.encode("utf-8")
    else:
        content = base64.b64encode(raw_text.encode("utf-8"))

    await _send_http(writer, 200, content, "text/plain; charset=utf-8", hdrs)


async def _serve_info_page(writer: asyncio.StreamWriter, uid: str):
    link = LINKS.get(uid)
    if not link and LINKS:
        link = next(iter(LINKS.values()))
    if not link:
        await _send_http(writer, 404, b"Not found", "text/plain")
        return

    info = get_link_info(link, uid)
    sub_e = escape_html(info["sub"])
    vless_e = escape_html(info["vless"])
    used_e = escape_html(fmt_bytes(info["used_bytes"]))
    lim_e = escape_html(fmt_bytes(info["limit_bytes"]) if info["limit_bytes"] else "Unlimited")

    html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escape_html(info['label'])}</title>
<script src="/assets/qr.js"></script>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#000;color:#fff;font-family:system-ui,-apple-system,sans-serif;font-size:13.5px;padding:16px}}
.wrap{{max-width:560px;margin:0 auto}}
.card{{background:#0a0a0a;border:1px solid #222;border-radius:6px;padding:16px;margin-bottom:12px}}
.btn{{padding:6px 12px;background:#111;border:1px solid #333;border-radius:4px;color:#fff;cursor:pointer;font-size:12px}}
.btn:hover{{background:#fff;color:#000}}
.code{{background:#000;border:1px solid #222;border-radius:4px;padding:8px;font:11px monospace;word-break:break-all;margin-top:4px;color:#bbb}}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <b>{escape_html(info['label'])}</b>
      <span style="font-size:12px;color:#aaa">{used_e} / {lim_e}</span>
    </div>
    <div style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:#888">VLESS TCP-REALITY (Fast SNI + DNS + TUN)</span>
        <button class="btn" onclick="cp('{vless_e}')">Copy Config</button>
      </div>
      <div class="code">{vless_e}</div>
    </div>
    <div style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:#888">Subscription URL (HTTPS)</span>
        <button class="btn" onclick="cp('{sub_e}')">Copy Sub</button>
      </div>
      <div class="code">{sub_e}</div>
    </div>
  </div>
</div>
<script>
function cp(t){{
  if(navigator.clipboard)navigator.clipboard.writeText(t);
  else{{var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove()}}
}}
</script>
</body>
</html>"""
    await _send_http(writer, 200, html.encode("utf-8"))


async def _state_autosave_loop():
    while True:
        await asyncio.sleep(180)
        await save_state()


async def _autodetect_public_ip():
    """
    Only check outbound IP as a fallback if no domain/host is configured
    and before the user opens the dashboard in their browser.
    """
    if CONFIG.get("public_domain") or CONFIG.get("manual_host_override"):
        return
    cur = str(CONFIG.get("tcp_public_host") or "").strip()
    if cur and cur not in ("", "auto") and not _is_invalid_host(cur):
        return
    for host, path in (("api.ipify.org", "/"), ("icanhazip.com", "/")):
        writer = None
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, 80), timeout=1.5)
            req = f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: curl/8.0\r\nConnection: close\r\n\r\n"
            writer.write(req.encode("ascii"))
            await writer.drain()
            raw = await asyncio.wait_for(reader.read(1024), timeout=1.5)
            body = raw.decode("latin-1", errors="ignore").split("\r\n\r\n", 1)[-1].strip()
            ip_obj = ipaddress.ip_address(body)
            if ip_obj.is_global and ip_obj.version == 4:
                detected = str(ip_obj)
                if detected in _KNOWN_IP_DOMAINS:
                    dom = _KNOWN_IP_DOMAINS[detected]
                    CONFIG["public_domain"] = dom
                    CONFIG["tcp_public_host"] = dom
                    CONFIG["host"] = dom
                else:
                    CONFIG["detected_ipv4"] = detected
                return
        except Exception:
            pass
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass


async def _prewarm_cloud_subs():
    await asyncio.sleep(0.3)
    for uid in list(LINKS.keys()):
        try:
            await _publish_trusted_https_sub(uid)
        except Exception:
            pass


_server_initialized = False


async def _init_botvpn_services(bind_mux: bool = True):
    global _server_initialized
    if _server_initialized:
        return
    _server_initialized = True
    import tcp_relay

    await load_state()
    await ensure_default_link()
    await _autodetect_public_ip()
    asyncio.create_task(_state_autosave_loop())
    asyncio.create_task(_prewarm_cloud_subs())

    if bind_mux:
        await tcp_relay.start_tcp_relay(
            public_port=PORT,
            enable_multiplexer=True,
            data_dir=DATA_DIR,
        )
        eff_p = _effective_public_port()
        if eff_p != PORT:
            await tcp_relay.ensure_listening_port(eff_p)


async def run_server():
    await _init_botvpn_services(bind_mux=True)
    p = _effective_public_port()
    h = get_host()
    print(f"[{APP_NAME} v{APP_VERSION}] Running on 0.0.0.0:{PORT} (and {p}) -> Panel: http://{h}:{p}/login (Default login: admin / admin)", flush=True)
    await asyncio.Event().wait()


async def app(scope=None, receive=None, send=None):
    """
    Universal entrypoint:
    - If called with 0 arguments (`await app()`), runs `run_server()`.
    - If called by Uvicorn/ASGI (`await app(scope, receive, send)`), initializes services cleanly.
    """
    if scope is None:
        return await run_server()
    await _init_botvpn_services(bind_mux=False)
    if scope.get("type") == "lifespan":
        while True:
            msg = await receive()
            if msg["type"] == "lifespan.startup":
                await send({"type": "lifespan.startup.complete"})
            elif msg["type"] == "lifespan.shutdown":
                await send({"type": "lifespan.shutdown.complete"})
                return


if __name__ == "__main__":
    asyncio.run(run_server())