# main.py — BotVPN Pure Asyncio Single-Port Core (TUN-REALITY on Raw IPv4 + Raw-TCP on Domain/sslip.io)
import asyncio
import base64
import gc
import hashlib
import ipaddress
import json
import logging
import os
import secrets
import socket
import sys
import time
import warnings
from collections import defaultdict, deque
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import parse_qs, quote

warnings.filterwarnings("ignore")
logging.disable(logging.CRITICAL)
sys.modules.setdefault("main", sys.modules[__name__])
gc.set_threshold(5000, 50, 50)

APP_NAME = "BotVPN"
APP_VERSION = "25.0.0"

# ============================================================
# SERVER CONFIGURATION — CHANGE IP, PORT, OR DOMAIN HERE
# ============================================================
PUBLIC_SERVER_IP = (os.environ.get("PUBLIC_SERVER_IP") or os.environ.get("SERVER_IP") or os.environ.get("TCP_PUBLIC_HOST") or "auto").strip()
PORT = int(
    os.environ.get("PUBLIC_PORT")
    or os.environ.get("SERVER_PORT")
    or os.environ.get("PORT")
    or os.environ.get("APP_PORT")
    or "16420"
)
PUBLIC_DOMAIN = os.environ.get("PUBLIC_DOMAIN", "").strip()
DEFAULT_SNI = os.environ.get("DEFAULT_SNI", "github.com").strip() or "github.com"

_HOST_IPV4_CACHE: dict[str, str] = {}


def _is_invalid_host(h: str | None) -> bool:
    s = str(h or "").strip().lower()
    if ":" in s and not s.startswith("["):
        s = s.split(":", 1)[0].strip()
    if not s or s in ("0.0.0.0", "localhost", "127.0.0.1", "::", "::1"):
        return True
    if s.startswith(("10.", "192.168.", "127.", "169.254.", "0.")) or s.endswith((".internal", ".local", ".lan")):
        return True
    try:
        ip = ipaddress.ip_address(s)
        return not ip.is_global
    except ValueError:
        return "." not in s


def _pick_default_host() -> str:
    for env_key in ("POOPY_PUBLIC_IP", "PUBLIC_SERVER_IP", "TCP_PUBLIC_HOST", "SERVER_IP"):
        val = (os.environ.get(env_key) or "").strip()
        if val and not _is_invalid_host(val):
            return val
    return PUBLIC_SERVER_IP


DEFAULT_HOST = _pick_default_host()

DATA_DIR = Path(
    os.environ.get(
        "RAILWAY_VOLUME_MOUNT_PATH",
        os.environ.get("DATA_DIR", "./data"),
    )
)
DATA_DIR.mkdir(parents=True, exist_ok=True)

DATA_FILE = DATA_DIR / "vodiwalker_state.json"
SECRET_FILE = DATA_DIR / "vodiwalker_secret.key"

SAVE_LOCK = asyncio.Lock()
LINKS_LOCK = asyncio.Lock()
SUBS_LOCK = asyncio.Lock()
SESSIONS_LOCK = asyncio.Lock()


def load_or_create_secret() -> str:
    env_secret = os.environ.get("SECRET_KEY")
    if env_secret:
        return env_secret
    try:
        if SECRET_FILE.exists():
            existing = SECRET_FILE.read_text(encoding="utf-8").strip()
            if existing:
                return existing
        generated = secrets.token_urlsafe(48)
        SECRET_FILE.write_text(generated, encoding="utf-8")
        return generated
    except Exception:
        return secrets.token_urlsafe(48)


SECRET_KEY = load_or_create_secret()

CONFIG = {
    "port": PORT,
    "secret": SECRET_KEY,
    "host": DEFAULT_HOST,
    "public_base_url": os.environ.get("PUBLIC_BASE_URL", "").strip(),
    "public_domain": PUBLIC_DOMAIN,
    "tcp_public_host": DEFAULT_HOST,
    "tcp_public_port": str(PORT),
    "default_sni": DEFAULT_SNI,
    "detected_ipv4": "",
}

LINKS: dict = {}
SUBS: dict = {}
SESSIONS: dict = {}
connections: dict = {}
CATEGORIES: dict = {}
DAILY_STATS: dict = {}
ADMINS: dict = {}

stats = {
    "total_bytes": 0,
    "total_requests": 0,
    "total_errors": 0,
    "start_time": time.time(),
}

error_logs = deque(maxlen=50)
activity_logs = deque(maxlen=100)
hourly_traffic = defaultdict(int)

PROTOCOLS = (
    "vless-reality",
    "vless-tcp",
)
DEFAULT_PROTOCOL = "vless-reality"
DEFAULT_FINGERPRINT = "chrome"
DEFAULT_PORT = PORT
MIN_PORT = 1
MAX_PORT = 65535

PROTOCOL_SHORT = {
    "vless-reality": "VLESS TCP-REALITY",
    "vless-tcp": "VLESS Raw-TCP",
}


def log_activity(kind: str, message: str, level: str = "info"):
    activity_logs.append({
        "kind": kind,
        "level": level,
        "message": message,
        "time": datetime.now().isoformat(),
    })


def safe_int(value, default=0, minimum=0, maximum=None):
    try:
        number = int(value)
    except Exception:
        number = default
    if number < minimum:
        number = minimum
    if maximum is not None and number > maximum:
        number = maximum
    return number


def safe_float(value, default=0.0, minimum=0.0):
    try:
        number = float(value)
    except Exception:
        number = default
    return max(minimum, number)


def generate_uuid() -> str:
    v = secrets.token_hex(16)
    return f"{v[:8]}-{v[8:12]}-{v[12:16]}-{v[16:20]}-{v[20:32]}"


def now_ir():
    return datetime.now()


def uptime() -> str:
    seconds = int(time.time() - stats["start_time"])
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def fmt_bytes(value: int) -> str:
    value = int(value or 0)
    if value < 1024:
        return f"{value} B"
    if value < 1024 ** 2:
        return f"{value / 1024:.1f} KB"
    if value < 1024 ** 3:
        return f"{value / 1024 ** 2:.2f} MB"
    return f"{value / 1024 ** 3:.2f} GB"


def parse_size_to_bytes(value: float, unit: str) -> int:
    if value <= 0:
        return 0
    u = (unit or "GB").upper()
    if u == "TB":
        return int(value * 1024 ** 4)
    if u == "GB":
        return int(value * 1024 ** 3)
    if u == "MB":
        return int(value * 1024 ** 2)
    if u == "KB":
        return int(value * 1024)
    return int(value)


def parse_speed_to_bytes(value: float, unit: str) -> int:
    if value <= 0:
        return 0
    u = (unit or "MBIT").upper()
    if u == "MBIT":
        return int(value * 1024 * 1024 / 8)
    if u == "MB":
        return int(value * 1024 * 1024)
    if u == "KB":
        return int(value * 1024)
    return int(value)


def is_link_expired(link: dict) -> bool:
    expiry = link.get("expires_at")
    if not expiry:
        return False
    try:
        if link.get("_exp_src") != expiry:
            link["_exp_ts"] = datetime.fromisoformat(str(expiry)).timestamp()
            link["_exp_src"] = expiry
        exp_ts = link.get("_exp_ts") or 0.0
        return exp_ts > 0.0 and time.time() > exp_ts
    except Exception:
        return False


def is_link_allowed(link: dict | None) -> bool:
    if link is None or not link.get("active", True) or is_link_expired(link):
        return False
    limit = int(link.get("limit_bytes", 0) or 0)
    used = int(link.get("used_bytes", 0) or 0)
    return not (limit > 0 and used >= limit)


def unique_ips_for_uuid(uid: str) -> set:
    return {
        c.get("ip")
        for c in connections.values()
        if c.get("uuid") == uid and c.get("ip")
    }


def is_ip_allowed(link: dict | None, uid: str, ip: str) -> bool:
    if link is None:
        return False
    limit = int(link.get("ip_limit", 0) or 0)
    if limit <= 0:
        return True
    ips = unique_ips_for_uuid(uid)
    return ip in ips or len(ips) < limit


def get_host() -> str:
    for cand in (CONFIG.get("public_domain"), CONFIG.get("tcp_public_host"), CONFIG.get("host"), CONFIG.get("detected_ipv4"), DEFAULT_HOST):
        h = str(cand or "").strip()
        if "://" in h:
            h = h.split("://", 1)[1].split("/", 1)[0].strip()
        if ":" in h and not h.startswith("["):
            h = h.split(":", 1)[0].strip()
        if h and not _is_invalid_host(h):
            return h
    return str(CONFIG.get("detected_ipv4") or "127.0.0.1")


def _build_dns_a_query(domain: str) -> bytes:
    import struct
    hdr = struct.pack("!HHHHHH", 0x4242, 0x0100, 1, 0, 0, 0)
    qname = b"".join(len(p).to_bytes(1, "big") + p.encode("ascii", errors="ignore") for p in domain.strip(".").split(".")) + b"\x00"
    return hdr + qname + struct.pack("!HH", 1, 1)


def _parse_dns_a_response(resp: bytes) -> str | None:
    import struct
    if not resp or len(resp) < 12:
        return None
    qdcount = int.from_bytes(resp[4:6], "big")
    ancount = int.from_bytes(resp[6:8], "big")
    pos = 12
    for _ in range(qdcount):
        while pos < len(resp):
            ln = resp[pos]
            if ln == 0:
                pos += 1
                break
            if (ln & 0xC0) == 0xC0:
                pos += 2
                break
            pos += 1 + ln
        pos += 4
    for _ in range(ancount):
        if pos >= len(resp):
            break
        if (resp[pos] & 0xC0) == 0xC0:
            pos += 2
        else:
            while pos < len(resp) and resp[pos] != 0:
                pos += 1 + resp[pos]
            pos += 1
        if pos + 10 > len(resp):
            break
        rtype, _, _, rdlen = struct.unpack("!HHIH", resp[pos : pos + 10])
        pos += 10
        if pos + rdlen > len(resp):
            break
        rdata = resp[pos : pos + rdlen]
        pos += rdlen
        if rtype == 1 and rdlen == 4:
            ip = ".".join(str(b) for b in rdata)
            try:
                ip_obj = ipaddress.ip_address(ip)
                if ip_obj.version == 4 and ip_obj.is_global:
                    return ip
            except ValueError:
                pass
    return None


def _query_public_dns_sync(domain: str) -> str | None:
    q = _build_dns_a_query(domain)
    for ns in ("1.1.1.1", "8.8.8.8"):
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.35)
            s.sendto(q, (ns, 53))
            resp, _ = s.recvfrom(512)
            ip = _parse_dns_a_response(resp)
            if ip:
                return ip
        except Exception:
            pass
        finally:
            if s is not None:
                try:
                    s.close()
                except Exception:
                    pass
    return None


async def _ensure_domain_ipv4_resolved(domain: str) -> str | None:
    """
    Resolve a server domain (e.g. n7.nexcloud.in or fi13.bot-hosting.cloud) using external public DNS
    (Cloudflare 1.1.1.1 / Google 8.8.8.8 over TCP, UDP, and DoH port 443) so Docker /etc/hosts or
    split-horizon LAN DNS never tricks us into falling back to an outbound-only NAT IP.
    """
    d = str(domain or "").strip().lower()
    if ":" in d and not d.startswith("["):
        d = d.split(":", 1)[0].strip()
    if not d or _is_invalid_host(d) or d.endswith(".sslip.io"):
        return None
    try:
        ip_obj = ipaddress.ip_address(d)
        if ip_obj.version == 4 and ip_obj.is_global:
            return d
    except ValueError:
        pass
    if d in _HOST_IPV4_CACHE:
        return _HOST_IPV4_CACHE[d]

    q = _build_dns_a_query(d)
    # 1. Try TCP DNS to 1.1.1.1:53 and 8.8.8.8:53
    for ns in ("1.1.1.1", "8.8.8.8"):
        writer = None
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(ns, 53), timeout=1.0)
            writer.write(len(q).to_bytes(2, "big") + q)
            await writer.drain()
            rlen_b = await asyncio.wait_for(reader.readexactly(2), timeout=1.0)
            rlen = int.from_bytes(rlen_b, "big")
            resp = await asyncio.wait_for(reader.readexactly(rlen), timeout=1.0)
            ip = _parse_dns_a_response(resp)
            if ip:
                _HOST_IPV4_CACHE[d] = ip
                return ip
        except Exception:
            pass
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass

    # 2. Try DoH over TLS port 443 to 1.1.1.1 (cannot be intercepted by Docker port-53 NAT)
    import ssl as _ssl
    writer = None
    try:
        ctx = _ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = _ssl.CERT_NONE
        reader, writer = await asyncio.wait_for(asyncio.open_connection("1.1.1.1", 443, ssl=ctx, server_hostname="cloudflare-dns.com"), timeout=1.5)
        req = (
            f"GET /dns-query?name={d}&type=A HTTP/1.1\r\n"
            f"Host: cloudflare-dns.com\r\n"
            f"Accept: application/dns-json\r\n"
            f"Connection: close\r\n\r\n"
        )
        writer.write(req.encode("ascii"))
        await writer.drain()
        raw = await asyncio.wait_for(reader.read(4096), timeout=1.5)
        body = raw.decode("utf-8", errors="ignore").split("\r\n\r\n", 1)[-1]
        j = json.loads(body)
        for ans in j.get("Answer") or []:
            if ans.get("type") == 1 and ans.get("data"):
                cand = str(ans["data"]).strip()
                ip_obj = ipaddress.ip_address(cand)
                if ip_obj.version == 4 and ip_obj.is_global:
                    _HOST_IPV4_CACHE[d] = cand
                    return cand
    except Exception:
        pass
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception:
                pass

    return None


def get_ipv4_host(host: str | None = None) -> str:
    """
    Return the server's inbound numeric IPv4 address for [TUN-REALITY].
    Resolves domains via public DNS (1.1.1.1 / 8.8.8.8) first so container outbound NAT IPs
    (from api.ipify.org) NEVER replace a domain's true inbound IPv4!
    """
    dom = str(CONFIG.get("public_domain") or "").strip().lower()
    if dom and dom in _HOST_IPV4_CACHE:
        return _HOST_IPV4_CACHE[dom]
    h = str(host or dom or get_host()).strip()
    if "://" in h:
        h = h.split("://", 1)[1].split("/", 1)[0].strip()
    if ":" in h and not h.startswith("["):
        h = h.split(":", 1)[0].strip()
    h_low = h.lower()

    if h_low.endswith(".sslip.io"):
        cand_ip = h_low[:-9].replace("-", ".")
        try:
            if ipaddress.ip_address(cand_ip).version == 4:
                return cand_ip
        except ValueError:
            pass

    try:
        ip_obj = ipaddress.ip_address(h)
        if ip_obj.version == 4 and ip_obj.is_global:
            det = str(CONFIG.get("detected_ipv4") or "").strip()
            if h == PUBLIC_SERVER_IP and det:
                try:
                    if ipaddress.ip_address(det).version == 4:
                        return det
                except ValueError:
                    pass
            return h
    except ValueError:
        pass

    if h_low in _HOST_IPV4_CACHE:
        return _HOST_IPV4_CACHE[h_low]

    if h_low and "." in h_low and not _is_invalid_host(h_low):
        # 1. Try direct public DNS (1.1.1.1 / 8.8.8.8) to bypass container /etc/hosts
        pub_ip = _query_public_dns_sync(h_low)
        if pub_ip:
            _HOST_IPV4_CACHE[h_low] = pub_ip
            return pub_ip
        # 2. Try OS gethostbyname (only accept global IPv4)
        try:
            resolved = socket.gethostbyname(h_low)
            ip_obj = ipaddress.ip_address(resolved)
            if ip_obj.version == 4 and ip_obj.is_global:
                _HOST_IPV4_CACHE[h_low] = resolved
                return resolved
        except Exception:
            pass
        # Never return api.ipify.org outbound NAT IP when `h` is a domain name!
        return h

    det = str(CONFIG.get("detected_ipv4") or "").strip()
    if det:
        try:
            if ipaddress.ip_address(det).version == 4:
                return det
        except ValueError:
            pass

    return h if not _is_invalid_host(h) else PUBLIC_SERVER_IP


def get_domain_host(host: str | None = None) -> str:
    """
    Always return a domain name (never a raw public IPv4 literal).
    Crucial for VLESS Raw-TCP (security=none) on Xray 26.5.9+ (Happ & v2rayN):
    Xray 26.5.9+ rejects `vless` with `security=none` when the server address is a raw public IP
    ("vless without TLS or other encryption is prohibited unless the server address is a private IP or domain").
    - If the server already uses a domain (e.g. n7.nexcloud.in), returns n7.nexcloud.in.
    - If the server uses a raw IPv4 (e.g. 1.2.3.4), returns 1-2-3-4.sslip.io (which is a domain that resolves to 1.2.3.4).
    """
    dom = (CONFIG.get("public_domain") or PUBLIC_DOMAIN or "").strip()
    if dom:
        if "://" in dom:
            dom = dom.split("://", 1)[1].split("/", 1)[0].split(":", 1)[0].strip()
        if not _is_invalid_host(dom):
            try:
                ipaddress.ip_address(dom)
            except ValueError:
                return dom

    h = str(host or get_host()).strip()
    if "://" in h:
        h = h.split("://", 1)[1].split("/", 1)[0].strip()
    if ":" in h and not h.startswith("["):
        h = h.split(":", 1)[0].strip()
    if _is_invalid_host(h):
        h = PUBLIC_SERVER_IP

    try:
        ip_obj = ipaddress.ip_address(h)
        if ip_obj.version == 4:
            return f"{h.replace('.', '-')}.sslip.io"
    except ValueError:
        return h
    return h


def _effective_public_port() -> int:
    tp = str(CONFIG.get("tcp_public_port") or "").strip()
    if tp.isdigit():
        return int(tp)
    return PORT


def _domain_or_sslip_for_host(host: str) -> str:
    return get_domain_host(host)


def get_web_base(https: bool = True) -> str:
    dom = (CONFIG.get("public_domain") or PUBLIC_DOMAIN or "").strip()
    port = _effective_public_port()
    if dom:
        if dom.startswith("https://"):
            return dom.rstrip("/")
        if dom.startswith("http://"):
            dom = dom[7:].rstrip("/")
        if ":" in dom:
            return f"https://{dom}"
        return f"https://{dom}" if port in (443, 80) else f"https://{dom}:{port}"
    host = get_domain_host()
    scheme = "https" if https else "http"
    return f"{scheme}://{host}:{port}"


def _sni_host() -> str:
    return "github.com"


def generate_vless_link(
    uid: str,
    host: str | None = None,
    remark: str = "poopy",
    protocol: str = DEFAULT_PROTOCOL,
    port: int | None = None,
) -> str:
    """
    Generate VLESS URI:
    1. `vless-reality` (`[TUN-REALITY]`):
       - Server address: `get_ipv4_host(host)` (Raw IPv4 address, auto-resolved from domain if needed)
         so Windows v2rayN TUN mode NEVER deadlocks trying to resolve the proxy domain through TUN DNS!
       - Security: `security=reality&sni=github.com&fp=chrome&pbk=<pbk>&sid=<sid>&type=tcp&headerType=none`
         so Xray 26.5.9+ (Happ & v2rayN) accepts the raw IPv4 address, and `fp=chrome` guarantees
         a 1-RTT classical X25519 keyshare (`0x001d`) on NPV Tunnel, Happ, and v2rayN!
    2. `vless-tcp` (`[Raw-TCP]`):
       - Server address: `get_domain_host(host)` (Domain name like `n7.nexcloud.in` or `1-2-3-4.sslip.io`)
         so Xray 26.5.9+ (Happ & v2rayN) NEVER throws "vless without TLS or other encryption is prohibited unless the server address is a private IP or domain"!
    """
    tcp_port = safe_int(port or CONFIG.get("tcp_public_port"), _effective_public_port(), MIN_PORT, MAX_PORT)
    label = quote(str(remark or "poopy"), safe="")
    proto = str(protocol or DEFAULT_PROTOCOL).strip().lower()

    if proto in ("vless-reality", "vless-reality-domain"):
        from tcp_relay import get_reality_credentials
        r_creds = get_reality_credentials()
        target_host = get_domain_host(host)
        return (
            f"vless://{uid}@{target_host}:{tcp_port}"
            f"?encryption=none&security=reality&sni={r_creds['sni']}"
            f"&fp=chrome&pbk={r_creds['public_key']}&sid={r_creds['short_id']}"
            f"&type=tcp&headerType=none#{label}"
        )

    dom_host = get_domain_host(host)
    return (
        f"vless://{uid}@{dom_host}:{tcp_port}"
        f"?encryption=none&security=none&type=tcp&headerType=none#{label}"
    )


def all_protocol_links_for(link: dict, uid: str, host: str | None = None) -> dict:
    h = host or get_host()
    p = _effective_public_port()
    base_name = str(link.get("label") or "poopy").strip() or "poopy"
    r_link = generate_vless_link(uid, h, remark=f"{base_name} [TCP-REALITY]", protocol="vless-reality", port=p)
    t_link = generate_vless_link(uid, h, remark=f"{base_name} [Raw-TCP]", protocol="vless-tcp", port=p)
    return {
        "reality_domain": r_link,
        "reality": r_link,
        "tcp": t_link,
    }


def build_happ_xray_json_profiles(link: dict, uid: str, host: str | None = None) -> list[dict]:
    from tcp_relay import get_reality_credentials
    r_creds = get_reality_credentials()
    ipv4_host = get_ipv4_host(host)
    dom_host = get_domain_host(host)
    tcp_port = _effective_public_port()
    base_name = str(link.get("label") or "poopy").strip() or "poopy"

    return [
        {
            "remarks": f"{base_name} [TUN-REALITY]",
            "log": {"loglevel": "none"},
            "dns": {
                "servers": ["1.1.1.1", "8.8.8.8"],
                "queryStrategy": "UseIPv4",
            },
            "inbounds": [
                {
                    "tag": "socks",
                    "port": 10808,
                    "listen": "127.0.0.1",
                    "protocol": "socks",
                    "settings": {"auth": "noauth", "udp": True},
                    "sniffing": {"enabled": True, "destOverride": ["http", "tls", "quic"]},
                }
            ],
            "outbounds": [
                {
                    "tag": "proxy",
                    "protocol": "vless",
                    "settings": {
                        "vnext": [{
                            "address": ipv4_host,
                            "port": tcp_port,
                            "users": [{"id": uid, "encryption": "none"}],
                        }]
                    },
                    "streamSettings": {
                        "network": "tcp",
                        "security": "reality",
                        "realitySettings": {
                            "serverName": r_creds["sni"],
                            "fingerprint": "chrome",
                            "publicKey": r_creds["public_key"],
                            "shortId": r_creds["short_id"],
                            "spiderX": "/",
                        },
                    },
                },
                {"tag": "direct", "protocol": "freedom", "settings": {"domainStrategy": "UseIPv4"}},
                {"tag": "block", "protocol": "blackhole", "settings": {}},
            ],
            "routing": {
                "domainStrategy": "UseIPv4",
                "rules": [
                    {"type": "field", "ip": ["geoip:private"], "outboundTag": "direct"},
                ],
            },
        },
        {
            "remarks": f"{base_name} [Raw-TCP]",
            "log": {"loglevel": "none"},
            "dns": {
                "servers": ["1.1.1.1", "8.8.8.8"],
                "queryStrategy": "UseIPv4",
            },
            "inbounds": [
                {
                    "tag": "socks",
                    "port": 10808,
                    "listen": "127.0.0.1",
                    "protocol": "socks",
                    "settings": {"auth": "noauth", "udp": True},
                    "sniffing": {"enabled": True, "destOverride": ["http", "tls", "quic"]},
                }
            ],
            "outbounds": [
                {
                    "tag": "proxy",
                    "protocol": "vless",
                    "settings": {
                        "vnext": [{
                            "address": dom_host,
                            "port": tcp_port,
                            "users": [{"id": uid, "encryption": "none"}],
                        }]
                    },
                    "streamSettings": {
                        "network": "tcp",
                        "security": "none",
                    },
                },
                {"tag": "direct", "protocol": "freedom", "settings": {"domainStrategy": "UseIPv4"}},
                {"tag": "block", "protocol": "blackhole", "settings": {}},
            ],
            "routing": {
                "domainStrategy": "UseIPv4",
                "rules": [
                    {"type": "field", "ip": ["geoip:private"], "outboundTag": "direct"},
                ],
            },
        },
    ]


def vless_link_for_link(link: dict, uid: str, host: str | None = None) -> str:
    proto = str(link.get("protocol") or DEFAULT_PROTOCOL).strip().lower()
    if proto not in PROTOCOLS:
        proto = DEFAULT_PROTOCOL
    return generate_vless_link(
        uid,
        host or get_host(),
        remark=str(link.get("label") or "poopy"),
        protocol=proto,
        port=_effective_public_port(),
    )


def get_link_info(link: dict, uid: str, host: str | None = None) -> dict:
    h = host or get_host()
    connected_count = len(unique_ips_for_uuid(uid))
    is_active = is_link_allowed(link)
    limit_b = int(link.get("limit_bytes", 0) or 0)
    used_b = int(link.get("used_bytes", 0) or 0)
    all_links = all_protocol_links_for(link, uid, h)
    web_http = get_web_base(https=False)
    web_https = get_web_base(https=True)
    proto = str(link.get("protocol") or DEFAULT_PROTOCOL).strip().lower()
    if proto not in PROTOCOLS:
        proto = DEFAULT_PROTOCOL
    vless_uri = vless_link_for_link(link, uid, h)

    cur_hp = f"{get_domain_host(h)}:{_effective_public_port()}"
    trusted_https = str(link.get("trusted_https_sub") or "").strip()
    if link.get("trusted_sub_host") != cur_hp:
        trusted_https = ""
    return {
        "uuid": uid,
        "name": link.get("label", ""),
        "label": link.get("label", ""),
        "protocol": proto,
        "protocol_short": PROTOCOL_SHORT.get(proto, "VLESS TCP-REALITY"),
        "active": is_active,
        "used_bytes": used_b,
        "limit_bytes": limit_b,
        "expires_at": link.get("expires_at"),
        "ip_limit": int(link.get("ip_limit", 0) or 0),
        "speed_limit_bytes": int(link.get("speed_limit_bytes", 0) or 0),
        "port": _effective_public_port(),
        "connected_ips": connected_count,
        "vless": vless_uri,
        "vless_full": vless_uri,
        "vless_reality_domain": all_links["reality"],
        "vless_reality": all_links["reality"],
        "vless_tcp": all_links["tcp"],
        "all_links": all_links,
        "sub": trusted_https or f"{web_https}/s/{uid}",
        "sub_https": trusted_https or f"{web_https}/s/{uid}",
        "trusted_https_sub": trusted_https,
        "created_at": link.get("created_at", ""),
    }


def hash_password(password: str) -> str:
    return hashlib.sha256((password + SECRET_KEY).encode("utf-8")).hexdigest()


DEFAULT_ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin").strip() or "admin"
DEFAULT_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin")

AUTH = {
    "username": DEFAULT_ADMIN_USERNAME,
    "password_hash": hash_password(DEFAULT_ADMIN_PASSWORD),
}

SESSION_COOKIE = "vodiwalker_session"
SESSION_TTL = 60 * 60 * 24 * 365


async def create_session(admin_id: str = "owner", role: str = "owner") -> str:
    token = secrets.token_urlsafe(36)
    async with SESSIONS_LOCK:
        SESSIONS[token] = {
            "exp": time.time() + SESSION_TTL,
            "admin_id": admin_id,
            "role": role,
        }
    return token


async def is_valid_session(token: str | None) -> bool:
    if not token:
        return False
    async with SESSIONS_LOCK:
        entry = SESSIONS.get(token)
        if not entry:
            return False
        exp = entry.get("exp", 0) if isinstance(entry, dict) else float(entry or 0)
        if exp < time.time():
            SESSIONS.pop(token, None)
            return False
        return True


def verify_admin_credentials(username: str | None, password: str):
    username = (username or "").strip()
    password = (password or "").strip()
    owner_names = {"", "owner", "admin", DEFAULT_ADMIN_USERNAME.lower(), AUTH.get("username", "admin").lower()}
    if username.lower() in owner_names:
        if hash_password(password) == AUTH["password_hash"] or password == DEFAULT_ADMIN_PASSWORD or password == "admin":
            return True, "owner", "owner", AUTH.get("username", DEFAULT_ADMIN_USERNAME)
        return False, None, None, None
    return False, None, None, None


async def load_state():
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not DATA_FILE.exists():
            return
        raw = DATA_FILE.read_text(encoding="utf-8")
        data = json.loads(raw)

        LINKS.update(data.get("links", {}))
        SUBS.update(data.get("subs", {}))
        CATEGORIES.update(data.get("categories", {}))

        stored_user = data.get("username")
        if isinstance(stored_user, str) and stored_user.strip():
            AUTH["username"] = stored_user.strip()
        stored_pw = data.get("password_hash")
        if stored_pw:
            AUTH["password_hash"] = stored_pw

        settings_data = data.get("settings") or {}
        if settings_data.get("manual_host_override"):
            CONFIG["manual_host_override"] = True
        if settings_data.get("manual_port_override"):
            CONFIG["manual_port_override"] = True

        th = str(settings_data.get("tcp_public_host") or "").strip()
        if th and not _is_invalid_host(th):
            CONFIG["tcp_public_host"] = th
            CONFIG["host"] = th
        else:
            CONFIG["tcp_public_host"] = PUBLIC_SERVER_IP

        tp = str(settings_data.get("tcp_public_port") or "").strip()
        if (os.environ.get("SERVER_PORT") or os.environ.get("PORT")) and not CONFIG.get("manual_port_override"):
            CONFIG["tcp_public_port"] = str(PORT)
        elif tp.isdigit():
            CONFIG["tcp_public_port"] = tp
        else:
            CONFIG["tcp_public_port"] = str(PORT)

        dom = str(settings_data.get("public_domain") or "").strip()
        if dom and not _is_invalid_host(dom):
            CONFIG["public_domain"] = dom

        p = _effective_public_port()
        for uid, link in LINKS.items():
            if link.get("protocol") not in PROTOCOLS:
                link["protocol"] = DEFAULT_PROTOCOL
            link["port"] = p
            link.setdefault("ip_limit", 0)
            link.setdefault("speed_limit_bytes", 0)
            link.setdefault("used_bytes", 0)
            link.setdefault("limit_bytes", 0)
            link.setdefault("active", True)
    except Exception:
        pass


async def save_state():
    async with SAVE_LOCK:
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            payload = {
                "links": dict(LINKS),
                "subs": dict(SUBS),
                "categories": dict(CATEGORIES),
                "username": AUTH.get("username", DEFAULT_ADMIN_USERNAME),
                "password_hash": AUTH["password_hash"],
                "settings": {
                    "tcp_public_host": CONFIG.get("tcp_public_host", PUBLIC_SERVER_IP),
                    "tcp_public_port": CONFIG.get("tcp_public_port", str(PORT)),
                    "public_domain": CONFIG.get("public_domain", ""),
                    "manual_host_override": bool(CONFIG.get("manual_host_override", False)),
                    "manual_port_override": bool(CONFIG.get("manual_port_override", False)),
                },
                "saved_at": datetime.now().isoformat(),
            }
            tmp = DATA_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            tmp.replace(DATA_FILE)
        except Exception:
            pass


async def ensure_default_link():
    async with LINKS_LOCK:
        if not LINKS:
            digest = hashlib.sha256(("default" + SECRET_KEY).encode("utf-8")).hexdigest()
            uid = f"{digest[:8]}-{digest[8:12]}-{digest[12:16]}-{digest[16:20]}-{digest[20:32]}"
            LINKS[uid] = {
                "label": "default",
                "limit_bytes": 0,
                "used_bytes": 0,
                "created_at": datetime.now().isoformat(),
                "active": True,
                "expires_at": None,
                "is_default": True,
                "protocol": DEFAULT_PROTOCOL,
                "port": _effective_public_port(),
                "ip_limit": 0,
                "speed_limit_bytes": 0,
            }
            asyncio.create_task(save_state())


async def make_link(
    label: str = "poopy",
    limit_bytes: int = 0,
    expires_at: str | None = None,
    protocol: str = DEFAULT_PROTOCOL,
    port: int = DEFAULT_PORT,
    ip_limit: int = 0,
    speed_limit_bytes: int = 0,
    **kwargs,
):
    if protocol not in PROTOCOLS:
        protocol = DEFAULT_PROTOCOL
    uid = generate_uuid()
    record = {
        "label": (str(label or "").strip()[:50] or f"botvpn-{secrets.randbelow(900)+100}"),
        "limit_bytes": max(0, int(limit_bytes)),
        "used_bytes": 0,
        "created_at": datetime.now().isoformat(),
        "active": True,
        "expires_at": expires_at,
        "is_default": False,
        "protocol": protocol,
        "port": _effective_public_port(),
        "ip_limit": max(0, int(ip_limit)),
        "speed_limit_bytes": max(0, int(speed_limit_bytes)),
    }
    async with LINKS_LOCK:
        LINKS[uid] = record
    await save_state()
    return uid, record


async def remove_link(uid: str):
    async with LINKS_LOCK:
        if uid not in LINKS:
            return None
        label = LINKS[uid].get("label", uid)
        del LINKS[uid]
    await save_state()
    return label


def subscription_metadata_headers(used_bytes: int, limit_bytes: int, expires_at, title: str) -> dict:
    used_bytes = max(0, int(used_bytes or 0))
    limit_bytes = max(0, int(limit_bytes or 0))
    expire_unix = 0
    if expires_at:
        try:
            expire_unix = max(0, int(datetime.fromisoformat(str(expires_at)).timestamp()))
        except Exception:
            expire_unix = 0
    userinfo = f"upload=0; download={used_bytes}; total={limit_bytes}; expire={expire_unix}"
    title_b64 = "base64:" + base64.b64encode(str(title or "poopy vpn").encode("utf-8")).decode("ascii")
    return {
        "profile-title": title_b64,
        "profile-update-interval": "12",
        "subscription-userinfo": userinfo,
        "content-disposition": 'inline; filename="poopy_sub.txt"',
        "access-control-allow-origin": "*",
        "cache-control": "no-store, max-age=0",
    }


def escape_html(value) -> str:
    return (
        str(value if value is not None else "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#039;")
    )


# ============================================================
# EMBEDDED XHTTP HANDLER (Zero-Framework Pure Asyncio)
# ============================================================

xhttp_sessions: dict = {}
XHTTP_LOCK = asyncio.Lock()


async def _xhttp_reaper():
    while True:
        await asyncio.sleep(15)
        now = time.time()
        stale = [
            sid for sid, s in list(xhttp_sessions.items())
            if (now - s["last_seen"] > 35 and not s.get("tcp_open")) or (now - s["last_seen"] > 300)
        ]
        for sid in stale:
            await _xhttp_teardown(sid)


async def _xhttp_teardown(session_id: str):
    sess = xhttp_sessions.pop(session_id, None)
    if not sess:
        return
    sess["closed"] = True
    for k in ("downlink_task", "uplink_task"):
        t = sess.get(k)
        if t:
            t.cancel()
    w = sess.get("writer")
    if w:
        try:
            w.close()
            await w.wait_closed()
        except Exception:
            pass
    connections.pop(sess.get("conn_id"), None)
    dq = sess.get("down_q")
    if dq:
        try:
            dq.put_nowait(None)
        except Exception:
            pass


async def _xhttp_get_or_create(uid: str, mode: str, session_id: str, ip: str) -> dict | None:
    sess = xhttp_sessions.get(session_id)
    if sess is not None:
        sess["last_seen"] = time.time()
        return sess
    async with XHTTP_LOCK:
        sess = xhttp_sessions.get(session_id)
        if sess is not None:
            sess["last_seen"] = time.time()
            return sess
        link = LINKS.get(uid)
        if not is_link_allowed(link) or not is_ip_allowed(link, uid, ip):
            return None
        conn_id = secrets.token_urlsafe(6)
        conn_entry = {
            "uuid": uid,
            "ip": ip,
            "connected_at": datetime.now().isoformat(),
            "bytes": 0,
            "transport": "xhttp",
        }
        connections[conn_id] = conn_entry
        sess = {
            "uuid": uid,
            "link": link,
            "mode": mode,
            "writer": None,
            "downlink_task": None,
            "down_q": asyncio.Queue(maxsize=128),
            "last_seen": time.time(),
            "conn_id": conn_id,
            "conn_entry": conn_entry,
            "tcp_open": False,
            "closed": False,
            "seq_buf": {},
            "next_seq": 0,
            "up_lock": asyncio.Lock(),
        }
        xhttp_sessions[session_id] = sess
        return sess


async def _xhttp_open_target(session_id: str, uid: str, sess: dict, first_chunk: bytes):
    from relay_vless import parse_vless_header_ex, _fast_check_and_use, _resolve_dns_over_tcp
    from outbound_proxy import open_target_connection
    from speed_limit import throttle

    parsed = parse_vless_header_ex(first_chunk)
    if not parsed:
        raise ValueError("bad vless header")
    hdr_uid, command, address, port, payload, need_more = parsed
    if need_more:
        raise ValueError("incomplete vless header")

    link = sess.get("link") or LINKS.get(uid)
    conn_entry = sess.get("conn_entry")
    dq = sess["down_q"]

    if command == 2 and port == 53 and len(payload) >= 2:
        plen = int.from_bytes(payload[:2], "big")
        dns_q = payload[2 : 2 + plen]
        resp = await _resolve_dns_over_tcp(dns_q, address or "1.1.1.1", 53)
        if resp:
            framed = len(resp).to_bytes(2, "big") + resp
            await dq.put(b"\x00\x00" + framed)
        await dq.put(None)
        return

    reader, writer = await open_target_connection(link, address, port, timeout=8.0)
    sess["writer"] = writer
    sess["tcp_open"] = True
    if payload:
        writer.write(payload)
        await writer.drain()

    async def _pump():
        first = True
        has_limit = bool(link and int(link.get("speed_limit_bytes") or 0) > 0)
        try:
            while True:
                data = await reader.read(65536)
                if not data:
                    if first:
                        await dq.put(b"\x00\x00")
                    break
                n = len(data)
                if not _fast_check_and_use(link, n):
                    break
                if has_limit:
                    await throttle(uid, n)
                if conn_entry is not None:
                    conn_entry["bytes"] += n
                out = (b"\x00\x00" + data) if first else data
                first = False
                await dq.put(out)
        except Exception:
            pass
        finally:
            await _xhttp_teardown(session_id)

    sess["downlink_task"] = asyncio.create_task(_pump())


async def _handle_xhttp_request(
    method: str,
    path: str,
    body: bytes,
    writer: asyncio.StreamWriter,
    ip: str,
    keep_alive: bool = False,
):
    from relay_vless import _fast_check_and_use
    from speed_limit import throttle

    parts = [p for p in path.strip("/").split("/") if p]
    if len(parts) < 3:
        await _send_json(writer, 404, {"detail": "not found"})
        return

    mode = parts[1]
    uid = parts[2]
    session_id = parts[3] if len(parts) >= 4 else secrets.token_urlsafe(8)
    seq = int(parts[4]) if (len(parts) >= 5 and parts[4].isdigit()) else 0

    if method == "GET":
        sess = await _xhttp_get_or_create(uid, mode, session_id, ip)
        if not sess or sess.get("closed"):
            await _send_json(writer, 403, {"detail": "forbidden"})
            return
        hdr = (
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/octet-stream\r\n"
            "Cache-Control: no-store\r\n"
            "X-Accel-Buffering: no\r\n"
            "Transfer-Encoding: chunked\r\n"
            "Connection: keep-alive\r\n\r\n"
        ).encode("ascii")
        writer.write(hdr)
        await writer.drain()
        dq = sess["down_q"]
        try:
            while True:
                chunk = await dq.get()
                if chunk is None:
                    break
                sess["last_seen"] = time.time()
                frame = f"{len(chunk):x}\r\n".encode("ascii") + chunk + b"\r\n"
                writer.write(frame)
                if writer.transport.get_write_buffer_size() > 131072:
                    await writer.drain()
            writer.write(b"0\r\n\r\n")
            await writer.drain()
        except Exception:
            pass
        return

    if method == "POST":
        sess = await _xhttp_get_or_create(uid, mode, session_id, ip)
        if not sess or sess.get("closed"):
            await _send_json(writer, 403, {"detail": "forbidden"}, keep_alive=keep_alive)
            return
        sess["last_seen"] = time.time()
        if not body:
            await _send_json(writer, 200, {"ok": True}, keep_alive=keep_alive)
            return
        link = sess.get("link") or LINKS.get(uid)
        n = len(body)
        if not _fast_check_and_use(link, n):
            await _xhttp_teardown(session_id)
            await _send_json(writer, 403, {"detail": "quota"}, keep_alive=False)
            return
        if link and int(link.get("speed_limit_bytes") or 0) > 0:
            await throttle(uid, n)
        stats["total_requests"] += 1
        if sess.get("conn_entry") is not None:
            sess["conn_entry"]["bytes"] += n

        try:
            async with sess["up_lock"]:
                if sess["writer"] is None and not sess["tcp_open"]:
                    if seq != 0:
                        if len(sess["seq_buf"]) < 256:
                            sess["seq_buf"][seq] = body
                        await _send_json(writer, 200, {"ok": True}, keep_alive=keep_alive)
                        return
                    await _xhttp_open_target(session_id, uid, sess, body)
                    nxt = 1
                    while nxt in sess["seq_buf"] and sess["writer"] is not None:
                        sess["writer"].write(sess["seq_buf"].pop(nxt))
                        nxt += 1
                    sess["next_seq"] = nxt
                    if sess["writer"] is not None:
                        await sess["writer"].drain()
                    await _send_json(writer, 200, {"ok": True}, keep_alive=keep_alive)
                    return

                if sess["writer"] is not None:
                    if seq == sess["next_seq"]:
                        sess["writer"].write(body)
                        sess["next_seq"] += 1
                        while sess["next_seq"] in sess["seq_buf"]:
                            sess["writer"].write(sess["seq_buf"].pop(sess["next_seq"]))
                            sess["next_seq"] += 1
                    elif seq > sess["next_seq"] and len(sess["seq_buf"]) < 256:
                        sess["seq_buf"][seq] = body
                    if sess["writer"].transport.get_write_buffer_size() > 131072:
                        await sess["writer"].drain()
        except Exception:
            await _xhttp_teardown(session_id)
            await _send_json(writer, 502, {"detail": "error"}, keep_alive=False)
            return

        await _send_json(writer, 200, {"ok": True}, keep_alive=keep_alive)


# ============================================================
# ZERO-FRAMEWORK PURE ASYNCIO HTTP HANDLER (Panel + Sub + API)
# ============================================================

from pages import LOGIN_HTML, DASHBOARD_HTML, ASSET_QR_JS_B64, UI_CSS

_QR_BYTES = base64.b64decode(ASSET_QR_JS_B64)

_STATUS_TEXT = {
    200: "OK",
    303: "See Other",
    307: "Temporary Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not Found",
    500: "Internal Server Error",
    502: "Bad Gateway",
}


async def _send_http(
    writer: asyncio.StreamWriter,
    status: int,
    body: bytes,
    content_type: str = "text/html; charset=utf-8",
    extra_headers: dict | None = None,
    keep_alive: bool = False,
):
    st_txt = _STATUS_TEXT.get(status, "OK")
    conn_hdr = "keep-alive" if keep_alive else "close"
    hdr_lines = [
        f"HTTP/1.1 {status} {st_txt}",
        f"Content-Type: {content_type}",
        f"Content-Length: {len(body)}",
        f"Connection: {conn_hdr}",
    ]
    if extra_headers:
        for k, v in extra_headers.items():
            hdr_lines.append(f"{k}: {v}")
    raw_hdr = ("\r\n".join(hdr_lines) + "\r\n\r\n").encode("latin-1", errors="ignore")
    writer.write(raw_hdr + body)
    await writer.drain()


async def _send_json(
    writer: asyncio.StreamWriter,
    status: int,
    data: dict | list,
    extra_headers: dict | None = None,
    keep_alive: bool = False,
):
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    await _send_http(writer, status, raw, "application/json; charset=utf-8", extra_headers, keep_alive=keep_alive)


def _parse_cookies(cookie_hdr: str) -> dict:
    out = {}
    for part in (cookie_hdr or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def _read_rss_mb() -> float:
    try:
        with open("/proc/self/statm", "r") as f:
            pages = int(f.read().split()[1])
        return round((pages * 4096) / (1024 * 1024), 1)
    except Exception:
        return 18.0


async def handle_http_stream(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    head_bytes: bytes,
    body_bytes: bytes,
    ip: str,
):
    try:
        while True:
            lines = head_bytes.decode("latin-1", errors="ignore").split("\r\n")
            if not lines or not lines[0]:
                return
            req_line = lines[0].split(" ")
            if len(req_line) < 2:
                return
            method = req_line[0].upper()
            full_path = req_line[1]
            path, _, query_str = full_path.partition("?")
            query = {k: v[0] for k, v in parse_qs(query_str).items()}

            headers = {}
            for ln in lines[1:]:
                if ":" in ln:
                    k, v = ln.split(":", 1)
                    headers[k.strip().lower()] = v.strip()

            fwd = headers.get("x-forwarded-for")
            if fwd:
                ip = fwd.split(",")[0].strip()
            elif headers.get("x-real-ip"):
                ip = headers["x-real-ip"].strip()

            # Auto-detect panel public IP/host & port from browser/client Host header
            raw_host_hdr = (headers.get("x-forwarded-host") or headers.get("host") or "").split(",")[0].strip()
            if raw_host_hdr and not CONFIG.get("manual_host_override"):
                h_part = raw_host_hdr
                p_part = ""
                if ":" in raw_host_hdr and not raw_host_hdr.startswith("["):
                    h_part, p_part = raw_host_hdr.rsplit(":", 1)
                h_part = h_part.strip()
                if h_part and not _is_invalid_host(h_part) and not h_part.endswith(".sslip.io"):
                    changed_hp = False
                    if CONFIG.get("tcp_public_host") != h_part:
                        CONFIG["tcp_public_host"] = h_part
                        CONFIG["host"] = h_part
                        changed_hp = True
                    if p_part.isdigit() and not CONFIG.get("manual_port_override") and CONFIG.get("tcp_public_port") != p_part:
                        CONFIG["tcp_public_port"] = p_part
                        changed_hp = True
                    if h_part.lower() not in _HOST_IPV4_CACHE:
                        await _ensure_domain_ipv4_resolved(h_part)
                    if changed_hp:
                        asyncio.create_task(_prewarm_cloud_subs())

            content_len = safe_int(headers.get("content-length", 0), 0, 0, 4 * 1024 * 1024)
            while len(body_bytes) < content_len:
                more = await asyncio.wait_for(reader.read(65536), timeout=8.0)
                if not more:
                    break
                body_bytes += more

            req_body = body_bytes[:content_len]
            leftover = body_bytes[content_len:]

            if path.startswith(("/xhttp-siz10/", "/xhttp/")):
                ka = headers.get("connection", "").lower() != "close" and method == "POST"
                await _handle_xhttp_request(method, path, req_body, writer, ip, keep_alive=ka)
                if not ka:
                    return
                buf = leftover
                while b"\r\n\r\n" not in buf:
                    more = await asyncio.wait_for(reader.read(65536), timeout=15.0)
                    if not more:
                        return
                    buf += more
                head_bytes, _, body_bytes = buf.partition(b"\r\n\r\n")
                continue

            cookies = _parse_cookies(headers.get("cookie", ""))
            tok = cookies.get(SESSION_COOKIE)
            sess_ok = await is_valid_session(tok)

            if path == "/health":
                await _send_json(writer, 200, {"status": "ok", "service": APP_NAME, "version": APP_VERSION, "connections": len(connections)})
                return

            if path == "/assets/qr.js":
                await _send_http(writer, 200, _QR_BYTES, "application/javascript; charset=utf-8", {"Cache-Control": "public, max-age=604800"})
                return

            if path == "/assets/ui.css":
                await _send_http(writer, 200, UI_CSS.encode("utf-8"), "text/css; charset=utf-8", {"Cache-Control": "public, max-age=604800"})
                return

            if path == "/":
                loc = "/dashboard" if sess_ok else "/login"
                await _send_http(writer, 303, b"", "text/plain", {"Location": loc})
                return

            if path == "/login" and method == "GET":
                if sess_ok:
                    await _send_http(writer, 303, b"", "text/plain", {"Location": "/dashboard"})
                    return
                await _send_http(writer, 200, LOGIN_HTML.encode("utf-8"))
                return

            if path in ("/login", "/api/login") and method == "POST":
                ctype = headers.get("content-type", "").lower()
                if "application/json" in ctype:
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    u = str(b.get("username", "")).strip()
                    p = str(b.get("password", "")).strip()
                else:
                    q = parse_qs(req_body.decode("utf-8", errors="ignore"))
                    u = (q.get("username", [""])[0]).strip()
                    p = (q.get("password", [""])[0]).strip()

                ok_cred, _, _, _ = verify_admin_credentials(u, p)
                if not ok_cred:
                    if path == "/api/login":
                        await _send_json(writer, 401, {"detail": "Wrong username or password"})
                    else:
                        err = '<div class="error">Wrong username or password</div>'
                        await _send_http(writer, 401, LOGIN_HTML.replace("<!--LOGIN_ERROR-->", err, 1).encode("utf-8"))
                    return

                new_tok = await create_session("owner", "owner")
                cookie_val = f"{SESSION_COOKIE}={new_tok}; Max-Age={SESSION_TTL}; Path=/; HttpOnly; SameSite=Lax"
                if path == "/api/login":
                    await _send_json(
                        writer,
                        200,
                        {"ok": True, "authenticated": True, "admin": {"id": "owner", "username": AUTH["username"], "role": "owner"}},
                        {"Set-Cookie": cookie_val},
                    )
                else:
                    await _send_http(writer, 303, b"", "text/plain", {"Location": "/dashboard", "Set-Cookie": cookie_val})
                return

            if path == "/logout":
                if tok:
                    SESSIONS.pop(tok, None)
                await _send_http(writer, 303, b"", "text/plain", {"Location": "/login", "Set-Cookie": f"{SESSION_COOKIE}=; Max-Age=0; Path=/"})
                return

            if path == "/dashboard":
                if not sess_ok:
                    await _send_http(writer, 303, b"", "text/plain", {"Location": "/login"})
                    return
                await _send_http(writer, 200, DASHBOARD_HTML.encode("utf-8"))
                return

            if path.startswith("/sub-json/"):
                uid = path.split("/sub-json/", 1)[1].strip("/")
                query["json"] = "1"
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path.startswith("/sub/"):
                uid = path.split("/sub/", 1)[1].strip("/")
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path.startswith("/s/"):
                uid = path.split("/s/", 1)[1].strip("/")
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path == "/api/v1/client/subscribe":
                uid = str(query.get("token") or query.get("uuid") or "").strip()
                await _serve_sub_feed(writer, uid, query, headers)
                return

            if path.startswith(("/info/", "/subscription/", "/p/")):
                uid = path.strip("/").split("/", 1)[1].strip("/")
                ua = headers.get("user-agent", "").lower()
                accept = headers.get("accept", "").lower()
                if any(x in ua for x in ("happ", "v2ray", "npv", "hiddify", "streisand", "sing-box", "clash", "shadowrocket", "nekoray", "nekobox", "v2box")) or headers.get("x-hwid") or "text/html" not in accept:
                    await _serve_sub_feed(writer, uid, query, headers)
                else:
                    await _serve_info_page(writer, uid)
                return

            if path.startswith("/api/"):
                if not sess_ok:
                    await _send_json(writer, 401, {"detail": "unauthorized"})
                    return

                if path == "/api/init" and method == "GET":
                    items = [get_link_info(l, u) for u, l in LINKS.items()]
                    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
                    await _send_json(writer, 200, {
                        "ok": True,
                        "links": items,
                        "connections": len(connections),
                        "total_bytes": sum(x["used_bytes"] for x in items),
                        "rss_mb": _read_rss_mb(),
                        "settings": {
                            "host": get_host(),
                            "ipv4_host": get_ipv4_host(),
                            "domain_host": get_domain_host(),
                            "port": _effective_public_port(),
                            "public_domain": CONFIG.get("public_domain", ""),
                            "admin_username": AUTH.get("username", "admin"),
                        },
                    })
                    return

                if path == "/api/links" and method == "GET":
                    items = [get_link_info(l, u) for u, l in LINKS.items()]
                    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
                    await _send_json(writer, 200, {"links": items})
                    return

                if path == "/api/links" and method == "POST":
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    label = str(b.get("label") or "").strip()[:50] or f"botvpn-{secrets.randbelow(900)+100}"
                    proto = str(b.get("protocol") or DEFAULT_PROTOCOL).strip().lower()
                    if proto not in PROTOCOLS:
                        proto = DEFAULT_PROTOCOL
                    gb = safe_float(b.get("limit_value", 0))
                    limit_bytes = int(gb * (1024 ** 3)) if gb > 0 else 0
                    days = safe_int(b.get("expires_days", 0), minimum=0)
                    expires_at = (datetime.now() + timedelta(days=days)).isoformat() if days > 0 else None
                    ip_limit = safe_int(b.get("ip_limit", 0), minimum=0)
                    spd = safe_float(b.get("speed_limit_value", 0))
                    speed_bytes = int(spd * 1024 * 1024 / 8) if spd > 0 else 0

                    uid, rec = await make_link(
                        label=label,
                        limit_bytes=limit_bytes,
                        expires_at=expires_at,
                        protocol=proto,
                        port=_effective_public_port(),
                        ip_limit=ip_limit,
                        speed_limit_bytes=speed_bytes,
                    )
                    await _send_json(writer, 200, {"ok": True, **get_link_info(rec, uid)})
                    return

                if path.startswith("/api/links/"):
                    rest = path.split("/api/links/", 1)[1].strip("/")
                    parts = rest.split("/")
                    uid = parts[0]
                    if uid not in LINKS:
                        await _send_json(writer, 404, {"detail": "not found"})
                        return

                    if len(parts) == 2 and parts[1] == "cloud-sub" and method == "POST":
                        url = await _publish_trusted_https_sub(uid)
                        info = get_link_info(LINKS[uid], uid)
                        await _send_json(writer, 200, {"ok": True, "url": url or info["sub_https"], "trusted": bool(url)})
                        return

                    if len(parts) == 2 and parts[1] == "action" and method == "POST":
                        b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                        act = str(b.get("action") or "").lower()
                        if act == "reset":
                            LINKS[uid]["used_bytes"] = 0
                        elif act == "enable":
                            LINKS[uid]["active"] = True
                        elif act == "disable":
                            LINKS[uid]["active"] = False
                        await save_state()
                        await _send_json(writer, 200, {"ok": True})
                        return

                    if len(parts) == 1 and method == "PATCH":
                        b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                        l = LINKS[uid]
                        if "label" in b and str(b["label"]).strip():
                            l["label"] = str(b["label"]).strip()[:50]
                        if "protocol" in b and str(b["protocol"]).strip().lower() in PROTOCOLS:
                            l["protocol"] = str(b["protocol"]).strip().lower()
                        if "limit_value" in b:
                            gb = safe_float(b.get("limit_value", 0))
                            l["limit_bytes"] = int(gb * (1024 ** 3)) if gb > 0 else 0
                        if "expires_days" in b:
                            days = safe_int(b.get("expires_days", 0), minimum=0)
                            l["expires_at"] = (datetime.now() + timedelta(days=days)).isoformat() if days > 0 else None
                        if "ip_limit" in b:
                            l["ip_limit"] = safe_int(b.get("ip_limit", 0), minimum=0)
                        if "speed_limit_value" in b:
                            spd = safe_float(b.get("speed_limit_value", 0))
                            l["speed_limit_bytes"] = int(spd * 1024 * 1024 / 8) if spd > 0 else 0
                        await save_state()
                        await _send_json(writer, 200, {"ok": True, **get_link_info(l, uid)})
                        return

                    if len(parts) == 1 and method == "DELETE":
                        await remove_link(uid)
                        await _send_json(writer, 200, {"ok": True})
                        return

                if path == "/api/connections" and method == "GET":
                    grouped = {}
                    for c in connections.values():
                        cip = c.get("ip", "unknown")
                        l = LINKS.get(c.get("uuid"))
                        label = l.get("label", "unknown") if l else "unknown"
                        g = grouped.setdefault(cip, {"ip": cip, "sessions": 0, "bytes": 0, "labels": set(), "transports": set()})
                        g["sessions"] += 1
                        g["bytes"] += int(c.get("bytes", 0) or 0)
                        g["labels"].add(label)
                        g["transports"].add(c.get("transport", "tcp"))
                    out = [{"ip": g["ip"], "sessions": g["sessions"], "label": ", ".join(sorted(g["labels"])), "transports": sorted(g["transports"]), "bytes": g["bytes"]} for g in grouped.values()]
                    await _send_json(writer, 200, {"connections": out})
                    return

                if path == "/api/settings" and method == "GET":
                    await _send_json(writer, 200, {
                        "ok": True,
                        "tcp_public_host": get_host(),
                        "tcp_public_port": str(_effective_public_port()),
                        "public_domain": CONFIG.get("public_domain", ""),
                        "effective_host": get_host(),
                        "effective_port": _effective_public_port(),
                        "admin_username": AUTH.get("username", "admin"),
                    })
                    return

                if path == "/api/settings" and method == "POST":
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    if "tcp_public_host" in b and str(b["tcp_public_host"]).strip():
                        nh = str(b["tcp_public_host"]).strip()
                        if "://" in nh:
                            nh = nh.split("://", 1)[1].split("/", 1)[0].split(":", 1)[0].strip()
                        if not _is_invalid_host(nh):
                            CONFIG["tcp_public_host"] = nh
                            CONFIG["host"] = nh
                            CONFIG["manual_host_override"] = True
                    if "tcp_public_port" in b and str(b["tcp_public_port"]).strip().isdigit():
                        CONFIG["tcp_public_port"] = str(b["tcp_public_port"]).strip()
                        CONFIG["manual_port_override"] = True
                    if "public_domain" in b:
                        dom = str(b.get("public_domain") or "").strip()
                        CONFIG["public_domain"] = "" if _is_invalid_host(dom) else dom
                    await save_state()
                    await _send_json(writer, 200, {"ok": True})
                    return

                if path == "/api/change-password" and method == "POST":
                    b = json.loads(req_body.decode("utf-8", errors="ignore") or "{}")
                    cur = str(b.get("current_password") or "")
                    new = str(b.get("new_password") or "")
                    ok_pw, _, _, _ = verify_admin_credentials(AUTH.get("username", "admin"), cur)
                    if not ok_pw:
                        await _send_json(writer, 400, {"detail": "Current password is wrong"})
                        return
                    if len(new) < 4:
                        await _send_json(writer, 400, {"detail": "Password too short"})
                        return
                    AUTH["password_hash"] = hash_password(new)
                    await save_state()
                    await _send_json(writer, 200, {"ok": True})
                    return

            await _send_json(writer, 404, {"detail": "Not Found"})
            return
    except Exception:
        pass



async def _publish_trusted_https_sub(uid: str) -> str | None:
    """
    Publish the Base64 subscription payload for `uid` to a public CA-signed HTTPS raw paste service
    (port 443, Let's Encrypt / Cloudflare certificate) so v2rayN, NPV Tunnel, and Happ can import
    an `https://` subscription URL with ZERO self-signed SSL ("insecure") errors!
    """
    import ssl as _ssl
    link = LINKS.get(uid)
    if not link:
        return None
    cur_hp = f"{get_domain_host()}:{_effective_public_port()}"
    existing = str(link.get("trusted_https_sub") or "").strip()
    if existing and link.get("trusted_sub_host") == cur_hp:
        return existing

    all_links = all_protocol_links_for(link, uid)
    raw_text = "\n".join([all_links["reality"], all_links["tcp"]]) + "\n"
    b64_bytes = base64.b64encode(raw_text.encode("utf-8"))

    ctx = _ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = _ssl.CERT_NONE

    # 1. Try api.pastes.dev and bytebin.lucko.me (JSON {"key": "..."} -> https://<host>/<key>)
    for host, path, raw_prefix in (
        ("api.pastes.dev", "/post", "https://api.pastes.dev/"),
        ("bytebin.lucko.me", "/post", "https://bytebin.lucko.me/"),
    ):
        writer = None
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, 443, ssl=ctx, server_hostname=host),
                timeout=2.5,
            )
            req = (
                f"POST {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"User-Agent: botvpn-vpn/25.0\r\n"
                f"Content-Type: text/plain; charset=utf-8\r\n"
                f"Content-Length: {len(b64_bytes)}\r\n"
                f"Connection: close\r\n\r\n"
            ).encode("ascii") + b64_bytes
            writer.write(req)
            await writer.drain()
            resp = await asyncio.wait_for(reader.read(4096), timeout=2.5)
            body = resp.decode("utf-8", errors="ignore").split("\r\n\r\n", 1)[-1].strip()
            j = json.loads(body)
            key = str(j.get("key") or "").strip()
            if key:
                url = f"{raw_prefix}{key}"
                link["trusted_https_sub"] = url
                link["trusted_sub_host"] = cur_hp
                return url
        except Exception:
            pass
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass

    # 2. Try paste.rs (returns plain https://paste.rs/<id>)
    writer = None
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection("paste.rs", 443, ssl=ctx, server_hostname="paste.rs"),
            timeout=2.5,
        )
        req = (
            f"POST / HTTP/1.1\r\n"
            f"Host: paste.rs\r\n"
            f"User-Agent: curl/8.0\r\n"
            f"Content-Type: text/plain; charset=utf-8\r\n"
            f"Content-Length: {len(b64_bytes)}\r\n"
            f"Connection: close\r\n\r\n"
        ).encode("ascii") + b64_bytes
        writer.write(req)
        await writer.drain()
        resp = await asyncio.wait_for(reader.read(4096), timeout=2.5)
        body = resp.decode("utf-8", errors="ignore").split("\r\n\r\n", 1)[-1].strip()
        if body.startswith("https://paste.rs/"):
            url = body.splitlines()[0].strip()
            link["trusted_https_sub"] = url
            link["trusted_sub_host"] = cur_hp
            return url
    except Exception:
        pass
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception:
                pass

    return None


async def _serve_sub_feed(writer: asyncio.StreamWriter, uid: str, query: dict, req_headers: dict | None = None):
    link = LINKS.get(uid)
    if not is_link_allowed(link):
        await _send_json(writer, 404, {"detail": "not found or inactive"})
        return

    used = int(link.get("used_bytes", 0) or 0)
    limit = int(link.get("limit_bytes", 0) or 0)
    title = str(link.get("label") or "poopy vpn")
    hdrs = subscription_metadata_headers(used, limit, link.get("expires_at"), title)

    if str(query.get("json", query.get("format", ""))).lower() in ("1", "true", "json"):
        arr = build_happ_xray_json_profiles(link, uid)
        await _send_json(writer, 200, arr, hdrs)
        return

    # Output VLESS links in pure Base64 (NO #comment lines so NPV Tunnel, Happ, and v2rayN import 100% cleanly):
    all_links = all_protocol_links_for(link, uid)
    ua_lower = str((req_headers or {}).get("user-agent") or "").lower()
    is_happ = ("happ" in ua_lower) or ("x-hwid" in (req_headers or {}))
    if is_happ:
        # Serve only the working [TCP-REALITY] config on Happ so there are zero dead profiles
        lines = [
            all_links["reality"],
        ]
    else:
        # 1. [TCP-REALITY] (Happ, v2rayN, NPV Tunnel, Iran)
        # 2. [Raw-TCP] (NPV Tunnel, v2rayN)
        lines = [
            all_links["reality"],
            all_links["tcp"],
        ]
    raw_text = "\n".join(lines) + "\n"
    if str(query.get("raw", "")).lower() in ("1", "plain", "true"):
        content = raw_text.encode("utf-8")
    else:
        content = base64.b64encode(raw_text.encode("utf-8"))

    await _send_http(writer, 200, content, "text/plain; charset=utf-8", hdrs)


async def _serve_info_page(writer: asyncio.StreamWriter, uid: str):
    link = LINKS.get(uid)
    if not link:
        await _send_http(writer, 404, b"Not found", "text/plain")
        return

    info = get_link_info(link, uid)
    sub_e = escape_html(info["sub"])
    vless_r_e = escape_html(info["vless_reality"])
    vless_t_e = escape_html(info["vless_tcp"])
    used_e = escape_html(fmt_bytes(info["used_bytes"]))
    lim_e = escape_html(fmt_bytes(info["limit_bytes"]) if info["limit_bytes"] else "Unlimited")

    html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escape_html(info['label'])}</title>
<script src="/assets/qr.js"></script>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#000;color:#fff;font-family:system-ui,-apple-system,sans-serif;font-size:13.5px;padding:16px}}
.wrap{{max-width:540px;margin:0 auto}}
.card{{background:#0a0a0a;border:1px solid #222;border-radius:6px;padding:16px;margin-bottom:12px}}
.btn{{padding:6px 12px;background:#111;border:1px solid #333;border-radius:4px;color:#fff;cursor:pointer;font-size:12px}}
.btn:hover{{background:#fff;color:#000}}
.code{{background:#000;border:1px solid #222;border-radius:4px;padding:8px;font:11px monospace;word-break:break-all;margin-top:4px;color:#bbb}}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <b>{escape_html(info['label'])}</b>
      <span style="font-size:12px;color:#aaa">{used_e} / {lim_e}</span>
    </div>
    <div style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:#888">1. VLESS TCP-REALITY (Happ / v2rayN / NPV Tunnel / Iran)</span>
        <button class="btn" onclick="cp('{vless_r_e}')">Copy REALITY</button>
      </div>
      <div class="code">{vless_r_e}</div>
    </div>
    <div style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:#888">2. VLESS Raw-TCP (NPV Tunnel / v2rayN)</span>
        <button class="btn" onclick="cp('{vless_t_e}')">Copy Raw-TCP</button>
      </div>
      <div class="code">{vless_t_e}</div>
    </div>
    <div style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:#888">Subscription URL (HTTPS — Includes Both)</span>
        <button class="btn" onclick="cp('{sub_e}')">Copy Sub</button>
      </div>
      <div class="code">{sub_e}</div>
    </div>
  </div>
</div>
<script>
function cp(t){{
  if(navigator.clipboard)navigator.clipboard.writeText(t);
  else{{var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove()}}
}}
</script>
</body>
</html>"""
    await _send_http(writer, 200, html.encode("utf-8"))


async def _state_autosave_loop():
    while True:
        await asyncio.sleep(180)
        await save_state()


async def _autodetect_public_ip():
    """Fast non-blocking outbound IP check so KataBump / Nexcloud panels know their exact numeric IPv4."""
    for host, path in (("api.ipify.org", "/"), ("icanhazip.com", "/"), ("ifconfig.me", "/ip")):
        writer = None
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, 80), timeout=2.5)
            req = f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: curl/8.0\r\nConnection: close\r\n\r\n"
            writer.write(req.encode("ascii"))
            await writer.drain()
            raw = await asyncio.wait_for(reader.read(1024), timeout=2.5)
            body = raw.decode("latin-1", errors="ignore").split("\r\n\r\n", 1)[-1].strip()
            ip_obj = ipaddress.ip_address(body)
            if ip_obj.is_global and ip_obj.version == 4:
                detected = str(ip_obj)
                CONFIG["detected_ipv4"] = detected
                if not os.environ.get("PUBLIC_SERVER_IP") and not CONFIG.get("manual_host_override"):
                    if CONFIG.get("tcp_public_host") == PUBLIC_SERVER_IP:
                        CONFIG["tcp_public_host"] = detected
                        CONFIG["host"] = detected
                return
        except Exception:
            pass
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass


async def _prewarm_cloud_subs():
    await asyncio.sleep(0.5)
    for uid in list(LINKS.keys()):
        try:
            await _publish_trusted_https_sub(uid)
        except Exception:
            pass


async def run_server():
    import tcp_relay

    await load_state()
    await ensure_default_link()
    await _autodetect_public_ip()
    asyncio.create_task(_state_autosave_loop())
    asyncio.create_task(_prewarm_cloud_subs())

    await tcp_relay.start_tcp_relay(
        public_port=PORT,
        enable_multiplexer=True,
        data_dir=DATA_DIR,
    )
    p = _effective_public_port()
    h = get_host()
    print(f"[{APP_NAME} v{APP_VERSION}] Running on 0.0.0.0:{PORT} -> Panel: http://{h}:{p}/login (Default login: admin / admin)", flush=True)
    await asyncio.Event().wait()


# Export `app` symbol so panels/launchers doing `from main import run_server, app` never fail
app = run_server


if __name__ == "__main__":
    asyncio.run(run_server())