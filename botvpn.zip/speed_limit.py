# speed_limit.py — Non-Blocking Token-Bucket Bandwidth Limiter (Deadlock-Free)
import asyncio
import time

from main import LINKS

_buckets: dict = {}

MIN_RATE = 1024
MIN_BURST = 512 * 1024
MAX_BUCKETS = 2000


class _Bucket:
    __slots__ = ("rate", "capacity", "tokens", "last")

    def __init__(self, rate_bytes_per_sec: float):
        self.rate = max(float(rate_bytes_per_sec), float(MIN_RATE))
        self.capacity = max(self.rate * 2.0, float(MIN_BURST))
        self.tokens = self.capacity
        self.last = time.monotonic()

    async def consume(self, n: int):
        now = time.monotonic()
        elapsed = now - self.last
        if elapsed > 0:
            self.last = now
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
        self.tokens -= n
        if self.tokens < 0:
            wait = min((-self.tokens) / self.rate, 0.4)
            if wait > 0.002:
                await asyncio.sleep(wait)


def _get_bucket(uuid: str, rate: int) -> _Bucket:
    b = _buckets.get(uuid)
    if b is None or b.rate != max(float(rate), float(MIN_RATE)):
        if len(_buckets) >= MAX_BUCKETS:
            _buckets.clear()
        b = _Bucket(rate)
        _buckets[uuid] = b
    return b


async def throttle(uuid: str, nbytes: int):
    if nbytes <= 0:
        return
    link = LINKS.get(uuid)
    if not link:
        return
    rate = int(link.get("speed_limit_bytes") or 0)
    if rate <= 0:
        return
    bucket = _get_bucket(uuid, rate)
    await bucket.consume(nbytes)


def reset_bucket(uuid: str):
    _buckets.pop(uuid, None)