# relay_vless.py — BotVPN Ultra-Fast Parser & TUN-Safe RFC-1035 DNS Engine (VLESS Raw TCP + XUDP/Mux)
import asyncio
import base64
import hashlib
import os
import socket
import struct
import time
import uuid as uuid_lib
from datetime import datetime

from main import (
    LINKS,
    stats,
    hourly_traffic,
    is_link_allowed,
    now_ir,
)

ALLOW_ALL_UDP = os.environ.get("VW_ALLOW_UDP", "1").strip().lower() not in ("0", "false", "no", "off")

_cached_hour_key = ""
_cached_hour_mono = 0.0
_cached_wall_ts = 0.0

_trojan_cache_ver = -1
_trojan_map: dict[bytes, str] = {}

# Wire-level DNS response cache: key = raw DNS question bytes -> (resp_without_txid, expire_mono)
_DNS_PKT_CACHE: dict[bytes, tuple[bytes, float]] = {}
_DNS_PKT_TTL = 600.0
_DNS_PKT_MAX = 8192


def _get_hour_and_ts() -> tuple[str, float]:
    global _cached_hour_key, _cached_hour_mono, _cached_wall_ts
    mono = time.monotonic()
    if mono - _cached_hour_mono > 10.0 or not _cached_hour_key:
        _cached_hour_mono = mono
        _cached_wall_ts = time.time()
        _cached_hour_key = now_ir().strftime("%H:00")
    return _cached_hour_key, _cached_wall_ts


def _is_link_allowed_fast(link: dict | None, now_ts: float) -> bool:
    if link is None or not link.get("active", True):
        return False
    limit = int(link.get("limit_bytes") or 0)
    if limit > 0 and int(link.get("used_bytes") or 0) >= limit:
        return False
    exp_str = link.get("expires_at")
    if exp_str:
        if link.get("_exp_src") != exp_str:
            try:
                link["_exp_ts"] = datetime.fromisoformat(str(exp_str)).timestamp()
            except Exception:
                link["_exp_ts"] = 0.0
            link["_exp_src"] = exp_str
        exp_ts = link.get("_exp_ts") or 0.0
        if exp_ts > 0.0 and now_ts > exp_ts:
            return False
    return True


def _fast_check_and_use(link: dict | None, n: int) -> bool:
    hour_key, now_ts = _get_hour_and_ts()
    if not _is_link_allowed_fast(link, now_ts):
        return False
    link["used_bytes"] = int(link.get("used_bytes") or 0) + n
    stats["total_bytes"] += n
    hourly_traffic[hour_key] += n
    return True


async def check_and_use(uid: str, n: int) -> bool:
    return _fast_check_and_use(LINKS.get(uid), n)


def resolve_trojan_uuid(sha224_hex: bytes) -> str | None:
    global _trojan_cache_ver, _trojan_map
    cur_len = len(LINKS)
    if _trojan_cache_ver != cur_len or sha224_hex not in _trojan_map:
        new_map: dict[bytes, str] = {}
        for uid, link in LINKS.items():
            h1 = hashlib.sha224(uid.encode("utf-8")).hexdigest().lower().encode("ascii")
            new_map[h1] = uid
        _trojan_map = new_map
        _trojan_cache_ver = cur_len
    return _trojan_map.get(sha224_hex.lower())


def parse_trojan_header_ex(chunk: bytes):
    """
    Parse Trojan wire header:
      [56B hex(SHA224(password))][\r\n][1B cmd][1B atyp][addr][2B port][\r\n][payload]
    Returns (uid, cmd, address, port, payload, need_more) or None if invalid.
    """
    if len(chunk) < 58:
        return None, 0, "", 0, b"", True
    if chunk[56:58] != b"\r\n":
        return None
    uid = resolve_trojan_uuid(chunk[:56])
    if not uid:
        return None
    if len(chunk) < 64:
        return None, 0, "", 0, b"", True
    cmd = chunk[58]
    atyp = chunk[59]
    pos = 60
    if atyp == 1:
        if len(chunk) < pos + 4 + 2 + 2:
            return None, 0, "", 0, b"", True
        address = ".".join(str(b) for b in chunk[pos : pos + 4])
        pos += 4
    elif atyp == 3:
        dlen = chunk[pos]
        pos += 1
        if len(chunk) < pos + dlen + 2 + 2:
            return None, 0, "", 0, b"", True
        address = chunk[pos : pos + dlen].decode("utf-8", errors="ignore")
        pos += dlen
    elif atyp == 4:
        if len(chunk) < pos + 16 + 2 + 2:
            return None, 0, "", 0, b"", True
        ab = chunk[pos : pos + 16]
        pos += 16
        address = ":".join(f"{ab[i]:02x}{ab[i+1]:02x}" for i in range(0, 16, 2))
    else:
        return None
    port = int.from_bytes(chunk[pos : pos + 2], "big")
    pos += 2
    if chunk[pos : pos + 2] == b"\r\n":
        pos += 2
    return uid, cmd, address, port, chunk[pos:], False


def has_vision_flow(chunk: bytes) -> bool:
    """Return True if the VLESS header addon specifies xtls-rprx-vision."""
    if len(chunk) >= 18 and chunk[0] in (0, 1):
        alen = chunk[17]
        if alen > 0 and len(chunk) >= 18 + alen:
            return b"xtls-rprx-vision" in chunk[18 : 18 + alen]
    return False


def parse_vless_header_ex(chunk: bytes):
    """
    Parse VLESS wire header supporting TCP (cmd=1), UDP (cmd=2), and XUDP/Mux (cmd=3).
    For cmd=3, returns (uid, 3, "1.1.1.1", 53, raw_mux_stream, False) so the XUDP/Mux handler
    receives the complete uncorrupted Mux frame stream!
    """
    if len(chunk) < 18:
        if chunk and chunk[0] not in (0, 1):
            return None
        return None, 0, "", 0, b"", True
    try:
        version = chunk[0]
        if version not in (0, 1):
            return None
        uid = str(uuid_lib.UUID(bytes=chunk[1:17]))
        addon_len = chunk[17]
        pos = 18 + addon_len
        if len(chunk) < pos + 1:
            return None, 0, "", 0, b"", True
        command = chunk[pos]
        pos += 1

        # Command 3 = Mux / XUDP: pass raw mux frames intact (handles both direct Xray XUDP and dummy port=0 header)!
        if command == 3:
            if len(chunk) >= pos + 4 and chunk[pos : pos + 2] == b"\x00\x00" and chunk[pos + 2] == 2:
                dlen = chunk[pos + 3]
                if len(chunk) < pos + 4 + dlen:
                    return None, 0, "", 0, b"", True
                pos += 4 + dlen
            return uid, 3, "1.1.1.1", 53, chunk[pos:], False

        if len(chunk) < pos + 3:
            return None, 0, "", 0, b"", True
        port = int.from_bytes(chunk[pos : pos + 2], "big")
        pos += 2
        addr_type = chunk[pos]
        pos += 1

        if addr_type == 1:
            if len(chunk) < pos + 4:
                return None, 0, "", 0, b"", True
            address = ".".join(str(b) for b in chunk[pos : pos + 4])
            pos += 4
        elif addr_type == 2:
            if len(chunk) < pos + 1:
                return None, 0, "", 0, b"", True
            dlen = chunk[pos]
            pos += 1
            if len(chunk) < pos + dlen:
                return None, 0, "", 0, b"", True
            address = chunk[pos : pos + dlen].decode("utf-8", errors="ignore")
            pos += dlen
        elif addr_type == 3:
            if len(chunk) < pos + 16:
                return None, 0, "", 0, b"", True
            ab = chunk[pos : pos + 16]
            pos += 16
            address = ":".join(f"{ab[i]:02x}{ab[i+1]:02x}" for i in range(0, 16, 2))
        else:
            return None

        return uid, command, address, port, chunk[pos:], False
    except Exception:
        return None


def _decode_base64_any(token: str) -> bytes | None:
    clean = token.strip()
    if not clean:
        return None
    try:
        normalized = clean.replace("-", "+").replace("_", "/")
        padded = normalized + "=" * ((4 - len(normalized) % 4) % 4)
        raw = base64.b64decode(padded.encode("ascii"), validate=False)
        if raw:
            return raw
    except Exception:
        pass
    return None


def _parse_dns_question(dns_query: bytes) -> tuple[str, int, int, bytes] | None:
    """
    Parse the first RFC-1035 DNS question from `dns_query`.
    Returns (qname, qtype, qclass, raw_question_section) or None.
    """
    try:
        n = len(dns_query)
        if n < 17:
            return None
        pos = 12
        labels = []
        while pos < n:
            llen = dns_query[pos]
            pos += 1
            if llen == 0:
                break
            if llen >= 64 or pos + llen > n:
                return None
            labels.append(dns_query[pos : pos + llen].decode("ascii", errors="ignore"))
            pos += llen
        else:
            return None
        if pos + 4 > n:
            return None
        qtype = int.from_bytes(dns_query[pos : pos + 2], "big")
        qclass = int.from_bytes(dns_query[pos + 2 : pos + 4], "big")
        q_section = dns_query[12 : pos + 4]
        qname = ".".join(labels).strip(".")
        return qname, qtype, qclass, q_section
    except Exception:
        return None


class _OneShotDNSProto(asyncio.DatagramProtocol):
    def __init__(self, fut: asyncio.Future):
        self.fut = fut

    def datagram_received(self, data: bytes, addr):
        if not self.fut.done():
            self.fut.set_result(data)

    def error_received(self, exc):
        if not self.fut.done():
            self.fut.set_result(None)


async def _resolve_dns_over_tcp(dns_query: bytes, dns_addr: str = "1.1.1.1", dns_port: int = 53) -> bytes | None:
    """
    TUN-Safe & Instagram-Fast DNS Resolver for Windows v2rayN TUN, Happ, and NPV Tunnel:
    1. Immediately returns empty NOERROR (ANCOUNT=0) for AAAA (IPv6, qtype=28) and HTTPS/SVCB (qtype=65, 64)
       queries so Instagram, YouTube, and TUN clients NEVER attempt HTTP/3 (QUIC) or IPv6!
    2. Resolves A (IPv4, qtype=1) queries directly via `_resolve_ipv4_candidates` (which races 1.1.1.1,
       8.8.8.8, 9.9.9.9, and the 64-worker OS resolver) and synthesizes the RFC-1035 DNS response in < 1ms!
    3. Falls back to 1.1.1.1 / 8.8.8.8 / 9.9.9.9 UDP & TCP for non-A record types (SRV, TXT, MX, etc.).
    """
    if not dns_query or len(dns_query) < 12:
        return None

    txid = dns_query[:2]
    q_parsed = _parse_dns_question(dns_query)
    if q_parsed is not None:
        qname, qtype, qclass, q_section = q_parsed
        # Block AAAA (28) and HTTPS/SVCB (65, 64) with authoritative empty NOERROR so Instagram/YouTube use pure IPv4 TCP!
        if qtype in (28, 65, 64):
            return txid + b"\x81\x80\x00\x01\x00\x00\x00\x00\x00\x00" + q_section

        q_key = q_section
        now = time.monotonic()
        cached = _DNS_PKT_CACHE.get(q_key)
        if cached and cached[1] > now:
            return txid + cached[0]

        if qtype == 1 and qclass == 1 and qname:
            try:
                from outbound_proxy import _resolve_ipv4_candidates
                ips = await _resolve_ipv4_candidates(qname, 443, timeout=2.5)
                if ips:
                    ans_records = []
                    for ip_str in ips[:2]:
                        ip_bytes = socket.inet_aton(ip_str)
                        ans_records.append(
                            b"\xc0\x0c\x00\x01\x00\x01\x00\x00\x01\x2c\x00\x04" + ip_bytes
                        )
                    ancount = len(ans_records)
                    resp_body = (
                        b"\x81\x80\x00\x01"
                        + ancount.to_bytes(2, "big")
                        + b"\x00\x00\x00\x00"
                        + q_section
                        + b"".join(ans_records)
                    )
                    if len(_DNS_PKT_CACHE) >= _DNS_PKT_MAX:
                        _DNS_PKT_CACHE.clear()
                    _DNS_PKT_CACHE[q_key] = (resp_body, time.monotonic() + _DNS_PKT_TTL)
                    return txid + resp_body
            except Exception:
                pass
    else:
        q_key = dns_query[2:]
        now = time.monotonic()
        cached = _DNS_PKT_CACHE.get(q_key)
        if cached and cached[1] > now:
            return txid + cached[0]

    loop = asyncio.get_running_loop()
    for upstream in ("1.1.1.1", "8.8.8.8", "9.9.9.9"):
        transport = None
        try:
            fut = loop.create_future()
            transport, _ = await asyncio.wait_for(
                loop.create_datagram_endpoint(
                    lambda: _OneShotDNSProto(fut),
                    remote_addr=(upstream, 53),
                    family=socket.AF_INET,
                ),
                timeout=1.0,
            )
            transport.sendto(dns_query)
            resp = await asyncio.wait_for(fut, timeout=1.0)
            if resp and len(resp) >= 12:
                if len(_DNS_PKT_CACHE) >= _DNS_PKT_MAX:
                    _DNS_PKT_CACHE.clear()
                _DNS_PKT_CACHE[q_key] = (resp[2:], time.monotonic() + _DNS_PKT_TTL)
                return resp
        except Exception:
            pass
        finally:
            if transport:
                try:
                    transport.close()
                except Exception:
                    pass

    for upstream in ("1.1.1.1", "8.8.8.8", "9.9.9.9"):
        writer = None
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(upstream, 53),
                timeout=1.8,
            )
            writer.write(len(dns_query).to_bytes(2, "big") + dns_query)
            await writer.drain()
            rlen_b = await asyncio.wait_for(reader.readexactly(2), timeout=1.8)
            rlen = int.from_bytes(rlen_b, "big")
            resp = await asyncio.wait_for(reader.readexactly(rlen), timeout=1.8)
            if resp and len(resp) >= 12:
                if len(_DNS_PKT_CACHE) >= _DNS_PKT_MAX:
                    _DNS_PKT_CACHE.clear()
                _DNS_PKT_CACHE[q_key] = (resp[2:], time.monotonic() + _DNS_PKT_TTL)
                return resp
        except Exception:
            pass
        finally:
            if writer:
                try:
                    writer.close()
                except Exception:
                    pass
    return None


async def parse_vless_header(chunk: bytes):
    parsed = parse_vless_header_ex(chunk)
    if not parsed:
        return None
    _uid, command, address, port, payload, need_more = parsed
    if need_more:
        return None
    return command, address, port, payload