# outbound_proxy.py — BotVPN Ultra-Fast Outbound Connector (Parallel Async DNS + Multi-IP CDN Failover + MSS Clamping)
import asyncio
from concurrent.futures import ThreadPoolExecutor
import ipaddress
import json
import socket
import struct
import time

from main import DATA_DIR

PROXIES_FILE = DATA_DIR / "vodiwalker_proxies.json"
PROXIES: dict = {}

SOCK_LIMIT = 262144
SOCK_BUF_SIZE = 524288
TCP_MSS_CLAMP = 1360  # Prevents PMTU blackholes on German Hetzner/Netcup vSwitch & cellular border networks

# Dedicated 64-thread executor so 50+ concurrent Instagram/YouTube DNS lookups never queue behind Python's default 5-thread pool
_DNS_EXECUTOR = ThreadPoolExecutor(max_workers=64, thread_name_prefix="botvpn_dns")

# Dynamic IPv4 DNS cache: domain -> (list_of_ipv4_strings, expire_monotonic)
_DNS_CACHE: dict[str, tuple[list[str], float]] = {}
_DNS_INFLIGHT: dict[str, asyncio.Future] = {}
_DNS_TTL = 600.0
_DNS_MAX = 16384

_PUBLIC_DNS_SERVERS = ("1.1.1.1", "8.8.8.8", "9.9.9.9", "1.0.0.1")

_CLOUDFLARE_DOH_HOSTS = frozenset({
    "cloudflare-dns.com",
    "one.one.one.one",
    "1dot1dot1dot1.cloudflare-dns.com",
    "mozilla.cloudflare-dns.com",
})
_CLOUDFLARE_DOH_IPS = (
    "104.16.248.249",
    "104.16.249.249",
    "1.1.1.1",
    "1.0.0.1",
    "172.64.41.4",
)


def _load_sync():
    try:
        if PROXIES_FILE.exists():
            data = json.loads(PROXIES_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                PROXIES.clear()
                PROXIES.update(data)
    except Exception:
        pass


_load_sync()


def _tune_outbound_writer(writer: asyncio.StreamWriter):
    sock = writer.transport.get_extra_info("socket")
    if not sock:
        return
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    except Exception:
        pass
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    except Exception:
        pass
    try:
        tcp_maxseg = getattr(socket, "TCP_MAXSEG", 2)
        sock.setsockopt(socket.IPPROTO_TCP, tcp_maxseg, TCP_MSS_CLAMP)
    except Exception:
        pass
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SOCK_BUF_SIZE)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SOCK_BUF_SIZE)
    except Exception:
        pass


def is_fake_or_non_public_ip(address: str) -> bool:
    """
    Returns True if `address` is an IPv6 literal, FakeIP (198.18.0.0/15),
    TUN hijack IP (172.18.0.x / 172.19.0.x), or private/non-global IPv4 address.
    Note: 127.0.0.1 is allowed for local self-tests.
    """
    if not address:
        return True
    if address == "127.0.0.1":
        return False
    if ":" in address:
        return True
    try:
        ip_obj = ipaddress.ip_address(address)
        if ip_obj.version == 6:
            return True
        first_two = address.split(".")[:2]
        if len(first_two) == 2 and first_two[0] == "198" and first_two[1] in ("18", "19"):
            return True
        return not ip_obj.is_global
    except ValueError:
        return False


def _build_dns_a_pkt(domain: str) -> bytes:
    hdr = struct.pack("!HHHHHH", 0x3133, 0x0100, 1, 0, 0, 0)
    qname = b"".join(
        len(p).to_bytes(1, "big") + p.encode("ascii", errors="ignore")
        for p in domain.strip(".").split(".")
        if p
    ) + b"\x00"
    return hdr + qname + struct.pack("!HH", 1, 1)


def _parse_dns_a_pkt_all(resp: bytes) -> list[str]:
    out: list[str] = []
    if not resp or len(resp) < 12:
        return out
    qdcount = int.from_bytes(resp[4:6], "big")
    ancount = int.from_bytes(resp[6:8], "big")
    pos = 12
    for _ in range(qdcount):
        while pos < len(resp):
            ln = resp[pos]
            if ln == 0:
                pos += 1
                break
            if (ln & 0xC0) == 0xC0:
                pos += 2
                break
            pos += 1 + ln
        pos += 4
    for _ in range(ancount):
        if pos >= len(resp):
            break
        if (resp[pos] & 0xC0) == 0xC0:
            pos += 2
        else:
            while pos < len(resp) and resp[pos] != 0:
                pos += 1 + resp[pos]
            pos += 1
        if pos + 10 > len(resp):
            break
        rtype, _, _, rdlen = struct.unpack("!HHIH", resp[pos : pos + 10])
        pos += 10
        if pos + rdlen > len(resp):
            break
        rdata = resp[pos : pos + rdlen]
        pos += rdlen
        if rtype == 1 and rdlen == 4:
            ip = ".".join(str(b) for b in rdata)
            try:
                ip_obj = ipaddress.ip_address(ip)
                if ip_obj.version == 4 and ip_obj.is_global and ip not in out:
                    out.append(ip)
            except ValueError:
                pass
    return out


def _parse_dns_a_pkt(resp: bytes) -> str | None:
    ips = _parse_dns_a_pkt_all(resp)
    return ips[0] if ips else None


class _FastUDPQueryProto(asyncio.DatagramProtocol):
    __slots__ = ("fut",)

    def __init__(self, fut: asyncio.Future):
        self.fut = fut

    def datagram_received(self, data: bytes, addr):
        if not self.fut.done():
            ips = _parse_dns_a_pkt_all(data)
            if ips:
                self.fut.set_result(ips)

    def error_received(self, exc):
        pass


async def _query_udp_dns_all(domain: str, timeout: float = 0.9) -> list[str]:
    pkt = _build_dns_a_pkt(domain)
    loop = asyncio.get_running_loop()
    fut = loop.create_future()
    transports = []
    try:
        for ns in ("1.1.1.1", "8.8.8.8", "9.9.9.9"):
            try:
                t, _ = await asyncio.wait_for(
                    loop.create_datagram_endpoint(
                        lambda: _FastUDPQueryProto(fut),
                        remote_addr=(ns, 53),
                        family=socket.AF_INET,
                    ),
                    timeout=0.4,
                )
                transports.append(t)
                t.sendto(pkt)
            except Exception:
                pass
        if not transports:
            return []
        return await asyncio.wait_for(fut, timeout=timeout)
    except Exception:
        return []
    finally:
        for t in transports:
            try:
                t.close()
            except Exception:
                pass


async def _fallback_public_dns_a_all(domain: str) -> list[str]:
    udp_ips = await _query_udp_dns_all(domain, timeout=0.8)
    if udp_ips:
        return udp_ips
    pkt = _build_dns_a_pkt(domain)
    for ns in ("1.1.1.1", "8.8.8.8", "9.9.9.9"):
        writer = None
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(ns, 53), timeout=1.2)
            writer.write(len(pkt).to_bytes(2, "big") + pkt)
            await writer.drain()
            rlen = int.from_bytes(await asyncio.wait_for(reader.readexactly(2), timeout=1.2), "big")
            resp = await asyncio.wait_for(reader.readexactly(rlen), timeout=1.2)
            ips = _parse_dns_a_pkt_all(resp)
            if ips:
                return ips
        except Exception:
            pass
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass
    return []


async def _fallback_public_dns_a(domain: str) -> str | None:
    ips = await _fallback_public_dns_a_all(domain)
    return ips[0] if ips else None


def _getaddrinfo_sync(host: str, port: int) -> list[str]:
    out: list[str] = []
    try:
        infos = socket.getaddrinfo(host, port or 80, socket.AF_INET, socket.SOCK_STREAM)
        for info in infos or ():
            cand = info[4][0]
            try:
                ip_obj = ipaddress.ip_address(cand)
                if ip_obj.version == 4 and (ip_obj.is_global or cand == "127.0.0.1") and cand not in out:
                    out.append(cand)
            except ValueError:
                pass
    except Exception:
        pass
    return out


async def _resolve_ipv4_candidates(address: str, port: int = 80, timeout: float = 3.0) -> list[str]:
    if not address:
        return []
    address_l = address.strip().lower().rstrip(".")
    try:
        ip_obj = ipaddress.ip_address(address_l)
        if ip_obj.version == 4:
            return [address_l]
    except ValueError:
        pass

    now = time.monotonic()
    cached = _DNS_CACHE.get(address_l)
    if cached and cached[1] > now and cached[0]:
        return cached[0]

    inflight = _DNS_INFLIGHT.get(address_l)
    if inflight is not None:
        try:
            res = await asyncio.wait_for(asyncio.shield(inflight), timeout=min(timeout, 3.0))
            return res or []
        except Exception:
            return []

    loop = asyncio.get_running_loop()
    fut = loop.create_future()
    _DNS_INFLIGHT[address_l] = fut
    resolved_ips: list[str] = []
    try:
        # Race OS resolver (on 64-worker pool) AND direct UDP 1.1.1.1/8.8.8.8/9.9.9.9 simultaneously
        # so broken/slow container `/etc/resolv.conf` on Germany nodes NEVER stalls Instagram or YouTube!
        t_os = loop.run_in_executor(_DNS_EXECUTOR, _getaddrinfo_sync, address_l, port or 80)
        t_udp = asyncio.create_task(_query_udp_dns_all(address_l, timeout=1.0))

        done, pending = await asyncio.wait({t_os, t_udp}, timeout=1.5, return_when=asyncio.FIRST_COMPLETED)
        for d in done:
            try:
                r = d.result()
                if r:
                    resolved_ips = list(r)
                    break
            except Exception:
                pass

        if not resolved_ips and pending:
            done2, pending2 = await asyncio.wait(pending, timeout=1.2)
            for d in done2:
                try:
                    r = d.result()
                    if r:
                        resolved_ips = list(r)
                        break
                except Exception:
                    pass
            for p in pending2:
                p.cancel()
        else:
            for p in pending:
                if hasattr(p, "cancel"):
                    p.cancel()

        if not resolved_ips:
            resolved_ips = await _fallback_public_dns_a_all(address_l)

        if not resolved_ips and address_l in _CLOUDFLARE_DOH_HOSTS:
            resolved_ips = list(_CLOUDFLARE_DOH_IPS)
        elif not resolved_ips and address_l in ("dns.google", "dns.google.com"):
            resolved_ips = ["8.8.8.8", "8.8.4.4"]

        if resolved_ips:
            if len(_DNS_CACHE) >= _DNS_MAX:
                _DNS_CACHE.clear()
            _DNS_CACHE[address_l] = (resolved_ips[:4], time.monotonic() + _DNS_TTL)
        fut.set_result(resolved_ips)
        return resolved_ips
    except Exception:
        if not fut.done():
            fut.set_result([])
        return []
    finally:
        _DNS_INFLIGHT.pop(address_l, None)


async def _resolve_ipv4_dedup(address: str, port: int = 80, timeout: float = 3.0) -> str | None:
    cands = await _resolve_ipv4_candidates(address, port, timeout)
    return cands[0] if cands else None


async def _resolve_host_ipv4(address: str, port: int = 80, timeout: float = 3.0) -> str:
    if not address or address == "0.0.0.0":
        return "1.1.1.1"
    if address == "127.0.0.1":
        return "127.0.0.1"
    res = await _resolve_ipv4_dedup(address, port, timeout)
    return res or address


async def _open_direct_cached(address: str, port: int, timeout: float):
    address_l = (address or "").strip().lower().rstrip(".")

    # Redirect any private/FakeIP/CN TCP DNS (port 53) to fast global DNS
    if port == 53 and (not address_l or address_l in ("119.29.29.29", "223.5.5.5", "114.114.114.114") or is_fake_or_non_public_ip(address_l)):
        for dns_ip in _PUBLIC_DNS_SERVERS:
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(dns_ip, 53, limit=SOCK_LIMIT),
                    timeout=1.5,
                )
                _tune_outbound_writer(writer)
                return reader, writer
            except Exception:
                pass
        address = "1.1.1.1"
        address_l = "1.1.1.1"

    # Fast multi-IP failover for Cloudflare DoH (`https://cloudflare-dns.com/dns-query`) used by Windows v2rayN TUN mode
    if port == 443 and (address_l in _CLOUDFLARE_DOH_HOSTS or address_l in ("1.1.1.1", "1.0.0.1")):
        cands = []
        cached = _DNS_CACHE.get(address_l)
        if cached and cached[1] > time.monotonic():
            cands.extend(cached[0])
        for cf_ip in _CLOUDFLARE_DOH_IPS:
            if cf_ip not in cands:
                cands.append(cf_ip)
        for cand_ip in cands:
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(cand_ip, 443, limit=SOCK_LIMIT),
                    timeout=1.5,
                )
                _tune_outbound_writer(writer)
                _DNS_CACHE[address_l] = ([cand_ip], time.monotonic() + _DNS_TTL)
                return reader, writer
            except Exception:
                continue

    try:
        ip_obj = ipaddress.ip_address(address_l)
        if ip_obj.version == 4:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(address_l, port, limit=SOCK_LIMIT),
                timeout=timeout,
            )
            _tune_outbound_writer(writer)
            return reader, writer
    except ValueError:
        pass

    cands = await _resolve_ipv4_candidates(address_l, port, timeout)
    if cands:
        per_try = min(timeout, 2.5) if len(cands) > 1 else min(timeout, 4.0)
        for idx, cand_ip in enumerate(cands[:3]):
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(cand_ip, port, limit=SOCK_LIMIT),
                    timeout=per_try,
                )
                _tune_outbound_writer(writer)
                if idx > 0:
                    # Promote the working IP to the front of the cache
                    new_order = [cand_ip] + [x for x in cands if x != cand_ip]
                    _DNS_CACHE[address_l] = (new_order, time.monotonic() + _DNS_TTL)
                return reader, writer
            except Exception:
                continue
        _DNS_CACHE.pop(address_l, None)

    reader, writer = await asyncio.wait_for(
        asyncio.open_connection(address, port, limit=SOCK_LIMIT),
        timeout=timeout,
    )
    _tune_outbound_writer(writer)
    return reader, writer


async def _connect_via_socks(proxy: dict, address: str, port: int):
    from python_socks import ProxyType
    from python_socks.async_.asyncio import Proxy

    scheme = str(proxy.get("scheme") or "socks5").lower()
    ptype = {"socks5": ProxyType.SOCKS5, "socks4": ProxyType.SOCKS4, "http": ProxyType.HTTP}.get(scheme, ProxyType.SOCKS5)
    px = Proxy.create(
        proxy_type=ptype,
        host=proxy["host"],
        port=int(proxy["port"]),
        username=(proxy.get("username") or None),
        password=(proxy.get("password") or None),
        rdns=True,
    )
    sock = await px.connect(dest_host=address, dest_port=port)
    reader, writer = await asyncio.open_connection(sock=sock, limit=SOCK_LIMIT)
    _tune_outbound_writer(writer)
    return reader, writer


async def open_target_connection(link: dict | None, address: str, port: int, timeout: float = 8.0):
    proxy_id = (link or {}).get("outbound_proxy_id") or ""
    proxy = PROXIES.get(proxy_id) if proxy_id else None
    if not proxy or not proxy.get("host"):
        return await _open_direct_cached(address, port, timeout)
    return await asyncio.wait_for(_connect_via_socks(proxy, address, port), timeout=timeout)