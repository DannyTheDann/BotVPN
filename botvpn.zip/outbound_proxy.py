# outbound_proxy.py — BotVPN Ultra-Fast Outbound Connector (In-Flight DNS Deduplication + IPv4 Cache + TUN Safe)
import asyncio
import ipaddress
import json
import socket
import time

from main import DATA_DIR

PROXIES_FILE = DATA_DIR / "vodiwalker_proxies.json"
PROXIES: dict = {}

SOCK_LIMIT = 131072
SOCK_BUF_SIZE = 262144

_DNS_CACHE: dict[str, tuple[str, float]] = {}
_DNS_INFLIGHT: dict[str, asyncio.Future] = {}
_DNS_TTL = 600.0
_DNS_MAX = 8192


def _load_sync():
    try:
        if PROXIES_FILE.exists():
            data = json.loads(PROXIES_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                PROXIES.clear()
                PROXIES.update(data)
    except Exception:
        pass


_load_sync()


def _tune_outbound_writer(writer: asyncio.StreamWriter):
    sock = writer.transport.get_extra_info("socket")
    if not sock:
        return
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    except Exception:
        pass


def is_fake_or_non_public_ip(address: str) -> bool:
    """
    Returns True if `address` is an IPv6 literal, FakeIP (198.18.0.0/15),
    TUN hijack IP (172.18.0.x / 172.19.0.x), or private/non-global IPv4 address.
    Note: 127.0.0.1 is allowed for local self-tests.
    """
    if not address:
        return True
    if address == "127.0.0.1":
        return False
    if ":" in address:
        return True
    try:
        ip_obj = ipaddress.ip_address(address)
        if ip_obj.version == 6:
            return True
        # 198.18.0.0/15 is the standard Sing-box / Clash / Happ FakeIP range
        first_two = address.split(".")[:2]
        if len(first_two) == 2 and first_two[0] == "198" and first_two[1] in ("18", "19"):
            return True
        return not ip_obj.is_global
    except ValueError:
        return False


async def _resolve_ipv4_dedup(address: str, port: int = 80, timeout: float = 3.5) -> str | None:
    if not address:
        return None
    address_l = address.strip().lower()
    try:
        ip_obj = ipaddress.ip_address(address_l)
        if ip_obj.version == 4:
            return address_l
    except ValueError:
        pass

    now = time.monotonic()
    cached = _DNS_CACHE.get(address_l)
    if cached and cached[1] > now:
        return cached[0]

    inflight = _DNS_INFLIGHT.get(address_l)
    if inflight is not None:
        try:
            return await asyncio.wait_for(asyncio.shield(inflight), timeout=min(timeout, 3.5))
        except Exception:
            return None

    loop = asyncio.get_running_loop()
    fut = loop.create_future()
    _DNS_INFLIGHT[address_l] = fut
    resolved_ip = None
    try:
        infos = await asyncio.wait_for(
            loop.getaddrinfo(address_l, port or 80, family=socket.AF_INET, type=socket.SOCK_STREAM),
            timeout=min(timeout, 3.5),
        )
        if infos:
            resolved_ip = infos[0][4][0]
            if len(_DNS_CACHE) >= _DNS_MAX:
                _DNS_CACHE.clear()
            _DNS_CACHE[address_l] = (resolved_ip, time.monotonic() + _DNS_TTL)
        fut.set_result(resolved_ip)
        return resolved_ip
    except Exception:
        if not fut.done():
            fut.set_result(None)
        return None
    finally:
        _DNS_INFLIGHT.pop(address_l, None)


async def _resolve_host_ipv4(address: str, port: int = 80, timeout: float = 3.5) -> str:
    if not address or address == "0.0.0.0":
        return "1.1.1.1"
    if address == "127.0.0.1":
        return "127.0.0.1"
    res = await _resolve_ipv4_dedup(address, port, timeout)
    return res or address


async def _open_direct_cached(address: str, port: int, timeout: float):
    # If TUN mode sends TCP DNS (port 53) to a private/router/FakeIP or slow CN DNS (119.29.29.29), redirect to 1.1.1.1
    if port == 53 and (not address or address in ("119.29.29.29", "223.5.5.5", "114.114.114.114") or is_fake_or_non_public_ip(address)):
        address = "1.1.1.1"

    try:
        ip_obj = ipaddress.ip_address(address)
        if ip_obj.version == 4:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(address, port, limit=SOCK_LIMIT),
                timeout=timeout,
            )
            _tune_outbound_writer(writer)
            return reader, writer
    except ValueError:
        pass

    resolved_ip = await _resolve_ipv4_dedup(address, port, timeout)
    if resolved_ip:
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(resolved_ip, port, limit=SOCK_LIMIT),
                timeout=timeout,
            )
            _tune_outbound_writer(writer)
            return reader, writer
        except Exception:
            _DNS_CACHE.pop(address.strip().lower(), None)

    reader, writer = await asyncio.wait_for(
        asyncio.open_connection(address, port, limit=SOCK_LIMIT),
        timeout=timeout,
    )
    _tune_outbound_writer(writer)
    return reader, writer


async def _connect_via_socks(proxy: dict, address: str, port: int):
    from python_socks import ProxyType
    from python_socks.async_.asyncio import Proxy

    scheme = str(proxy.get("scheme") or "socks5").lower()
    ptype = {"socks5": ProxyType.SOCKS5, "socks4": ProxyType.SOCKS4, "http": ProxyType.HTTP}.get(scheme, ProxyType.SOCKS5)
    px = Proxy.create(
        proxy_type=ptype,
        host=proxy["host"],
        port=int(proxy["port"]),
        username=(proxy.get("username") or None),
        password=(proxy.get("password") or None),
        rdns=True,
    )
    sock = await px.connect(dest_host=address, dest_port=port)
    reader, writer = await asyncio.open_connection(sock=sock, limit=SOCK_LIMIT)
    _tune_outbound_writer(writer)
    return reader, writer


async def open_target_connection(link: dict | None, address: str, port: int, timeout: float = 8.0):
    proxy_id = (link or {}).get("outbound_proxy_id") or ""
    proxy = PROXIES.get(proxy_id) if proxy_id else None
    if not proxy or not proxy.get("host"):
        return await _open_direct_cached(address, port, timeout)
    return await asyncio.wait_for(_connect_via_socks(proxy, address, port), timeout=timeout)