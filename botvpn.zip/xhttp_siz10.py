# xhttp_siz10.py — Compatibility stub for legacy panel launchers
def register_xhttp_siz10_routes(app=None, **kwargs):
    return None
